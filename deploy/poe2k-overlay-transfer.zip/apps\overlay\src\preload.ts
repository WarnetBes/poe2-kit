/**
 * Preload: безопасный мост между изолированным рендерером и main-процессом.
 * Renderer имеет доступ только к api, описанному ниже (contextIsolation: true).
 */
import { contextBridge, ipcRenderer } from 'electron';

export interface OverlayAPI {
  priceCheck(): Promise<unknown>;
  onPriceResult(cb: (result: unknown) => void): () => void;
  onPriceBusy(cb: (busy: boolean) => void): () => void;
  onLevelResult(cb: (level: unknown) => void): () => void;
  getLeague(): Promise<string>;
  setLeague(league: string): Promise<string>;
  getHotkey(): Promise<string>;
  setInteractive(interact: boolean): Promise<boolean>;
  onMoveMode(cb: (state: { unlocked: boolean; resetOffset: boolean }) => void): () => void;
  resetOffset(): Promise<boolean>;
  onBuildUpdate(cb: (state: unknown) => void): () => void;
  buildImport(): Promise<boolean>;
  buildToggle(): Promise<boolean>;
  buildReset(): Promise<boolean>;
  buildGet(): Promise<unknown>;
  /** Подогнать высоту окна под контент ( авторазмер, px в DIP). */
  autosize(px: number): Promise<number>;
}

const api: OverlayAPI = {
  priceCheck: () => ipcRenderer.invoke('price:check'),

  onLevelResult: (cb) => {
    const listener = (_evt: unknown, data: unknown) => cb(data);
    ipcRenderer.on('level:result', listener);
    return () => ipcRenderer.removeListener('level:result', listener);
  },

  onPriceResult: (cb) => {
    const listener = (_evt: unknown, data: unknown) => cb(data);
    ipcRenderer.on('price:result', listener);
    return () => ipcRenderer.removeListener('price:result', listener);
  },

  onPriceBusy: (cb) => {
    const listener = (_evt: unknown, data: boolean) => cb(data);
    ipcRenderer.on('price:busy', listener);
    return () => ipcRenderer.removeListener('price:busy', listener);
  },

  getLeague: () => ipcRenderer.invoke('league:get'),

  setLeague: (league) => ipcRenderer.invoke('league:set', league),

  getHotkey: () => ipcRenderer.invoke('hotkey:get'),

  setInteractive: (interact) => ipcRenderer.invoke('interact:set', interact),

  onMoveMode: (cb) => {
    const listener = (_evt: unknown, state: { unlocked: boolean; resetOffset: boolean }) =>
      cb(state);
    ipcRenderer.on('move:mode', listener);
    return () => ipcRenderer.removeListener('move:mode', listener);
  },

  resetOffset: () => ipcRenderer.invoke('move:reset'),

  onBuildUpdate: (cb) => {
    const listener = (_evt: unknown, state: unknown) => cb(state);
    ipcRenderer.on('build:update', listener);
    return () => ipcRenderer.removeListener('build:update', listener);
  },

  buildImport: () => ipcRenderer.invoke('build:import'),

  buildToggle: () => ipcRenderer.invoke('build:toggle'),

  buildReset: () => ipcRenderer.invoke('build:reset'),

  buildGet: () => ipcRenderer.invoke('build:get'),

  autosize: (px) => ipcRenderer.invoke('overlay:autosize', px),
};

contextBridge.exposeInMainWorld('poe2k', api);