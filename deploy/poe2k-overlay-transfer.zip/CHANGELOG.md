# Changelog

Формат loosely по [Keep a Changelog](https://keepachangelog.com/).
Версии совпадают с тегами релизов на SourceCraft.

## [1.0.33] — 2026-10-19 (сессии №496—№568: гайды/планнер poeshop-волна, иконки гемов/уников, данные патча)

### Added
- **Вкладка «📖 Гайды» (poeshop-стиль):** карточная сетка 298 гайдов с GGG-обложками, тир-лист S–C, чип-фильтры со счётчиками, аккордеон; датасет guides/poeshop_guides.json (генератор gen-poeshop-guides.mjs, только фактура + url-атрибуция).
- **Планнер по мотивам poeshop.ru/planner:** скилл-группы с клик-ячейками, пикер с поиском и рекомендованными, share-ссылка #pl= (base64url, приоритетнее LS), 11 клик-слотов экипировки с иконками уников + пикер + кастом-имя.
- **Иконки гемов/уников (poe2db, CC BY-NC-SA, GGG-арт):** skill_gems/icons 831 + uniques/icons 430 + индексы-манифесты; генераторы fetch-gem-icons.mjs (слаг poe2db регистрозависим: of/the строчные, римские цифры RR, дефисы Title, percent-хекс верхний) и fetch-item-icons.mjs; dist-зеркала gem_icons/item_icons через copy-datasets.mjs.
- **UX (№568):** deep-links #t=<tab> на все вкладки (соседствует с a=/pl=, restore после init-хендлеров), кнопки «Из буфера» ×4 (build/compare/keybinds/pob), Escape → закрытие пикеров, lastTabInGroup → LS.
### Changed
- **Карточный редизайн «🧬 Билды»:** обложки классов, цен-бейджи, фейк-рамки, чип-фильтры классов/цен, аккордеон.
- **₽-цены убраны из UI (№496, решение владельца):** остаются только в structured-данных и raw-датасетах; из markdown-тулов poe2_unique_market / poe2_price_check / poe2_starter_builds, tooltip’ов web и overlay — удалены. README RU/EN дополнен честной строкой про источник poeshop (RMT-витрина, НЕ рынок; кит ничего не продаёт).
- **fullMap.ts:** syncPlanHash теперь сохраняет чужие hash-сегменты (не затирает #t=/#a=).
### Verified
- build web OK; vitest 585/585; npm run smoke ALL OK; живой E2E: пикер гемов 380/381 <img>, гир 52/53, deep-links #t=, share #pl=…&t=planner, Escape, paste-кнопки ×4.
### Not verified
- 52 иконки гемов (мусорные mod-подписи / tier-II без страниц / CDN-403) — фолбэк-жетоны by design, докач = убывающая отдача.
- CI-раны SourceCraft после push — принять глазами.



### Changed
- **Рубли убраны из всех текстовых выводов и UI (решение владельца: кит бесплатный, цены услуг не показывать).** ₽-цифры витрин (poeshop rub, lootkeeper_rub) остаются только в structured-данных и raw-датасетах: из markdown-ответов тулов `poe2_unique_market` / `poe2_price_check` / `poe2_starter_builds`, tooltip'ов web-вкладки «🧬 Билды» и overlay-панели «🧬 Стартовые» (вкл. запекаемый в renderer датасет) — удалены. README RU/EN дополнен честной строкой про источник poeshop (RMT-витрина, НЕ рынок; кит ничего не продаёт).

## [1.0.32] — 2026-10-15 (сессии №469–№494: стартовые билды, витрина poeshop, дисклеймер)

### Added
- **Стартовые билды 0.5.x (эпика №479–№488, курируемые волны ресёрча №471–№477):** датасет `starter_builds.json` — 18 билдов (патч 0.5.5, Forbidden Rites) со стадиями-ценами (Старт/Мид/Мейн/Макс; неопубликованные цены честно null), ключевыми униками, порядком узлов асценденси, PoB-ссылками; предупреждения о фейк-связках (тронутые-warning). 9 расхождений гайдов закрыты подтверждённым декодом PoB (№482/№485). Поле `lootkeeper_rub` (№484) — честная пометка «цена витрины услуг, НЕ стоимость гира».
  - **MCP-тул `poe2_starter_builds`:** карточки билдов с фильтрами id/class/ascendancy/query (тул №76).
  - **Web-вкладка «🧬 Билды»:** 18 карточек, 8 класс-групп, поиск, 59 внешних PoB-ссылок (target/rel), ⚠-фейк-пометки; живой DOM-E2E 18/18 (№481).
  - **Overlay-панель «🧬 Стартовые»** (№487, a4addff): вкладка starterbuilds, компакт-датасет 31 КБ запекается в rendererHtml (паттерн RADAR_LIVE), PoB-ссылки через IPC `starter:openpob` (allowlist poe.ninja/pobb.in).
- **Витрина poeshop.ru — офлайн-цены (№493–№494, 83a48db):** датасет `market/poeshop_market.json` (957 записей с ценами по лигам, 945 RU-имён; генератор `scripts/gen-poeshop-market.mjs`, скрап flight-чанков Next.js, curl-фолбэк). Закрывает пробел «каталог уников не знает цен»; честные caveats в `_meta` (RMT-витрина, rub floor 50₽ у дешёвых, свежесть по fetchedAt, Standard устаревает).
  - **Core-модуль `poeshopMarket`:** lookup EN/RU/канонического имени, лига-резолв, приоритет свежих челлендж-лиг, вердикт-тиры divine (≥10 «🔴 НЕ выкидывай» / ≥1 ценный / ≥0.1 дёшево / …), freshness.
  - **MCP-тул `poe2_unique_market` (№77):** офлайн-оценка уника с вердиктом «не выкидывай», варианты баз, поиск; дисклеймер «витрина услуг, НЕ рыночная стоимость гира». Работает с Ctrl+C из RU-клиента (ruIndex).
  - **Хук в `poe2_price_check`:** редкость Unique → секция «Витрина poeshop»: цены div/ex/chaos + вердикт + freshness; при молчащих scout/trade2 — единственная доступная оценка.

### Changed
- **Дисклеймер актуализирован** (№469, a423215; модалка «О проекте · Дисклеймер» в web + README RU/EN): добавлены секции про MCP-инструментарий (77 тулов, локальный процесс, клиент игры не затрагивается), работу кита без установленной игры (game-зависимые разделы честно сообщают об отсутствии лога) и portable-дистрибуцию (zip без установки, пишет только в свою папку).
- **Data-refresh 15.10** (`efceae5`): `trade_stats.json` +2 fractured-стата (Allocates Quick Recovery, Allocates Unbothering Cold), `fetchedAt` RePoE 11→15.10.
- **Смок n136 устойчивее** (№489, 3635be1): точная строка PANEL_TABS заменена литерал-паттерном — смоки больше не ломаются от порядка вкладок.

### Verified
- Гейты релиза: core/mcp/overlay/web builds 0; vitest **585/585** (+14 poeshop); `npm run smoke` ALL OK (вкл. MCP `--smoke` = **77**); CI SourceCraft на `83a48db` — run 1000007 `ci-ping` success (pob-джобы не триггерятся фильтром путей); живой lookup витрины: Temporalis (RU/EN/канонич.) → jackpot, RU-матчинг «Темпоралис Шёлковое платье» OK.

### Not verified (честно)
- Живой глазной контроль overlay-панели «🧬 Стартовые» и PoB-ссылок у друга; свежесть среза poeshop после следующего патча/лиги (рефреш: `node scripts/gen-poeshop-market.mjs --scrape`); длинные сессии MCP 77.

## [1.0.31] — 2026-10-11 (сессии №455–№463: ЭПИКА headless-PoB — движок PathOfBuilding-PoE2 в комплекте, фазы 1–4)

### Added
- **Headless-PoB оракул (эпика, фазы 1–4; хост `oracle/headless/pob_host.lua`, контракт 4):** настоящий движок PoB2 (v0.23.1, без патчей апстрима) считается в ките. One-shot для тула + ДОЛГОЖИВУЩАЯ персист-сессия для web (boot ~2.5 с один раз → RPC ~3 мс, FIFO-очередь, id-матчинг, ленивый рестарт; RPC умершего движка = честный отказ, не ответ из пустого билда).
  - **MCP-тул `poe2_recompute`:** живые статы билда + what-if матрица `scenarios=[...]` (до 12 сценариев {name, config, level} одним boot'ом, CAS-изоляция: каждый поверх baseline, невалидный сценарий — точечный отказ, матрица живёт); CAS-конфиг с валидацией enum и авто-резистами босс-тиров (Boss 30 / Pinnacle 50 / Uber 50 — апстрим в headless применяет их только как GUI-плейсхолдеры); `get_config_schema`, snapshot/restore_build.
  - **Дерево целей в `poe2_build_estimate`:** опция `goals` (≤8 уровневых вех) → live-таблица DPS/Life/EHP с Δ к baseline; XML-код ретраится через decode-фолбэк.
  - **Web-вкладка «🧮 PoB-оракул»** (раздел «Билд»): статус сессии, загрузка share-кода/XML (дедуп «Из поля "Импорт билда"»), пресеты what-if (Босс / Пиннакл+Хаос75 / Uber / lvl 92-95-100 + свой уровень) с Δ% и честным 503+hint. API: serve-dist.mjs `/api/pob/{load,rpc,status}` (whitelist-RPC, произвольный Lua не отдаём).
- **Воспроизводимость оракула (фаза 4):** `oracle/PINNED.md` (тег v0.23.1, zip SHA256, SHA-гейты luajit.exe/lua51.dll, контракт 4, процедура дрейфа 0_5→1.0); кросс-платформенный `oracle/headless-selftest.mjs` (без билд-XML: new_build/whatif/CAS); CI-workflow `pob-headless` (Linux, SourceCraft; sha256sum в лог для сверки с пинами).
- **Инструкция сетапа игрового ПК:** `docs/GAMINGPC_SETUP_RU.md` из шары (XP-copy → Node → рантайм → клон PoB2 → POE2K_POB2_SRC → serve-dist → оракул/MCP/оверлей; таблица симптомов).

### Fixed
- **⚠️ Веб-сборка была сломана с Фазы 2:** `pobHost.ts`/`pobSession.ts` использовали статические named-imports node-builtins — rollup подменяет их `__vite-browser-external` без экспортов → `vite build` web падал. Переведены на канонический nodeenv-паттерн кита (ленивые node:* через IS_NODE; top-level await, es2022). Не проявлялось ранее, потому что web-dist не персобирался; теперь правило: трогаешь packages/core → гейтить `npm run build -w @poe2-kit/web`.
- **Контракт 3→4 протокола:** dkjson при DECODE пропускает `"ключ":null` — «удалить ключ» через JSON round-trip не выражался, restore_config по RPC молча не откатывал. Фикс: `set_config` отдаёт `remove[]`, `restore_config` принимает `before` и/или `remove`.

### Verified (live E2E, эталон Invoker lvl 97)
- baseline TotalDPS 5 992 638.62 / Life 1539 — идентичен настольному PoB2 того же тега; Boss +0% (билд игнорирует элементальные резисты — флаги Ignore*), Pinnacle+Chaos75 −26.2%, Uber −70% (1.80M); 12-сценарная смешанная матрица (level+config вместе) — 0 fails, after-matrix = baseline до копейки; персист-сессия: 10 RPC одним спавном, каждый ~3 мс.
- Гейты релиза: tsc 0 (core/mcp/overlay/web), vitest 563/563 (+6 PobSession, +2 oracle), vite build OK, smoke 75.

### Not verified (честно)
- Первый Linux-CI-ран pob-headless (ждёт cloud worker), визуал вкладки в браузере (проверен HTTP-API-уровень), HTTP-конкурентность под нагрузкой, дни-аптайм сессии, live-OAuth GGG (`POE2K_GGG_CLIENT_ID`), дрейф-процедура на живом релизе 1.0.

## [1.0.30] — 2026-10-10 (сессия №266: suppadv-web, честность дат патч-таймлайна, пробы источников)

### Added
- **Саппорт-советы в web-разборе билда (№266, suppadv-web):** после «Разобрать» (вкладка «Импорт билда») под сводкой появляется блок рекомендаций саппортов по каждому активному кому. Слои — core.gemSupports (№192/№262-Э4): эталон меты (meta_supports: билд+дата) → base-ранги poe2db; «нет гема в слоях» = честное пусто. Датасеты (16 КБ + 317 КБ) подгружаются лениво из public/datasets (scripts/copy-datasets.mjs), офлайн, без внешних запросов.

### Changed
- **Web-радар: точность дат патч-таймлайна (№266):** строки 0.5.3/0.5.4 показывают ≈-пометку и вид точности даты (approx / day-of-approximate-source) — неточная дата больше не выглядит точной.

### Investigated
- Пробы источников: poe.ninja builds-API жив напрямую (index-state, срез 0056-20261010) — web-версия «🧬 Билды» осуществима без прокси; poe.ninja exchange-overview отвечает 200, но пуст в обеих индексированных лигах — для свежих курсов не полагаться.

## [1.0.29] — 2026-10-10 (волна №262 + №263/№265: web/overlay-паритет, курация известного, живая верификация)

### Added
- **Волна №262 «web/overlay-паритет» (5 коммитов `c4639b8…4609188`):**
  - **web**: nav-группы .tabgroups (Сейчас/Прокачка/Билд/Эндгейм/Экономика) + лендинг «Сейчас» (чек-лист-снапшот, резисты lastBuild, live-баги — офлайн); новые вкладки «🔨 Крафт» (craftPlan по предмету из поля/буфера + каталоги CRAFT_* аккордеонами), «👑 Пиннакл» (estimateBuild по `poe2k.lastBuildCode` → pinnacleChecklist, verdict pass/fail/unknown), «📖 Слэнг» (web-вкладок теперь 17); переименования map→«Дерево (полное)», tree→«Дерево (мои узлы)»; кнопка сравнения с последним билдом.
  - **overlay**: новая вкладка «🛡 Радар» (liveIssues/listKnownTricks запечены JSON-инжектом из core, офлайн) + keybinds-секция в панели билда (IPC `keybinds:advice` → adviseKeybinds по импортированному билду, `#buildKeybinds`).
  - **core**: `slang.ts` (единый источник словаря overlay+web), `gemSupports.ts` (движок supportsForActive, `normGemName`, `GemSupportRecoLite`, `resetGemSupportCaches`); overlay — делегация core.
- **E2E-скрипты №265** (живая верификация): `tests/e2e/e2e_radar_unverified.mjs` (живой MCP-зов poe2_known_issues), `scripts/e2e-radar-web.mjs` (CDP-клик web-радара), `scripts/e2e-radar-overlay.mjs` (живой Electron-прогон overlay-радара).

### Changed
- **Курация known_issues (№263 + №265, живые фetчи forum-тредов)**: strongbox-unable-open и vaal-ruins-waypoint — подтверждены 10+ независимыми репортёрами → **live** с воркараундами (взорвать как экспедиционный; пати-телепорт/маяк с 5+ кристаллами); ghostdance-compressed-duration и spirit-reservation-checkbox — единичные репорты → **unverified** с пояснениями (поле `unverified`); битые Inven-URL `/board/poe2/4845/*` → `/board/poe/6317/*` (known_issues + tricks). Итог: live 12, unverified 5.
- **T_DICT overlay**: строки радара («Воркараунд:», «Как:», «Механизм:») переведены для EN-локали.

## [1.0.28] — 2026-10-10 (волны №239–№248 + №256: Simulacrum, источники/свежесть, stat-id, «🛡 Радар»)

### Added
- **«🛡 Радар» №256 — патч-таймлайн, живые баги и хитрости PoE2 (web-вкладка 15 + data-слой + 2 MCP-тула)**:
  - **Data**: `packages/core/data/game/known_issues.json` (22 записи: 14 live / 3 unverified ❓ / 4 fixed / 1 feature — в т.ч. фича-не-баг Arbiter of Divinity non-quest Origin Core; формат наследует known_issues simulacrum_facts) + `tricks.json` (8 легальных хитростей: Ritual-postpone лимит, патч-день-стэш, Texture Quality low-VRAM, spirit-гем-галочка, пати-роли aurabot/MF-culler, фарм-мета 0.5.5e). Наполнение — ресёрч-волна-2 (`_research/poe2r2_*_digest_2026-10.md`), курация ручная; при хотфиксах GGG записи переводятся в fixed с `fixed_in` (append-only).
  - **Core** `packages/core/src/radar.ts`: parseKnownIssues/parseKnownTricks (enum-гейты status/severity/risk; fixed обязан иметь fixed_in), фильтры live/unverified/fixed/feature, radarMeta, findIssue/findTrick.
  - **MCP-тулы 64–65** `poe2_known_issues` + `poe2_tricks` (apps/mcp/src/tools/radar.ts): фильтры status/query/category/id, unverified — с ❓-пометкой в markdown и structured; смоки n236/n239 — счётчик 63→65, новый `tests/smoke/smoke_n256_radar.mjs` (14 проверок).
  - **Web-вкладка «🛡 Радар»** (apps/web/src/radar.ts, 15-я, между Simulacrum и «Карта»): патч-таймлайн из patches.json, живые баги, ❓-секция, исправленное, фичи-не-баги, хитрости, свежесть данных (в браузере freshness читает только метафайлы — полный прогон через MCP poe2_data_freshness); CSS-классы Simulacrum переиспользованы.
  - Simulacrum known-issues: 2-й триггер бага unable-to-proceed (Grand Mirror на островной боссовой арене, Ol'Roth; волна-2 №256) влит в known_issues `simulacrum_facts.json` (записи слиты, не задублированы).
- **Simulacrum №239: энциклопедия + гайд (Delirium, PoE2 0.5.x)** — 5-агентный ресёрч 09.10.2026 (досье: `_research/poe2_simulacrum_research.md`, `simulacrum_loot_0.5.md`, `simulacrum_strategy_0.5.md`; UI-концепция docs/design_simulacrum_tab.md):
  - **Web-вкладка «🌀 Simulacrum»** (`apps/web/src/simulacrum.ts`, ленивый рендер по клику): fact-box (7 волн / 300 сплинтеров / 100→200% Deliriousness), stepper доступа (Delirium Mirror → Grand Mirror → Fog Bank → предмет → Tang'Mazu), таблица 7 волн с расчётной sevBar-опасностью, 3 Fracturing Shards с консенсус-рекомендацией (боссы > моды > паки), 3 босс-карточки в формате «Атака→Телеграф→Ответ→Опасность» (Kosis / Omniphobia / Tang'Mazu), лут-таблица с honest-экономикой (Voices-джекпот ≈ весь профит), 4 collapse-стратегии, атлас-ноды Delirium (mandatory «Is this about me... or you?»), чек-лист из 7 пунктов с копированием в буфер. Интеграция: main.ts (+tab btn/pane/import/init), style.css (префикс `sim-*`). Спорный «Count Geonor» отклонён (PoE1-босс, 0 подтверждающих источников).
  - **Phase-2: core.simulacrum** (`packages/core/src/simulacrum.ts`) — нормализованные данные гайда (12 `unverified`-пометок сохранены: волны боссов 3–5, Realmgate-уровни, прирост Deliriousness, сэмплы рейтов) + офлайн-генератор `simulacrumGuideMarkdown(section)` (9 секций all/overview/access/waves/bosses/loot/strategy/atlas/checklist; danger-шкала `simDangerBar` для медиа-независимого рендера). Web-вкладка переведёна на импорт из core — один источник данных для вкладки и MCP.
  - **MCP-тул №63 `poe2_simulacrum_guide`** (apps/mcp/src/tools/simulacrum.ts): section (enum, дефолт all) → markdown-гайд + structured {section, markdown, facts, waves, bosses, checklist}; readOnly, офлайн, честная дисциплина unverified.
  - **Known-issues секция (№244)**: живой баг Grand Delirium Mirror / Simulacrum «unable to proceed» (репорты 05–06.10.2026, bugfree.gg + форум 4009785, не в официальных Known Issues — unverified-пометка) + community-воркараунд; core `SIM_KNOWN_ISSUES` → markdown-секция 'checklist'/'all' + web-рендер `.sim-known`.
- **Stat-id-первичный матчинг + локализационные алиасы (№246, Этап 2 «источники + автообновление», закрывает №190)**:
  - `core.statMatching`: новый опциональный параметр `strategy: MatchStrategy` (`'stat-id'` — дефолт | `'text'`) и входной тип `StatMatchInput = string | { text: string; id?: string | null }` (строки обратно совместимы); при известном датасету id матч идёт по id в каждом слое (offline → live), неизвестный id = прозрачный text-фолбэк; результат получил `matchedBy: 'stat-id' | 'text' | 'unknown'`. Каталог переработан в `Catalog { byText, byId }` (+`findById`). Дефолтное поведение строк без id не изменилось (регресс-тесты).
  - **Локализационные алиасы EN→{de,es,fr,pt,ru}** для text-фолбэка: `packages/core/data/game/i18n/aliases.json` (17 терминов из дайджестов 2026-10, per-term `_meta {patch:'0.5.x', sources[]}`, непереведённые локали = отсутствие ключей, Heist/Blight PoE1-заимствования не добавлены) + лоадер `core.i18nAliases` (`getI18nTermAliases`/`i18nAliasesMeta`/`resetI18nAliasesCache`, паттерн learnedStats: HAS_DISK, офлайн). Алиасы НЕ подменяют, а расширяют кандидаты после родных; границы слов посимвольно `\p{L}\p{Nd}` (\b ASCII-only ломится на «Делириум»/«téléportation»).
  - `trade.matchModsToStatFilters` принимает `StatMatchInput[]` + `{strategy}` (additive, старые вызовы работают).
  - Тесты: новый `packages/core/test/statMatchingStrategy.test.ts` — 15 кейсов (DE-смесь по stat-id == EN, FR-обрезка, алиасы DE/ES/FR/PT/RU, честность покрытия: Simulacrum без pt, регресс дефолта, интеграция trade.ts); suite 252/252.
- Тесты: живой CDP e2e `scripts/e2e-simulacrum.mjs` (23/23 PASS: консоль чистая, lazy-rerender-guard, unverified≥5, Catalysts-ложь отсечена, known-issues) + `tests/smoke/smoke_n239_simulacrum.mjs` (10/10: регистрация 63 тулов, изолированные секции, zod-enum-валидация).

### Changed
- **Этап 4 «safe auto-refresh» (№248): реестр патчей + дедупликация реестров + stale-only refresh + diff-отчёт**:
  - **Офлайн-реестр патчей** `packages/core/data/game/patches.json` (11 записей: 0.4.0 12.12.2025 → 0.5.5e 06.10.2026; даты — только из дайджестов ресёрча 09.10.2026, спорные 0.5.3/0.5.4 помечены `unverified` и в knownPatchAt НЕ попадают) + `core.patches` (`listKnownPatches`/`findKnownPatch`/`knownPatchAtMs`/`latestKnownPatch`/`parseKnownPatches` — битый/пустой файл = честная отработка). Сознательно без живого парсинга GGG-страниц: файл обновляет куратор при патче.
  - **knownPatchAt подключён в freshness**: `datasetFreshnessFromRaw`/`datasetFreshnessList` берут дату последнего подтверждённого патча из patches.json ПО УМОЛЧАНИЮ — auto-датасеты, чья мета старее патча 0.5.5e (06.10.2026), теперь 🔴 STALE даже моложе 30-дн порога; явный параметр переопределяет (null — отключить правило). MCP `poe2_data_freshness` получил опциональный `patch_version` (свежесть «на момент патча X», контракт additive, тулов по-прежнему 63) и строку «Известный патч» в сводке.
  - **Дедупликация реестров**: `scripts/refresh-data.mjs` мигрирован на core — собственный список мет (freshnessTargets №208) удалён, единственный реестр = core.freshness.FRESHNESS_DATASETS (9 датасетов); скрипт только оркестрирует (refresh-карта: refreshable-скрипт есть только у trade_stats; датасеты вне карты — регламент ручных экстракторов). Живого парсинга GGG-страниц нет нигде.
  - **--stale-only**: новый режим refresh-data.mjs — обновлять только датасеты со stale=true по вердикту core.freshness; полный режим по умолчанию НЕ изменился.
  - **Diff-отчёт (refresh не молчит)**: новый `core.datasetDiff` (`countRecords`/`snapshotDataset`/`diffDatasetSnapshots`/`formatDatasetDiff` — счётчики записей + fingerprint контента, НЕ полный дифф); refresh-data.mjs после каждого шага печатает «до → после» и пишет файл-отчёт в os.tmpdir(). Философия: никакое изменение фактов не проходит молча и без автокоммитов, только через явное принятие человеком.
  - Тесты: новый `packages/core/test/patches.test.ts` (реестр + knownPatchAt в freshness + datasetDiff). Note: fail-порог trade_stats в refresh-скрипте приведён к канону core: ранее 45 дн (локальный STALE_AFTER_DAYS №208), теперь auto-вердикт core (30 дн/патч).
- `tests/smoke/smoke_n236_map_prep.mjs`: счётчик MCP-тулов 62 → 63 (docs/SPEC_MAP_PREP.md §7 помечен).
- **Источники — kind/update-классификация + stale-логика freshness (№245, Этап 1 «источники + автообновление данных»)**:
  - `core.sources`: каждый источник реестра получил `kind` (datamined/community/official — происхождение данных) и `update` (auto/manual — как данные попадают в kit); новые источники `pob2` (Path of Building PoE2, локальный клон, MIT) и `repoe` (RePoE2 repoe-fork) — накопители наших датасетов; пороги протухания `STALE_DAYS_AUTO=30` / `STALE_DAYS_MANUAL=90` + правило «auto-данные старше известного патча = stale» (`sourceStaleness`).
  - **`core.freshness` (новый)**: реестр свежести 9 data-файлов (trade_stats, support_gems, gem_colors, recommended_supports, build_planner/map, passive_tree/layout, hideout/decor, maps/maps + waystone_mods от №234) — дата из меты (_meta/metadata/scraped_at), kind/update, schema_version/_meta.rev, возраст и stale-флаг; нет меты — честная пометка, не падение.
  - MCP `poe2_data_freshness`: пер-датасетная таблица перегнана на core.freshness — колонки источник/kind/update/дата/возраст/схема/состояние (🔴 STALE / ⚠ нет меты / ✅ свежий); `poe2_sources_list` показывает kind/update-строку каждого источника. Контракты тулов не менялись (только additive).
- **Stat-id-матчинг №246**: `matchStat`/`matchStatsBulk`/`matchStatsBulkResult` — сигнатуры расширены additive (`StatMatchInput` + `opts.strategy`), `buildIndex` → `buildCatalog` (Catalog byText+byId), `resetStatMatchingCaches` дополнительно сбрасывает кэш алиасов. Host-side (web/mcp/overlay) НЕ менялся; MCP-тулов по-прежнему ровно 63.
- **Simulacrum known-issues/open-questions → data-файл (№247, Этап 3)**: `packages/core/data/game/guides/simulacrum_facts.json` (`_meta {patch:'0.5.x', as_of, sources[]}`, `known_issues[]` c `report_dates[]`, `open_questions[] {question, check_condition, as_of}` — очередь перепроверки при патче, досье §7). `core.simulacrum`: `SIM_KNOWN_ISSUES` грузится из файла (статический JSON-импорт — виден и в Node, и в браузере; readFileSync дал бы пустой массив в web), экспортированы `SIM_OPEN_QUESTIONS`/`SIM_FACTS_META`/`parseSimulacrumFacts` (пустой/битый файл = честная отработка); markdown 'all' получил хвост «### ❓ Открытые вопросы (на перепроверку)»; MCP `poe2_simulacrum_guide` — опциональное `structured.open_questions` (контракт additive, тулов 63). Web-рендер не менялся — источник данных сменился прозрачно. Сами факты гайда (волны/боссы/лут/атлас) остаются в core — без дублей.

## [1.0.27] - 2026-10-09

Релиз объединяет волны №225–№227 (keybind-хвосты) и №234–№236 (новая фича «Map Prep Assistant» — советчик подготовки к картам). УТП фичи: офлайн-вердикт «этот waystone под ТВОИ резисты/EHP — качай/переролль», конкурентный контраст с Sidekick (regex без персонального совета) и poe2ref (без персонализации).

### Added
- **Map Prep Assistant №234–№236** (SPEC docs/SPEC_MAP_PREP.md):
  - Датасеты Этапа 1: data/game/maps/maps.json (135 waystone-карт из PoB2 WorldAreas.lua, MIT: пулы трэш-монстров per-map + боссы + 6 биом-групп) и waystone_mods.json (74 группы модов × 3 ступени); экстрактор scripts/build_map_prep_data.mjs (идемпотентный, локальный PoB2-клон, rev в _meta). Отклонения от SPEC честно зафиксированы: 135 карт (не ≥140), 3 ступени (не 4), area_level=65 базовый (тиры через endgame.waystoneAreaLevel).
  - **core.mapPrep** (mapThreat / mapPrepChecklist / mapPrepAdvice / requiredChaosRes): матчинг live-строк модов (canon: «-(7-8)%» == «minus (5 to 8)%»; построчный матч двухстрочных статов), каталог угроз по stat_text (Exposure → −maxRes, Smothering → recovery, Drought → фляги, resistant → монстр-резисты, элементные веса), вердикт-чеклист на базе ehp.identifyDefenseGaps + enemy-канона (boss +30% elem / pinnacle +50%); честная verified/unverified-дисциплина (пороги chaos — maxroll, помечены).
  - **MCP-тул №62 poe2_map_prep** (map / mods[] / tier / pob либо defensiveStats → threat + checks + advice-markdown; structured output; без билда — честная пометка, не пустые fail-чеки).
  - **Web-вкладка «🗺 Карты»** (поиск по 135 картам, тир T1–T16, вставка модов камня, вердикт по импортированному билду или ручным резистам, severity-бары, unverified-пометки видимы).
  - **Overlay**: блок «Вердикт карты» в панели «🗺 Эндгейм» (логика — только core, ноль дублирования; IPC mapprep:check).
  - e2e scripts/e2e-map-prep.mjs (13/13 живой CDP: datalist-135, exposure-матчинг, T12→76, консоль 0) + smoke tests/smoke/smoke_n236_map_prep.mjs (10/10).
- №225: профиль-ссылки poe.ninja через живой model API GET /poe2/api/profile/characters/{enc-acc}/{league}/{enc-char}/model/{v} (JSON charModel.pathOfBuildingExport); profileCharacterModelUrl() + fetchProfileCharacterCode() с percent-encode сегментов; чинит importBuild/char-sync оверлея.
- №226: KeybindAdvice.triggered — блок «бинд НЕ нужен» для Cast-on-X-сетапов (Ice Nova ← Cast on Block, Comet ← Cast on Critical и т.д.); data-driven отсев PoE2-саппортов по skillTypes; метки срабатывания по событию.
- №227: переработка SVG-схемы геймпада по численному аудиту геометрии (симметрия корпуса, D-pad/стик без пересечений, wrapLabel 1–2 строки + title-tooltip, единая нотация face-кнопок).

### Fixed
- mapPrep: дубли чеков резистов (identifyDefenseGaps повторял резист-гэпы, покрытые Exposure-скорректированными) — резист-гэпы отфильтрованы из мержа.
- mapPrep: extractNumbers больше не глотает внутренний дефис диапазона «(7-8)» как знак минуса — диапазоны в скобках всегда положительные; value приоритизирует живой ролл вставки над ступенью датасета.
- overlay emitted-JS: regex-сплит в шаблонной строке эмитил живой перевод строки вместо последовательности backslash-n → SyntaxError в рендерере (грабли №174 повторно); удвоен экранирующий слэш. Урон пойман смоками n113/n196b/smoke_renderer.

## [1.0.26] - 2026-10-08

Советчик раскладки навыков (SPEC `docs/SPEC_KEYBIND_ADVISOR.md`, №221–223): классификация активных гемов билда PoB и раскладка по слотам геймпада (Xbox/PS, 22 слота с L2-модификатором, эргономика по комментариям GGG) и клавиатуры (LMB/RMB/Q-W-E-R-T, режимы WASD/клик-мув); SVG-схемы контроллеров; «имба-атаки» — авто-определение главной атаки.

### Added
- **core.keybinds** (`adviseKeybinds`, `keybindsToMarkdown`): роли primary/burst/movement/buff/curse/aura; Spirit-блок (ауры/херальды/persistent — НЕ биндоваются, вывод с ценой резервации); системные слоты не перебиваются (dodge LB/L1, фляги D-pad, карта/портал L2+◀▶, A=Interact); `overrides`-пины ролей; пометки `unverified` для несверённого с игрой.
- **MCP-тул №61 `poe2_keybind_advisor`** (code/platform/movement_mode/overrides) — полная раскладка текстом.
- **Web-вкладка «🎮 Раскладка»**: вставка PoB share-кода/decoded XML, выбор платформы и режима движения, карточки слотов, Spirit-блок, ручные шаги выставления в игре.
- **SVG-визуал раскладки** (№223, `apps/web/src/keybindsVisual.ts`): геймпад Xbox/PS (face/триггеры/D-pad, L2-панель) и клавиатура (мышь/QWERT/WASD/Space/1–5) — кнопки окрашены стихией камня (`gem_colors.json`, второй браузерный датасет через `installBrowserDataset`).
- **«Имба-атаки»** (№223b/№223c): сортировка внутри роли — дэмедж-скиллы раньше утилити; при отсутствии main-группы каскад авто-повышения до primary: `FullDPSSkill` PoB (max DPS) → теговый fallback датасета (причина: `mainSocketGroup` PoB2 дефолтится в 1 → первая группа часто аура → RB/LMB пустовали). Точный предикат дэмеджа по 183 тегам: `Attack` | Damage-семейство (без HasReservation), гварды NOT_DMG; Spell-тег исключён как маркер (~41 ложный позитив снят: курсы/бафы/Empowers-мета/Guard-варкраи).
- **KEYBOARD_SYSTEM**: Weapon Set Swap (X) и Force Move (Mouse 3) — кандидаты дайджеста keymap.io, помечены unverified.
- **core.build.toXml: decoded XML passthrough** — сырой XML билда (начинающийся с `<PathOfBuilding`) больше не падает как «невалидный base64» (web/MCP принимают оба формата).
- **core.dataset.installBrowserDataset(rel, data)** (№222): хост-приложение устанавливает полную браузерную копию офлайн-датасета; web-вкладка «Раскладка» лениво fetch'ит `public/datasets/skill_gems_v2.json` (~550 КБ gzip; копия при build/dev скриптом `apps/web/scripts/copy-datasets.mjs`, в git не хранится).
- **getSkillGemDetails: `spiritReservationFlat`** — резервация Spirit persistent-гемов (PoE2) прокинута в уровни; раньше Spirit-стоимость терялась (cost отсутствует у HasReservation-гемов).
- **Ресёрч-дайджест раскладок сообщества** (КУБ-3): `_research/poe2_keybinds_community_digest.md` — дефолты PoE2 (keymap.io, verified), BindIQ-методика, reddit-паттерны.

### Fixed
- **PS-дубль слота** (№222): дубль-чек слотов сверялся в Xbox-нотации при выдаче PS-нотации — на PlayStation два навыка получали один слот. Сверка теперь в нотации платформы (тест уникальности добавлен).

### Verified
- core tsc ✓, vitest 188/188 ✓ (8 keybinds + 7 promote-тестов), core/mcp/overlay build ✓, MCP smoke 61 exit 0 ✓, web tsc+vite build ✓, живой CDP-прогон: xbox/ps/keyboard×wasd/click — без дублей, SVG строится, консоль чистая ✓; деплой на шару 192.168.0.200 (deploy-share --all + web dist), LAN preview 5173 = 200 ✓.

## [1.0.25] - 2026-10-04

Мелкий релиз качества: **орфографическая чистка русских строк UI** (волна 216, `7ea68a4`). Только тексты, без функциональных изменений.

### Fixed
- **«вайпоинт» единообразно**: унифицированы три варианта написания (вояпоинт/вэпоинт) в тултипах оверлея и web-чеклиста, выводе MCP-тула прокачки и комментариях core/docs.
- **Грамматика**: «Не распознано модов» → «Не распознаны моды» (панель прайса, оверлей).
- **Согласованность терминов**: «Поиск нод»/«Показать ноды» → «Поиск узлов»/«Показать узлы» (остальной UI пишет «узлы»); ключи RU→EN словаря оверлея обновлены синхронно.
- «Trial of the Sekhemas (лестница)» → «(лестница этажей)»; английские имена сущностей (gem/skill/асценданси) сохранены как канон.

Слэнг-канон kit («асценданси», «гира», «пиннакл», «саппорты», «Плитки смотрителя») не тронут.


## [1.0.24] - 2026-10-04

Главная фича релиза: **вкладка «Атлас» (Atlas Passive Tree) + калькулятор модификаторов** — полное дерево атласа, планирование очков и суммарная сводка выбранных умений атласа и дерева пассивок вместе.

### Added
- **Вкладка «Атлас»** (`625d5d7`, №215): SVG-карта древа атласа (537 узлов / 586 рёбер / 7 веток, данные RePoE Atlas.json 4.5.5.2, иконки poe2db CDN с фолбэком на кружки): pan/zoom/«Вписать», клик = взять/снять очко (аллокация смежно с корнем/взятыми, refund только свободных), счётчик 40 очков, поиск по узлам, шаринг `#a=<ids>` (сохраняет `#p=`), persist localStorage, тултипы, карточка узла. 38 icon-only узлов-мастери (AtlasGenericMastery) исключены как декоративные.
- **Калькулятор модификаторов** (`b1cdde0`, №215b): панель «Сводка взятых умений (N)» — агрегирует статы всех взятых узлов по нормализованному шаблону: одинаковые модификаторы стакаются («12% increased X ×3»), диапазоны «(A-B)%» суммируются по min/max, «+N» трактуется с сохранением знака, уникальные текстовые эффекты — списком со счётчиком. Обновляется на аллокацию/refund/restore/очистку.
- **Калькулятор дерева пассивок** (`96560ec`): та же панель в планировщике вкладки «Карты» — сводка статов узлов плана (включая узлы асценданси).
- **Кросс-вкладочная сводка** (`96560ec`): панели атласа и планировщика показывают ОБЪЕДИНЁННЫЙ список модификаторов (атлас + пассивки складываются вместе), заголовок с счётчиками «(Атлас: N + Дерево пассивок: M)»; общий модуль calcSummary.ts, publisher/subscriber без рекурсии.
- **Lazy-bootstrap + маркеры источников** (`fff83b2`): если вторая вкладка не открывалась, её план агрегируется прямо из localStorage (без потери полноты сводки); цветные точки-маркеры у каждой строки: золотая = атлас, синяя = дерево пассивок.

### Changed
- **Иконки узлов атласа уменьшены** (`cc12f34`): nodeR*2.7 → nodeR*2.2 по визуальному фидбеку; хит-круги узлов исправлены (перекрытие соседних узлов при клике).

### Fixed
- Клик-аллокация атласа: pointer capture перенаправлял click на svg — клики переведены на down/up-пару (dist ≤ 4px).


## [1.0.23] — 2026-10-04

Фокус релиза: **карта дерева по уровню игровых сайтов** — поиск узлов,
визуальный diff план ↔ PoB и игровой хаб-арт.

### Added
- **Поиск узлов** (`dc6b2ac`, №212): поле поиска на панели карты с
  дропдауном (имя + тип, ранжирование, max 30), горячая клавиша «/»
  (работает и на русской раскладке). Выбор результата центрует карту:
  WebGL — реальным API tree-react (`focus` + teal-кольцо), SVG — пан/зум
  + метка; mastery — кольцо без центровки.
- **ΔDiff план ↔ PoB** (`dc6b2ac`, №212): кнопка «Δ Diff» (при
  разобранном PoB-билде) + счётчики «не хватает X · лишних Y».
  Оранжевый = узлы PoB-билда, не взятые в план («добери кликом»);
  фиолетовый = узлы плана, которых нет в PoB. WebGL — легальный
  двухцветный канал `weaponSets` (без патчей библиотеки), SVG — метки,
  статус Δ в карточке узла в обоих видах.
- **Хаб-арт centreSprites** (`dc6b2ac`, №212): официальный арт хаба
  (резная рамка + вращающееся золотое кольцо + портрет активного класса)
  из официального же webp-экспорта GGG — 0 новых бинарников.
  Выключение `?hubart=0` (векторный фолбэк); битый ассет не ломает рендер.

### Changed
- e2e: интеграционный `scripts/e2e-wave212.mjs` (16/16) + регресс
  планировщика `e2e-planner.mjs` (19/19) — синтетика CDP, живые клики.

## [1.0.22] — 2026-10-04

Фокус релиза: **хайдоут-хаб, игровая WebGL-карта дерева и интерактивный
планищик** — дерево как в игре, клик-аллокация с PoB-семантикой pathing,
плюс официальный экспорт `*.build` по ссылкам.

### Added
- **Хайдоут-хаб** (`591e060`, №199–202): core.hideout
  (parse/summarize/classify/share-код/markdown), вкладка «Хайдоуты» в web
  (разбор .hideout, MTX-чекбоксы, canvas-мини-карта), 5 живых фикстур,
  e2e-hideout 15/15. Нативный PoE2-экспорт = POH-формат 1:1 (12 живых файлов
  владельца); decor.json x1.7 — 234 имени / 9 баз; SPEC генератора
  `docs/HIDEOUT_GENERATOR_SPEC.md` (buildHideout/rebaseHideout/substituteFree).
  Узоры Выборга/Карелии в web-скине: Олафова башня, ромбо-цепь käsivyynte,
  ёлочка tree-of-life, слепая аркада, ромбическая канва (inline SVG data-URI).
- **Интерактивный планировщик на карте дерева** (`e6c3495`, №209): клик по
  узлу в игровом WebGL-виде берёт/снимает очко с path-валидацией в
  `@poe2-toolkit/tree-core` (кратчайший путь от старта класса, отсечение
  осиротевших ветвей — семантика PoB); merge плана и подсветки PoB в одну
  сцену, persist localStorage `poe2k.plan`, шаринг `#p=<class>:<asc>:<ids>`
  в hash, бейдж «План: N», кнопки «Ссылка»/«Сброс», автостарт класса,
  Голубые метки `.mplan` в SVG-виде, статус узла в detail-карточке.
- **e2e планировщика** (`207cdb3`, №210): scripts/e2e-planner.mjs — living-клик
  по canvas с точной репликацией viewport, restore из `#p=hash`, сброс;
  ALL PASS 19/19; persist-on-restore — расшаренная ссылка пишет и localStorage.
- **MCP `poe2_export_build_planner`** (№208): конвертация билда PoB (share-код или ссылка pobb.in/poe.ninja) в официальный `*.build` Build Planner PoE2 (schema v1) для импорта в игре. Гир — из клир-текстов (уники — по имени, рарники — additional_text), честные warnings о непопавшем.
- **Per-dataset свежесть** (№208): `poe2_data_freshness` больше не слеп к отдельным датасетам — таблица дат/возраста всех офлайн-файлов (support_gems честно показывает 296 дн ⚠, pre-0.5); `scripts/refresh-data.mjs` — тот же реестр с политикой fail/warn; хук в `run_live_smoke_daily.bat` (не блокирует итог смока).
- **Импорт ссылок в web-UI** (№208): поле импорта билда принимает теперь и ссылки (pobb.in → /raw, poe.ninja/pob) через `core.build.toXml` (анти-HTML, таймаут) — раньше умирало на `decodeShareCode`.
### Fixed
- **Копирование план-ссылки** (`7a0b4d5`, №210+): кнопка «🔗 Ссылка» реально
  работает — полный каскад clipboard API → execCommand(copy) через скрытый
  textarea → честная надпись «скопируйте адрес из строки браузера»
  (раньше NotAllowedError молча съедался декоративным catch).
- **DPI-фикс прокси serve-dist** (`591e060`, №202): spawn(curl --ssl-no-revoke)
  + fetch-fallback + 3 ретрая — DPI-сеть душит сырой node:https (0/7) и
  undici-пул (~60%, отравленный keep-alive), curl 3/3; стало 8/8 по 200 за 0.65с.
- **P1 rejected-promise кэш** (№208, аудит web): сбой загрузки больше не прилипает в ленивых кэшах `treeGame/mount.ts` («Игровой вид» мёртв до F5) и `treeMap.ts` (dbPromise) — отклонённый promise сбрасывается, ретрай на следующем действии.
- **P1 resize-утечка** (№208): «Показать дерево» больше не копит window-resize-листенеры (detached-DOM) — AbortController, живёт один рендер.
- **P0 stripBraces в *.build** (№208): посторонние `{}` в тексте модов вырезаются перед `additional_text` — парсер игры использует скобы как делимитеры разметки Custom Text (донор: PoB2 BuildExportPoE2.lua:185).

- **`.gitattributes`** (`ff76d0a`, №202-bis): `*.hideout -text` — запрет EOL-подмены на checkout (нативные хайдоут-файлы PoE2 ломались нормализацией).

### Added (№204–207, ранее)
- **Миграция layout.json на официальный экспорт GGG** (№207): `scripts/build_tree_layout.mjs` регенерирует SVG-датасет вкладок «Карта/Дерево» из того же `export/data.json`, что питает WebGL (единый источник истины; было — PoB TreeData с другой системой координат). Узлов 5152 (SVG показывает именованные: 4912), рёбер 6069 (дуги 1603 по орбитам + прямые), иконки — через тот же manifest.json, позиции дисков асценданси — центроид+дельта в новых координатах. Эталон 28880: 148/148 узлов PoB ≡ GGG skill — совместимость билд-подсветки и treeMap сохранена; потеря визуала минимальна (2 ребра узла 30100 — GGG обнулил его имя; 1 self-loop отброшен).
- **SVG-подсветка билда** (№207): «⭐ Билд» теперь подсвечивает пассивки и в лёгком (SVG) виде — свечение + золотой контур (`applySvgBuild`, CSS `.mbuild`); состояние переживает переключение WebGL↔SVG.
- **Подсветка билда на игровом дереве** (№206): кнопка «⭐ Билд (N)» подсвечивает пассивки последнего разобранного PoB прямо на WebGL-карте (пройденные узлы/связи — «allocated»-фреймы и рельсы) через `allocation` tree-core. id PoB ≡ числовые id GGG — 148/148 на эталоне, конвертация не нужна. При первом открытии — автоматически; селекторы класса/асценданси синхронизируются билдом. ~~В SVG-фолбэке подсветка не поддерживается~~ (закрыто №207).
- **WebGL — режим по умолчанию вкладки «Карта»** (№205): карта открывается сразу в игровом виде (PixiJS поверх официального экспорта GGG); «🧭 Лёгкий вид (SVG)» — тумблер-фолбэк, при недоступности WebGL2/данных — авто-переход на SVG с сообщением.
- **Селектор асценданси** (№205): в SVG-режиме приглушает чужие ветки, в WebGL — переносит диск асценданси в хаб «как в игре» (`activeAscendancy` tree-react). Список — из GGG data.json (22 асценданси по 8 классам).
- **WebGL «Игровой вид» вкладки «Карта»** (№204): тумблер переключает SVG-рендер на PixiJS-рендер полного дерева (`@poe2-toolkit/tree-core`+`tree-react`, MIT) по официальному экспорту GGG (`grindinggear/poe2-skilltree-export`): 5153 узла текущего патча, игровой арт (иконки/фреймы/паттерны мастерств, покрытие манифест-ключей 100%), pan/zoom на GPU, клик по узлу — статы. SVG-режим остаётся лёгким фолбэком (гейт WebGL2, откат тем же тумблером). React+PixiJS изолированы в lazy-чанке `treegame` (~231 КБ gzip, только по тумблеру). Датасет `packages/core/data/game/passive_tree/export/` (data.json GGG + атласы frame/mastery + manifest.json, сборщик `_build_tree_manifest.mjs`).

## [1.0.21] — 2026-10-03

Фокус релиза: **защита от скама при покупке** — подозрительные листинги
видны сразу, и больше данных для точной оценки.

### Added
- **Скам-флаги листингов** (`7bcfe32`, №197, S10): локальная эвристика
  относительно рыночной медианы — «⚠ подозрительно дёшево» (≤ 25% медианы,
  классический price-bait) и «✖ дороже рынка» (≥ 4× медианы). Без сети,
  помечает, но НЕ скрывает листинги — решение за игроком. Срабатывает
  только при уверенной оценке (confidence exact/approx, медиана ≥ 5 chaos,
  известен курс валюты) — без ложных пометок на дешёвых предметах.
- dev: система скам-эвристик вынесена в чистую функцию
  `flagSuspiciousListings` (+7 тестов, vitest 160/160).

### Changed
- **Чанковый fetch trade2** (`7bcfe32`): официальный API отдаёт максимум
  10 листингов за запрос — ранее лимит выше 10 молча обрезался. Теперь
  выборка идёт чанками по 10; для оценки раров по статам выборка увеличена
  10 → 20 листингов (медиана по 10 шумная). Квота fetch у GGG отдельная
  от search — расход прежний по окнам.
- dev: смок `smoke_n197` +9 маркеров (fetch-чанки, флаги в core/UI).

## [1.0.20] — 2026-10-03

Фокус релиза: **S7-UI и стабильность данных** — прозрачность матчинга статов.

### Added
- **Баннер «⚠ N модов не распознано» в прайс-вью** (`58dca77`, №196-bis,
  S7-UI): core пробрасывает `unmatchedMods`/`statMatch` в
  `PriceCheckResult`; кнопка **«🔄 Обновить каталог»** (IPC
  `trade:reloadStats`) сбрасывает кэши stat-матчинга (live-мемоизация +
  negative-memo 5 мин) — свежий патч GGG лечится без релиза, следующий
  Ctrl+F1 идёт по живому каталогу. Батч-вью — сокращённый маркер.
- `scripts/deploy-share.mjs` (`npm run deploy:share`): деплой на шару
  игрового ПК без зависаний — preflight-доступность с таймаутом, копии
  под таймаутом, SHA256-сверка каждой записи; exit-коды 0/1/2
  (2 = шара недоступна, ничего не трогаем).
- `scripts/refresh-data.mjs` (`npm run refresh-data`): конвейер обновления
  офлайн-датасетов + отчёт свежести (порог 45 дней, паритет
  STALE_AFTER_MS statMatching).

### Changed
- Консолидация trade-дампов: `stats_snapshot.json` (853 КБ дубль) удалён,
  единый источник — `trade_stats.json` (8300 записей; сверено: строгое
  супер-множество старого снапшота).

### Fixed
- dev: `matchModsToStatFilters` возвращает `liveMatches` (диагностика UI);
  новых тестов +3 (vitest 153/153), смок `smoke_n196b` +9 проверок
  (22 смока ALL OK); CI зелёный на all-jobs.

## [1.0.19] — 2026-10-02

Фокус релиза: **гигиена данных и интерфейса** — T_DICT и кодировка.

- i18n: закрыты пропуски T_DICT, видимые в EN-режиме прайс-вью
  (Market/Sources/listings/median, approx./exact/rough) — `0183988`.
- fixed: лечение CP1251-mojibake в package-описаниях и шапке/описаниях
  MCP-тулов (артефакт PowerShell-bump без `-Encoding UTF8`) — `6f8ffd1`.
  Клиенты MCP снова видят читаемую кириллицу в описаниях poe2_*.
- build: make-portable дополнительно исключает dev-скрипты
  (`_extract_*.mjs`, `_smoke*`) из portable-архива — ранее утекали
  пути машины разработчика.

## [1.0.18] — 2026-10-01

Фокус релиза: **EN-локализация интерфейса панели оверлея** —
этапы 1–2 (`ad3196f`, `2f04e0e`). Владелец проекта отметил свадьбу
22.10.2026 — Kit остаётся бесплатным в любом случае.

### Added
- **Переключатель языка панели** (`ad3196f`, №160): настройка
  `lang: ru | en | auto` (auto = язык Windows), чипы RU/Auto/EN в
  настройках, применение через перезагрузку панели.
- **Механизм перевода**: словарь `T_DICT` RU→EN с длиннейшим
  сегментным сопоставлением, проход по DOM (текст/атрибуты,
  SCRIPT/STYLE исключены), `MutationObserver` для динамических
  рендеров (debounce 50 мс). Промах словаря = RU-фолбэк, ничего
  не ломается.
- **EN-хром всех вкладок** (`2f04e0e`, №161): заголовки, кнопки,
  статусы, подсказки, сегменты композитов (билд/импорт/камни/
  крафт/курс/генератор/пиннакл/квесты/дерево), слоты и чипы
  поиска нод. Verified по CDP: 607 → 479 RU-строк, остаток —
  intentionally RU (гайд-контент, см. ниже).

### Fixed
- `settings:get` возвращал урезанный объект (без lang/height/
  autoHeight/gemLang/theme/colors) — тема и gemLang визуально
  слетали в дефолт при каждом открытии настроек (№160).

### Known limitations
- Гайд-контент панелей (советы боссов, маршрут прокачки,
  слэнг-глоссарий, крафт-рецепты, советы саппортов) — только
  русский; RU-имена камней/валют управляются отдельно
  (`gemLang`). Полный перевод контента — в планах (B-дорожка).

## [1.0.17] — 2026-10-01

Фокус релиза: **конструктор комбо-связок, панель боссов, генератор
крафт-планов и живучесть прайсинга** — №126–№145, по логам живой
SSF-сессии (русский клиент, Forbidden Rites).

### Added
- **Панель боссов с таймером** (`4587b75`, №143; №143b `971bd22`):
  карточки боссов кампании (силы/слабости/фарм — maxroll act-1-3,
  верифицировано; канонические EN-имена `name_en`; +Граф Геонор —
  финал акта 1, ошибка «Канделмасс = финал» исправлена) и собственный
  босс-таймер: стопчотч входа в зону по живому логу, кнопки
  «🏆 Убит»/«💀 Смерть», лучшие времена по лиге.
- **🧬 Конструктор комбо-связок** (№139 `a401d70`, №141 `360e9fb`,
  №142 `8277840`): акт-фильтр камней + совместимые саппорты, слоты
  1..5 с подсветкой следующего, QR-кнопка «📋 Код импорта» →
  PoB-XML через nameSpec (кнопка всегда видна, №141-bis `6bd2215`);
  пресеты друга (Ball Lightning/Azmerian Wolf/Comet). Чанкированный
  gemdata-IPC (1343 акт + 680 саппортов офлайн).
- **Генератор целевых крафт-планов SSF** (`f8865e9`, №126):
  по предмету — план крафта с SSF-оценкой доступности.
- **Каталог крафт-рецептов** (№130 `f2851df`, №137 `c9c77b7`):
  CRAFT_RECIPES, Waystone-план, полные таблицы poe2db
  (эссенции/спец/сплавы/омены) + планы по пиннаклам.
- **Вкладки «💱 Курс» и «🧬 Билды»** (№135 `3cfaea3`, №136 `34c8c4a`):
  курсы валют по лигам (38 валют, RU+EN имена) и генератор билдов
  по ладдеру poe.ninja (meta по классу, локальные гемsetups).
- **Вкладка «📖 Слэнг» + окно «⚒ Крафт»** (`8703b1b`, №133/№134).
- **Окно ℹ у каждой функции панели** (`6b095e9`, №128);
  **DPS-блок в панели билда** (расчётный, `a9556d6`, №131);
  **кнопки прокрутки ▲/▼ + wheel-телеметрия** (`5d90aed`, №132).

### Fixed
- **Прайсинг слотов билда зависал надолго** (№145 `49b0dd9`): таймаут
  слота 45с → 25с (ядро держит бюджет 20с) — слот больше не вечно
  «крутится»; httpJson один ретрай transient-5xx через ту же
  очередь/лимитер (после 1.5с), 4xx/таймауты не ретраятся.
  Живой лог: HTTP 500 от trade2 на Sapphire/Gold Ring, fetch failed.
- **Колонка вкладок при 11+ вкладках** (№144 `4120834`): вертикальный
  скролл колонки, длинные подписи эллипсисом (профилактика выпирания).
- **RU Uncut-камни не прайсились** (№138 `d350af3`): trade2 давал
  400 на RU-имена — статические EN-базы Spirit/Skill/Support Uncut,
  плюс banded-тип `Uncut <K> Gem (Level N)` (№138q, `a401d70`).
- **Панель сама переключалась на Билд** (№138b `0537b8c`): onBuildUpdate
  больше не ворует активную вкладку (Currency → Build прыжок).
- **Прогресс прокачки** (№140 `8cc55de`): per-league персист
  visitedCodes — реальные done-статусы зон, ручной сброс.
- **Ввод текста** (№129 `e9f6730`, №113e-b `b4355f2`, `b4355f2`):
  ввод в move-режиме, кликабельный фильтр нод без клавиатуры;
  before-input-event гасил ВСЕ клавиши — починено.
- **Валюты двуязычно** (№138c `24bb50d`): RU-имена из обратного
  poe2db-словаря, capital letter.

## [1.0.16] — 2026-10-01

Фокус релиза: **UX панели по живым репортам SSF-сессии — навигация,
прокрутка, точность цен и ввод текста** (№103–№113e).

### Added
- **Боковая колонка вкладок** (`992c4f4`, №113): кнопки-вкладки
  вертикальной колонкой слева от панели — все вкладки видны без
  свёртки при scale 1.25.
- **Управление видимостью вкладок** (`992c4f4`, №113b): ⚙ → секция
  «Вкладки панели» с чекбоксами; скрытая вкладка деактивируется,
  функция остаётся на хоткеях; персист в overlay-settings.json
  («⚙» скрыть нельзя).
- **База знаний целевого крафта PoE2** (`docs/crafting_knowledge_base.md`):
  валюта/эссенции/омены/руны 0.5.5, методология «двух якорей»,
  расчёт Expected Exalts, инструменты (poe2db #ModifiersCalc,
  Craft of Exile ?game=poe2).

### Fixed
- **Ввод текста в полях оверлея** (`25d022a`, №113e): поиск нод и другие
  поля не принимали текст — окно создано focusable:false. Теперь фокус
  отдаётся окну только на focusin поля INPUT/TEXTAREA и возвращается
  игре на focusout (WASD в бою не теряется).
- **Прокрутка во всех панелях** (`d46c713`, №113d): «в некоторых окнах
  весь текст не посмотреть и не прокрутить вниз» — #lvlWrap/#gemsWrap
  имели px-max-height больше окна (низ срезался), Плитки/Пиннакл/Импорт
  вообще без скролла. Единый flex-паттерн (как у Билда) для всех врапов.
- **Watchlist-алерты на шуме цен** (`45439bc`, №113c): тост «0.0 → 0.0»
  на флуктуации рынка. Теперь алерт только при падении ≥10% от базовой
  (база при падении не двигается); адаптивная точность цен (3 знака
  <1 chaos, 2 знака ≥1, 1 знак ≥10) во всех ценовых UI.
- Float-сборки панели, hotkey-печать и прочие мелкие UX/DX-патчи цикла
  №103–№113 (см. журнал куба-5 по номерам).

## [1.0.15] — 2026-10-01

Фокус релиза: **живая SSF-сессия на игровом ПК (русский клиент,
Forbidden Rites): charSync, gem-check, телеметрия сессии и UX
импорта билда** — всё по логам друга, все патчи подтверждены вживую.

### Added
- **charSync — синхронизация гира персонажа** (`7bb6d35`, `7a0d41c`):
  слежение за PandarenDeepRover через poe.ninja-профиль, матчинг
  скопированных предметов со слотами билда (`build slot matched/bought`),
  сверка эталона PoB с фактическим гиром. Live: «совпало 11 (новых: 7)».
- **Gem-check в clipboard-watch** (`5d00059`): Ctrl+C по камню внутри
  игры → RU-имя распознаётся (offline-словарь 1020 камней) → «✓ есть в
  билде / ✗ не в билде».
- **Телеметрия сессии** (`68d5eff`): счётчики событий в диагностике
  (`priceCheck:*`, `buildImport:*`, `charSync:ok`, `buildPrice:failed`),
  сериализация аргументов лога, dedup логов асценданси-гида, хвост
  лога 400 строк, uptime + RSS.
- **RU-руны** (`54262ba`): имена рун из русского клиента идут в прайсинг.
- **Гиды прокачки по зонам PoB** (`91aa31d`).
- **Экраны прокачки №92/92-bis** (`4259039`, `b4feb82`): поинты
  атрибутов, асценданси-подсказки с core-хинтами.

### Fixed
- **Renderer-панель мертва (SyntaxError)** (`8003a0e`): сырой `\n` внутри
  JS-строки в HTML-шаблоне — экранирован; проверено script-смоком
  (`new Function`).
- **Медианы цен: chaos-медиана** (`03aa6b8`): смешанные валюты листингов
  конвертируются по курсам (full-lower keymap + trade2-алиасы), raw-median
  fallback.
- **White-базы стартера в прайсинге билда** (`97ae934`): отключены —
  каждая давала 45-с таймаут trade2. Плюс: роут poe.ninja-линка из
  Ctrl+F1 в импорт билда, `[DNT]`-токены срезаются из keystones.
- **Импорт билда, три слоя защиты** (`68d5eff`, `bf3fdec`):
  - не-предметный буфер в Ctrl+F1 → мгновенный отказ без 10-с ожидания
    словаря (`priceCheck:rejected:nonItem`, 0–1 мс даже на 123 932 симв.);
  - item-текст в Ctrl+F3 → подсказка «Прайс — Ctrl+F1»;
  - не-PoB буфер в Ctrl+F3 (не base64, не JSON) → мгновенная
    человеческая подсказка вместо крипто-ошибки base64
    (`buildImport:rejected:notCode`).
- **Вкладка «Импорт»** (`68d5eff`): после Ctrl+F3 оверлей остаётся на
  экране импорта с результатом, без прыжка на панель билда.
- **TZ-нормализация времён** (`142c88e`): единая метка времени в логах.

### Verified live
- Друг (v1.0.15-код, SHA `EDF7A712`): рестарт 01:07 UTC, init чисто,
  build-state поднят, `rejected:nonItem` на 21-символьном буфере — 1 мс.
- Полный конвейер импорта PoB-кода ×4: 12 184 симв. → 19 слотов, дерево
  133/152 (keystones=1, notables=34), advice/estimate/gem-setups/meta —
  без ошибок.

## [1.0.14] — 2026-09-30

Фокус релиза: **живой тест v1.0.13 и два UX/корректность-фикса**
по обратной связи с игрового ПК (русский клиент, scale 1.25).

### Fixed
- **RU→EN словарь: фолд «й→и»** (`2ebde93`): poe2db хранит RU-имена
  с «и» на месте «й» («велик**ии** флакон жизни», «зате**и**ливые
  перчатки») — lookup с честного игрового «великий»/«затейливые»
  промахивался → trade2 400 «Unknown item base type». `normName`
  теперь сворачивает обе стороны одинаково (0 коллизий ключей на
  живом словаре 1779 баз).
- **RU→EN словарь: срез аффикс-префиксов** (`2ebde93`): у магических
  предметов имя = префикс + база («Крепкая Жертвенная мантия») —
  префикс уходил в trade-запрос. При промахе точного ключа `toEn`
  срезает ведущие слова (≤3) и находит чистую базу
  (Sacrificial Mantle / Colossal Life Flask / Intricate Gloves).
- **Панель настроек: sticky-подвал кнопок** (`e1d8f9c`): при scale 1.25
  контент выше окна 480px — кнопки «Сохранить»/«Сбросить клавиши»
  тонули в скролле. Теперь `.set-actions` всегда прижаты к низу
  видимой области; контент уезжает под них чисто (фон + тень).

### Verified live
- Разбор диагностики с игрового ПК (21:27Z): оверлей v1.0.13 полноценно
  работает после №73-фикса — init, билд 13 слотов, дерево 128/128,
  7 хоткеев, вкладки, автопрайс clipboard-watch, watchlist-алерты.
- После фикса: «Неразбавленный Великий флакон жизни» → `Colossal
  Life Flask`, цена найдена (10 листингов), watchlist-алерт сработал.

## [1.0.13] — 2026-09-30

Фокус релиза: **интерактивный UI оверлея + «глаза» AI-агента через MCP**
— вкладки, hover-подсветка, прайс-группы с chaos-конверсией, библиотека
источников и чтение живого состояния оверлея.

### Added
- **Вкладки панели билда** (`67b6904`): блоки панели открываются по клику
  вкладки, дублируя хоткеи через единый IPC `panel:open`; высота панели
  стабильна (без «прыжков» при открывании блоков).
- **Hover-интерактив** (`67b6904`): подсветка строк при наведении, курсор-
  обратная связь во всех списках панели.
- **Вкладка «💎 Камни»** (`67b6904`): локальный чек-лист сетапов билда
  (без IPC — данные уже в payload).
- **Прайс-чек: группы листингов по валюте** (`67b6904`): cmpbar-полоски
  соотношения внутри группы, номинальная медиана группы + «≈X chaos»
  в заголовке (конверсия курсов — core `attachListingChaos`).
- **Библиотека источников** (`64cdbf5`): курируемый реестр 11 источников
  в core (`sources.ts`) с host-guard (произвольный fetch невозможен by
  design), единый троттл/UA; новые MCP-туры `poe2_sources_list`,
  `poe2_sources_fetch` + гайд агенту с 4-уровневым порядком добора данных.
- **«Глаза» агента на игровой ПК — MCP-туру `poe2_overlay_state` /
  `poe2_overlay_gaps`** (`64cdbf5`): чтение userData-файлов оверлея
  (лига, watchlist, built-state, settings, лог) и автодиагностика пробелов
  (непоцененные слоты, отсутствие дерева/gemSetups, watchlist без цен,
  невыбранная лига) с закрывающим тулом на каждую дыру.
- `start-mcp.bat` (`39b6b73`): лаунчер MCP-сервера для игрового ПК —
  проверка Node, portable-режим, снипеты конфигов OpenCode/Claude Desktop.

### Fixed
- **Self-logging лаунчер** (`399a5a9`): `start-mcp.bat` при запуске с шары
  мог закрыться до вывода (cmd не умеет `cd` в UNC и глотал ошибки) —
  теперь `pushd` мапит UNC, весь вывод пишется в `start-mcp-log.txt`
  рядом с батником, `pause` гарантирован, коды выхода 0–5.
- Smoke-строка MCP на английском (`4f899ae`): на консолях с OEM-кодировкой
  русский текст показывался «кашей».
- **Краш оверлея при загрузке на игровом ПК** (№73, deploy-fix, не в git):
  в `node_modules\@poe2-kit\core` не было `package.json` → Electron падал
  в `legacyMainResolve`. Правило деплоя: вложенная копия core = dist +
  data + **package.json**.

## [1.0.12] — 2026-09-29

(секция добавлена ретроспективно в 1.0.13; сам релиз — коммит `edd1ab2`.)

- **Цвета камней v2** (`58`): правило цвета = primary-атрибут по данным
  `Gems.lua` PathOfBuilding-PoE2 (reqStr/reqDex/reqInt на каждый камень),
  валидация против poe2db-карты. Активные камни Monk от poe2db без цвета
  теперь красятся корректно.

## [1.0.11] — 2026-09-29

(секция добавлена ретроспективно в 1.0.13; сам релиз — тег на `34fb5b6`.)

- **Rename-map 0.5** (`c8a3dec`): карта переименований камней волны 0.5 —
  старые имена гейма (например «Martial Tempo») резолвятся к актуальным.
- **Помощник по пассивному дереву в оверлее** (`5788a93`): живое дерево
  PoE2 не экспортирует — источник = PoB-импорт `<Tree><Spec nodes=...>`.
- **Оптимизированный PoB-декодер** (`4907041`, `packages/core/src/pobcode.ts`):
  один проход base64→Uint8Array, инфлейт только лучшего кандидата (вместо
  round-trip deflate-9 на каждого).

## [1.0.10] — 2026-09-29

Мелкий релиз: **русские имена саппортов в подсказках** — там, где они были
английскими без причины.

### Fixed
- **RU-лукап саппортов** (`cf92f17`): три скрытые причины EN-фолбэков —
  (1) словарь poe2db хранит имена с тирами («Precision I»), а билды/мета
  пишут «Precision» — теперь цепочка «точное → база → тир I → тир II»;
  (2) слаги poe2db percent-encoded (`Ois%C3%ADns_Oath` = «Клятва Исина»)
  не декодировались при генерации словаря;
  (3) диакритика в именах не сворачивалась при сопоставлении.
  Не переведённых саппортов стало меньше: 47 → 33 в эталонном слое.
  ⚠️ Оставшиеся 33 — старые имена гейма до волны переименований 0.5
  (например «Martial Tempo»): требуют карты переименований по данным poe2db,
  будут закрыты в следующем релизе.

## [1.0.9] — 2026-09-29

Фокус релиза: **подсказки саппортов прямо в игре** — от «какой камень вообще
ставить» к «эталон меты 0.5.5 / базовые рекомендации poe2db» за один Ctrl+C.

### Added
- **Чек-лист камней билда** (`915fa64`): Ctrl+C по камню умений в игре отмечает
  его ✅ в панели билда (сопоставление с сетапами импортированного PoB-билда,
  вердикт «есть в билде / не в билде», уровень камня и «с камня» фиксируются).
- **Рекомендуемые саппорты камня** (`0d78241`, `3a007a5`) — трёхслойная схема:
  1. **«⚡ эталон» меты 0.5.5** — кураторский датасет из PoB-гайдов Maxroll
     (`meta_supports.json`: 47 скиллов, 55 записей — Ice Strike Invoker,
     Glacial Lance, Permafrost, Poisonburst Pathfinder/Acolyte, Minion Lich и
     др.), провениранс — PoB-XML + planner-эмбеды;
  2. **«базово»** — poe2db Recommended Support Gems, ранги 1–5
     (`recommended_supports.json`: 381 из 407 активных камней, офлайн, RU+EN);
  3. live-fetch poe2db, если офлайн-датасета нет.
  Вызов: Ctrl+C по камню в окне умений (G) → блок в панели оценки. RU-имена —
  офлайн-словарь 1020 камней (`gemsRuEn.ts`); выбор языка имён RU/EN — Ctrl+F6.
- **MCP `poe2_build_summary`**: полный состав всех групп гема (имена + уровни,
  раньше — только счётчик).
- `buildGemSetups` (core) принимает сырой PoB-XML, не только share-code.

### Fixed
- **Крит: копия камня уходила в прайс-чек (HTTP 400 «Unknown item name») вместо
  гем-чека** (`6b76b6b`): сплиттер буфера выбрасывал строку «Класс предмета:»
  (она стоит перед «Редкость:», а якорь групп — Редкость), parseGemText не видел
  класс. Баг был во всех сборках с чек-листом.
- RU⇄EN-словарь: добавлен класс Флаконы (`d071020`) — базы флаконов не
  переводились → trade2 400.
- Leveling-сводка: фолбэк на зону+areaLevel (`71f46c6`) — PoE2-клиент не пишет
  level_up в Client.txt.
- Оверлей не терялся за границами экрана при непривязанном окне (`822a574`).
- Настройки панели применяются сразу по клику, не только после «Сохранить»
  (`b51bdba`); UX-оформление в стиле PoE2-HUD (`c6a0ae3`, `95fdbc4`).

## [1.0.8] — 2026-09-28

### Added
- **Карта дерева: пер-класс фоны** — 8 официальных листов GGG
  (`background-<class>.webp`, экспорт `grindinggear/poe2-skilltree-export`):
  фоны асценданси-кластеров на абсолютных координатах экспорта (Class1..N),
  базовый фон класса — на стартовом узле (в экспорте x/y=0). Слой под рёбрами,
  полупрозрачный, гасится фильтром классов вместе с деревом.
- **Mastery-узлы: иконки** — 368 из 369 mastery-колёс получили кадр
  `MasteryBlank` из официального спрайта (в экспорте нет групповых иконок
  `MasteryGroup*` — используется игровая «пустая» заглушка). Оставшийся круг —
  «Zarokh's Gift» (jewel-сокет, `icon` пуст в экспорте — корректно).

### Changed
- `layout.json`: `metadata.classBgs` (кадры/позиции фонов), `node.ic` у mastery.
  Покрытие иконками: 4902/4903.

## [1.0.7] — 2026-09-28

### Added
- **Карта дерева: игровые иконки узлов из официального экспорта GGG**
  (`grindinggear/poe2-skilltree-export`, спрайт-лист `skills.webp`) — 4534 из
  4903 узлов получили иконки «как в игре» (369 mastery-узлов остаются кружками —
  в этом спрайте их иконок нет); 660 уникальных кадров, легально, без CDN poe2db.
- **Стартовые кольца классов** — `group-background.webp` (`startNode:MainCircle`)
  под шестью базовыми классами, как в игре.
- Блоку «О проекте · Дисклеймер» добавлена секция о карте дерева (данные,
  источник, внешний планировщик), дата/версия актуализированы.

### Fixed
- **Клик по узлу на карте** — три независимых бага: (1) SVG `<use>` hit-тестирует
  только закрашенные пиксели спрайта → прозрачный паддинг иконки проваливал
  клик; (2) стартовые кольца перехватывали клики (теперь `pointer-events:none`);
  (3) на дальнем зуме иконка < 1 px экрана → попадание мышью невозможно.
  Фикс: невидимые hit-круги поверх узлов с гарантированным минимальным экранным
  радиусом 6 px на любом зуме.
### Changed
- **Карта дерева: читаемость на дальнем зуме** — раньше мировая толщина линий
  (2.2 юнита) на fit-зуме превращалась в субпиксельную кашу, а иконки мирового
  размера (68/98/136 юнитов) перекрывали соседей (промежутки 32-42 юнита).
  Теперь: линии — экранные 1 px (vector-effect: non-scaling-stroke),
  прозрачность 0.42 (асценданси-рёбра 0.62); контурные подложки — 1.25 px
  non-scaling; иконки — кламп размера max(мировой, мин. 4/5/7 px экрана по
  типу узла), как у poe2db. Подписи notable (983 шт.) показываются только на
  близком зуме (иконка >= ~12 px экрана), шрифт экранный 13 px на любом зуме.
- **Фильтр по классу на карте** не работал визуально: CSS-правило
  opacity .medge перекрывало presentation-атрибут — теперь inline style,
  прочие классы гаснут (5771/5801 рёбер).

## [1.0.6] — 2026-09-28

### Changed
- **Карта дерева: кросс-орбитальные связи тоже дугами** — порт второго правила
  веб-рендера poe2db (`drawLines`): связь с `orbit != 0` рисуется дугой радиуса
  `orbitRadii[|orbit|]` (sweep по знаку), а не прямой. Дуг в рендере
  1460 → 2857 (same-orbit 1460 + cross-orbit 1397) при тех же 5823 рёбрах —
  визуальная разница с игровым видом закрыта (у poe2db дуг 2989, остаток —
  рёбра между асценданси, которые мы сознательно показываем прямыми).

## [1.0.5] — 2026-09-28

### Added
- **Карта дерева пассивок «как в игре» (web, вкладка «Карта»):** новый датасет
  `layout.json` (PoB2 TreeData 0_5: 4903 узла, 5823 связи, стартовые точки классов
  и асценданси, включая Druid-ветки) с игровой геометрией (группы+орбиты).
  Рёбра-дуги по орбитам (как в игре / poe2db: SVG path A, 1460 дуг) + прямые
  связи; pan/zoom, фильтр по классу, клик по узлу → статы, кнопка-ссылка на
  внешний планировщик poe2db.tw (прямое iframe-встраивание запрещено их
  `X-Frame-Options: SAMEORIGIN`). Вкладка «Дерево» (взятые узлы билда) — те же
  актуальные координаты: билд 28880 рисует 128 узлов (было 125).
### Fixed
- **Portable-сервер без реверс-прокси:** в portable-zip все живые запросы
  (poe.ninja / poe2scout / trade2) уходили в SPA-фолбэк — `serve-dist.mjs`
  получил чистый node-прокси `/proxy/*` (без зависимостей).
- **Браузерный краш POST trade2:** расчёт ключа кэша `cachedPostJson` требовал
  node:crypto — в браузере это null. Добавлен pure-JS cyrb53-fallback.
- **Таймаут прайс-чека trade2:** POST /search выполняется ~15 с и резался
  дефолтными 10 с — для /search и /fetch задано `timeoutMs: 30000`

## [1.0.4] — 2026-09-28

### Added
- **Optimize-этап 1: read-only аудит билда** (ТЗ `docs/SPEC_OPTIMIZE_TOOLS.md`): новый
  `core.optimize` + 3 MCP-тула (48→51):
  `poe2_evaluate_build` — билд против числовых целей (DPS/EHP/резисты/Spirit), verdict
  pass/fail/unknown + разрыв; `poe2_rank_levers` — рычаги апгрейда по ΔEHP (computed:
  пересчёт канонических слоёв ehp.ts) и ΔDPS-оценке (estimated: оружие, линейная
  арифметика); `poe2_pinnacle_check` — чек-лист готовности к эндгейму против табличных
  статов босса (резисты ≥ 75, chaos ≥ 0 или CI-иммунитет, EHP-порог ×N ударов,
  устойчивость к Heavy Stun через stun.ts). Инвариант ТЗ: каждое число помечено
  `computed:`/`estimated:`, фиксированный набор рычагов (без комбинаторного перебора),
  support-множители и passives-роутер осознанно НЕ ранжируются (нет данных — этап 3).
- **Сессии игры + реальные имена зон в лог-парсере** (`core.log`): PLAY-сессии по
  границам `***** LOG FILE OPENING *****` (`ClientGameState.sessions`);
  событие `[SCENE] Set Source` — настоящее имя зоны из лога перезаписывает
  табличное `ZONE_NAMES` (дописывает зоны, которых нет в таблице).
  Паритет с sergeyklay services-logfile.ts закрыт полностью.
- **Базовые пулы PoE2 — канон PoB2** (`core.resources` + тул `poe2_base_pools`):
  life = 12·lvl+16, mana = 4·lvl+30, реген маны 4%/с, ES без базы от уровня.
  ⚠️ Сверка с Hivemind resource_calculator.py показала его PoE1-legacy
  (life/str, mana/int, сдвиг на 12/4) — отвергнуто, канон выверен по исходникам
  PathOfBuilding-PoE2 (CalcSetup.lua:954-956, ModStore.lua:442). MCP 47→48.
- **ТЗ на optimize-тулы** (`docs/SPEC_OPTIMIZE_TOOLS.md`): перенос приёмов
  MaxWilk poe2-build-mcp (инвариант «число — только computed/estimated»,
  verify-before-present, ограничение перебора); этапы 1-3.
- **Автопрайс-чек из буфера (overlay, opt-in):** слежение 500мс с дедупом
  (приём ExileOracle clipboard-monitor) — новые предметы проверяются без
  Ctrl+F1. Выключено по умолчанию (приватность); тумблер в Ctrl+F6,
  срабатывает только на клир-текст с «Rarity:/Редкость:», busy-защита,
  включение не триггерит проверку старого буфера.
- **Ярлыки состояния в парсере** (`core.parse`): `corrupted / mirrored /
  unidentified` (edge-cases из ExileOracle parser-item-text; EN-клиент,
  ярлыки не попадают в моды). Поля `ParsedItem.corrupted/mirrored/unidentified`.
- **Сверка stun-калькулятора с Hivemind stun_calculator.py:** формулы
  совпали (порядок модификаторов, пороги 15/50/100, Crushing Blow).
  Выровнен edge: при `immuneToStun` метр больше не мутирует (паритет
  с первоисточником — без hitsReceived++ и ложного конечного hits).

### Added (previous)
- **OAuth 2.1 (PKCE) вход в GGG** (`core.oauth`): доступ к официальному
  аккаунтному API `api.pathofexile.com` realm poe2 — список персонажей
  и полный снапшот выбранного (экипировка, инвентарь, пассивки) без
  копипасты из игры. Токены локально (`~/.poe2-kit/ggg-oauth.json`, 0600),
  автопродление по refresh, вход через локальный callback
  `http://127.0.0.1:8080/callback`. Требует `POE2K_GGG_CLIENT_ID`
  (регистрация приложения GGG; без него — честный отказ, остальной Kit
  не затронут). Стэш-API PoE2 у GGG не существует (PoE1 only) — стэш-тулов
  нет и не делаем.
- MCP-инструменты: `poe2_oauth_login`, `poe2_oauth_status`,
  `poe2_oauth_logout`, `poe2_characters`, `poe2_character_get`
  (42 → 47 тулов).
- Офлайн-смоук OAuth: PKCE/state/URL, хранилище токенов, 401 → refresh →
  повтор (мок fetch), валидация имени персонажа на границе (path-injection).

## [1.0.3] — 2026-09-28

### Added
- **statdesc-рендерер** (`@poe2-kit/core` `core.statdesc`): текст игрового
  стата по stat_id + значению — диапазоны `#`/`N`/`a|b`/`!N`, 31+ handler-
  конверсий (negate, per_minute_to_per_second и др.), теги `[A|B]`,
  fail-safe null на неизвестном stat_id. `normalizeStatPattern` /
  `findStatIdByPattern` — поиск по нормализованному тексту.
- **Оффлайн-снапшот каталога trade2** (`core.tradeSnapshot` +
  `data/game/trade/stats_snapshot.json`, 8299 статов): матчинг модов
  предмета → stat-id работает и без сети / при смене схемы после патча.
  Цепочка фолбэков: живой каталог → снапшот → learned.
- **Динамический rate-limit-клиент GGG** (http.ts): уважение заголовкам
  `X-Rate-Limit-Ip/Account` + `-State` (все правила), ожидание до
  освобождения квоты, при 429 — пауза по `Retry-After`/бан-счётчикам и
  повтор ≤2 раз. Действует на все запросы trade2/прайс-чек пачек.
- **Валидация community-вкладов** (`merge-contributions.mjs`): каждый
  предложенный stat_id↔шаблон сверяется с датамайном и снапшотом trade2;
  жёсткий конфликт «id есть с другим текстом» ловится в отчёте.
- **Headless-PoB2 оракул в CI SourceCraft** (`.sourcecraft/ci.yaml` +
  `oracle/`): настоящий движок PoB2 без GUI, 5 сценариев против golden
  (tolerance 1e-4), еженедельный cron + при изменениях `oracle/**`.
  Ловит дрейф формул/данных PoB2 до релиза.

## [1.0.2] — 2026-09-27

### Added
- **Оверлей: «осторожный режим»** — галка «Привязка к окну игры» в панели
  Ctrl+F6 (`bindWindow`, default on). Выключена = ни одного вызова user32.dll:
  оверлей стоит в углу рабочей области экрана (двигается Ctrl+F5), всегда
  видим, не следует за окном игры и не прячется при alt-tab.
- `loadSettings` теперь BOM-толерантен: файл, записанный PowerShell
  (`Set-Content -Encoding UTF8` = UTF-8 с BOM), больше не роняет чтение
  настроек в тихие дефолты.
- Дисклеймер ToS GGG: разделы «Правила использования» в README (RU/EN),
  строка в панели настроек оверлея, фиксация «no automation / read-only FFI»
  в SECURITY.md.
- CHANGELOG.md.

### Data
- base_items: baseline бандла перегенерирован до патча 0.5.5 (5382 → 5496 записей,
  +114 новых баз; game build 4.5.5.2, снапшот repoe-fork 11.09). Остальные датасеты
  (skill_gems, stat_descriptions, passive_tree, ascendancies) — патч 0.5 до
  лицензионной re-extraction. `data_revision` 12 → 13.
- `POE2K_LEARN_SOURCE`: записи журнала обучения теперь несут метку источника
  (`overlay` / `mcp`), внешний env не перетирается.

## [1.0.1] — 2026-09-26

### Added
- **Portable-сборка** `poe2-kit-portable-1.0.1-win64.zip` (17 МБ): путь без
  Node.js/npm — `start-overlay.bat` сам скачивает Electron при первом старте
  (github → фолбэк npmmirror). Режим `--full` (~190 МБ) — для своих ПК.
  `start-web.bat` раздаёт production-сборку через `serve-dist.mjs`.
- Оверлей: панель Ctrl+F6 — галка «Журнал обучения» и кнопка
  «📤 Поделиться предметами» (вклад без консоли).
- `README.en.md` (English Quick Start).

### Fixed
- Монорепо: `@poe2-kit/core` в apps/* пинился `"0.1.0"` → падение 404 при
  установке (теперь `*`); electron перенесён в prod-зависимости оверлея
  (иначе вырезался из portable `--omit=dev`); typescript — в devDeps core.

## [1.0.0] — 2026-09-26

Первый публичный релиз. MIT, публичное распространение через SourceCraft.

### Added
- **Community learning (opt-in):** журнал обучения (`POE2K_LEARN=1`,
  `~/.poe2-kit/learn/items.jsonl` — только структура предмета, без
  персонажа/аккаунта); `npm run contribute-items` — JSON-дайджест для issue;
  `merge-contributions` — строгий валидатор мейнтейнера.
- **Библиотека выученных статов** `stat_text_map.json` (3711 stat-id ↔ шаблон,
  засеяно живым trade2 `/data/stats`): фолбэк-матчинг модов — прайс-чек раров
  не падает при смене схемы после патча.
- `poe2_build_guide` — скелет 9-секционного гайда из проверяемых данных
  (MCP-тулы: 41 → 42).
- Документация: README — раздел «MCP-инструменты (42)» с примерами всех
  тулов и «Как что считается»; `ASSISTANT_GUIDE.md` — шпаргалка для
  ИИ-ассистентов.
- Оверлей: полная карта дерева пассивок в вебе; чек-лист прокачки
  (localStorage по лиге); сравнение с топ-лестницей класса; вставка предмета
  из буфера в вебе; диагностика (Кнопка «📋 Отправить диагностику» — хвост
  лога + конфиг в буфер/файл); watchlist-алерты; пакетный прайс-чек;
  HiDPI-лог.
- Live-смоки против живых API (poe.ninja / trade2 / poe2scout) —
  ежесуточно, Windows Task Scheduler (хост SourceCraft не исполняет
  GitHub Actions).
- Релиз-файлы: LICENSE (MIT), SECURITY.md (вклады — только данные),
  CONTRIBUTING.md.

## До 1.0.0 (dev-история)

P0/P1/P2-этапы разработки (декод PoB, прайс-чек, дерево пассивок,
MCP-сервер, оверлей, веб) — детально в `WORK_LOG.md` и `docs/WORK_SUMMARY.md`.
