/**
 * UI-связка веб-приложения PoE2 Kit c ядром @poe2-kit/core.
 * Все данные — только бесплатные публичные API.
 */
import {
  core,
  KNOWN_LEAGUES,
  type League,
} from '@poe2-kit/core';
import { renderTreeMap } from './treeMap';
import { renderSupportsAdvice } from './supports';

export { core, KNOWN_LEAGUES };

const LEAGUE_KEY = 'poe2k.league';

// Сохранённая пользователем лига (если есть), иначе null → определяем актуальную.
function savedLeague(): string | null {
  try {
    const saved = localStorage.getItem(LEAGUE_KEY);
    return saved || null;
  } catch {
    return null;
  }
}

let activeLeague: string | null = savedLeague();

/**
 * Активная лига по умолчанию — актуальная текущая из poe2scout.
 * Вызывается один раз после старта: если пользователь не выбирал лигу, берём
 * актуальную и фиксируем её как активную (а не устаревший KNOWN_LEAGUES[0]).
 */
export async function initActiveLeague(): Promise<string> {
  if (!activeLeague) {
    try {
      activeLeague = await core.trade.currentDefaultLeague();
    } catch {
      activeLeague = null;
    }
    if (activeLeague) core.trade.setLeague(activeLeague);
  }
  return activeLeague ?? '';
}

/** Загрузить актуальный список лиг из poe2scout. */
export async function loadLeagueList(): Promise<League[]> {
  const list = await core.trade.fetchLeagues();
  if (list?.length) return list;
  return KNOWN_LEAGUES;
}

/** Установить выбранную лигу (также сохраняется в localStorage). */
export function selectLeague(id: string | null): void {
  if (id) {
    activeLeague = id.trim();
    core.trade.setLeague(activeLeague);
    try {
      localStorage.setItem(LEAGUE_KEY, activeLeague);
    } catch {
      /* ignore */
    }
  } else {
    // Сброс на «по умолчанию» — актуальную лигу определяем асинхронно.
    activeLeague = null;
    try {
      localStorage.removeItem(LEAGUE_KEY);
    } catch {
      /* ignore */
    }
    void initActiveLeague();
  }
}

/** Получить активную лигу (имя/id). */
export function getActiveLeague(): string {
  return activeLeague ?? '';
}

/** Принудительно обновить кэш данных выбранной лиги (курсы/цены). */
export function refreshLeagueData(): void {
  core.trade.invalidateLeagues();
  core.trade.clearRatesCache();
  core.trade.clearScoutCache();
  setStatus(`Список лиг и кэш «${activeLeague}» обновлены.`);
}

// Браузер блокирует прямые запросы к poe.ninja/poe2scout/trade из-за CORS.
// Vite (dev/preview) настроен на реверс-прокси; переписываем абсолютные URL на
// относительные пути через тот же хост. В Node (MCP/оверлей) это не нужно.
if (typeof window !== 'undefined') {
  // Относительные префиксы (без ведущего слэша) — липпка работает и из корня, и из подпапки
  // (/poe2kit/). В dev/preview это те же пути, что проксирует Vite.
  core.http.setProxyBaseMap({
    'poe.ninja': 'proxy/poeninja',
    'poe2scout.com': 'proxy/scout',
    'pathofexile.com': 'proxy/trade',
    'repoe-fork.github.io': 'proxy/repower',
  });
}

export function setStatus(msg: string): void {
  const el = document.querySelector('#status-text');
  if (el) el.textContent = msg;
}

const AI_SETTINGS_KEY = 'poe2k.ai.settings';

export interface AISettings {
  base: string;
  key: string;
  model: string;
}

/** Загрузить настройки ИИ из localStorage (со значениями по умолчанию). */
export function loadAISettings(): AISettings {
  const dflt: AISettings = { base: '', key: '', model: '' };
  try {
    const raw = localStorage.getItem(AI_SETTINGS_KEY);
    if (raw) return { ...dflt, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return dflt;
}

/** Сохранить настройки ИИ. */
export function saveAISettings(s: AISettings): void {
  try {
    localStorage.setItem(AI_SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

type ChatMsg = { role: 'system' | 'user' | 'assistant'; content: string };

let _chatHistory: ChatMsg[] = [];

export async function sendAIMessage(text: string, context?: Record<string, unknown>): Promise<void> {
  const el = out('out-ai');
  const settings = loadAISettings();
  if (!settings.base || !settings.model) {
    _chatHistory.push({ role: 'user', content: text });
    _chatHistory.push({
      role: 'assistant',
      content: 'ИИ-модель не настроена (нужен базовый URL OpenAI-совместимого эндпоинта и модель). Пока дам встроенные советы Ice Strike Monk:\n\n' + core.ai.iceStrikeMonkAdvice(context),
    });
    _renderChat();
    setStatus('ИИ не настроен — встроенные советы.');
    return;
  }
  if (!text?.trim()) {
    el.innerHTML = '<p class="err">Введи вопрос.</p>';
    return;
  }

  _chatHistory.push({ role: 'user', content: text });
  _renderChat();
  setStatus('Запрос к ИИ…');
  try {
    const reply = await core.ai.callChatEndpoint(settings.base, settings.key || undefined, settings.model, text, context);
    _chatHistory.push({ role: 'assistant', content: reply });
  } catch (e) {
    _chatHistory.push({
      role: 'assistant',
      content: '⚠ Ошибка: ' + (e instanceof Error ? e.message : String(e)) + '\n\nПроверь URL/key/модель и доступность эндпоинта. Могу предложить встроенные советы Ice Strike Monk:\n\n' + core.ai.iceStrikeMonkAdvice(context),
    });
  }
  _renderChat();
  setStatus('Готово.');
}

function _bubble(m: ChatMsg): string {
  const cls = m.role === 'user' ? 'bubble me' : 'bubble ai';
  return `<div class="${cls}"><pre>${esc(m.content)}</pre></div>`;
}

function _renderChat(): void {
  const el = out('out-ai');
  const msg = _chatHistory.map((m) => _bubble(m)).join('');
  el.innerHTML =
    (msg ? `<div class="chatlog">${msg}</div>` : '') +
    `<div class="aipane">
       <textarea id="ai-input" rows="3" placeholder="Спроси про билд, прокачку, торговлю…"></textarea>
       <button id="ai-send" class="primary">Отправить</button>
     </div>`;
  const send = el.querySelector('#ai-send');
  const input = el.querySelector('#ai-input') as HTMLTextAreaElement;
  send?.addEventListener('click', () => void submitAI());
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void submitAI();
    }
  });
}

function submitAI(): void {
  const el = out('out-ai');
  const input = el.querySelector('#ai-input') as HTMLTextAreaElement;
  void sendAIMessage(input?.value ?? '');
}

export function showAIChat(): void {
  _renderChat();
  // записать настройки в поля и подвязать сохранение
  const s = loadAISettings();
  const sb = document.querySelector('#ai-base') as HTMLInputElement;
  const sk = document.querySelector('#ai-key') as HTMLInputElement;
  const sm = document.querySelector('#ai-model') as HTMLInputElement;
  if (sb) sb.value = s.base;
  if (sk) sk.value = s.key;
  if (sm) sm.value = s.model;
  [sb, sk, sm].forEach((f) =>
    f?.addEventListener('change', () => {
      saveAISettings({
        base: (document.querySelector('#ai-base') as HTMLInputElement).value.trim(),
        key: (document.querySelector('#ai-key') as HTMLInputElement).value.trim(),
        model: (document.querySelector('#ai-model') as HTMLInputElement).value.trim(),
      });
    }),
  );
}

/** Собрать контекст текущего билда (если разобран) для отправки в ИИ. */
export function currentBuildContext(): Record<string, unknown> | undefined {
  try {
    const raw = localStorage.getItem('poe2k.lastBuild');
    if (raw) return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    /* ignore */
  }
  return undefined;
}

/** Очистить историю чата. */
export function clearAIChat(): void {
  _chatHistory = [];
  _renderChat();
  setStatus('История чата очищена.');
}

function out(id: string): HTMLElement {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing output element ${id}`);
  return el;
}

function esc(s: string): string {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c,
  );
}

export async function showPriceCheck(text: string): Promise<void> {
  const el = out('out-price');
  if (!text?.trim()) {
    el.innerHTML = '<p class="err">Вставь текст предмета.</p>';
    return;
  }
  el.innerHTML = '<em>Оценка цены…</em>';
  setStatus(`Прайс-чек (лига «${activeLeague}»)…`);
  try {
    core.trade.setLeague(activeLeague);
    const league = activeLeague ?? undefined;
    const res = await core.trade.priceCheck(text, { league });
    const lines: string[] = ['<h3>' + esc(res.itemName) + '</h3>', `<p class="meta">Редкость: <b>${esc(res.rarity)}</b></p>`];
    if (res.estimate) {
      lines.push(
        `<p class="est">Оценка: <b>${res.estimate.median}</b> chaos <span class="dim">(диапазон ${res.estimate.min}–${res.estimate.max}, доверие: ${res.estimate.confidence})</span></p>`,
      );
    } else {
      lines.push('<p class="est none">Оценка: нет данных (не найдено в бесплатных источниках).</p>');
    }
    if (res.listings.length) {
      lines.push('<h4>Похожие объявления (trade2)</h4>');
      lines.push(
        '<table class="tbl"><thead><tr><th>Цена</th><th>Валюта</th></tr></thead><tbody>' +
          res.listings
            .slice(0, 15)
            .map((l) => `<tr><td class="num">${l.price}</td><td>${esc(l.currency)}</td></tr>`)
            .join('') +
          '</tbody></table>',
      );
    }
    lines.push(`<p class="note">Лига: ${esc(res.league ?? activeLeague ?? '')} · Источники: ${res.sources.join(', ') || '—'}.</p>`);
    el.innerHTML = lines.join('');
    setStatus('Прайс-чек готов.');
  } catch (e) {
    el.innerHTML = `<p class="err">Ошибка: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
    setStatus('Ошибка прайс-чека.');
  }
}

export async function showLevelingPlan(): Promise<void> {
  const el = out('out-leveling');
  const sel = document.querySelector<HTMLSelectElement>('#leveling-class');
  const ascInput = document.querySelector<HTMLInputElement>('#leveling-asc');
  // Асценданси приоритетнее селекта: Invoker -> Monk, Lich -> Witch и т.д.
  const raw = (ascInput?.value ?? '').trim() || (sel?.value ?? '').trim();
  el.innerHTML = '<em>Загрузка плана…</em>';
  try {
    let plan: ReturnType<typeof core.leveling.getLevelingPlan>;
    let header = '';
    if (raw) {
      const resolved = core.leveling.resolveLevelingClass(raw);
      if (!resolved) {
        el.innerHTML = `<p class="err">Неизвестный класс или асценданси: «${esc(raw)}». Выбери один из 8 классов или введи асценданси (Invoker, Lich, Titan, Deadeye…).</p>`;
        setStatus('Класс не распознан.');
        return;
      }
      plan = core.leveling.getClassLevelingPlan(resolved.baseClass);
      const label =
        raw.toLowerCase() === resolved.baseClass.toLowerCase()
          ? esc(resolved.baseClass)
          : `${esc(resolved.baseClass)} <span class="dim">(асценданси «${esc(raw)}»)</span>`;
      header = `<p class="hint lvhead">⚔ <b>${label}</b>: ${esc(resolved.tagline ?? '')}</p>`;
    } else {
      plan = core.leveling.getLevelingPlan();
    }
    const byAct = new Map<number, typeof plan>();
    for (const z of plan) {
      const arr = byAct.get(z.act) ?? [];
      arr.push(z);
      byAct.set(z.act, arr);
    }
    const blocks: string[] = [];
    for (const [act, zones] of byAct) {
      const zrows = zones
        .map(
          (z) =>
            `<li><b>${esc(z.zone)}</b> <span class="dim">(ур. ${z.monsterLevel})</span>` +
            (z.rewards.length ? ` <span class="reward">🏆 ${esc(z.rewards.join('; '))}</span>` : '') +
            (z.steps.length ? `<ul class="steps">${z.steps.map((s) => `<li>${s.startsWith('⚔') || s.startsWith('💡') || s.startsWith('🛠') ? `<span class="ctip">${esc(s)}</span>` : esc(s)}</li>`).join('')}</ul>` : '') +
            `</li>`,
        )
        .join('');
      blocks.push(`<div class="actblock"><h3>Акт ${act}</h3><ul class="zones">${zrows}</ul></div>`);
    }
    el.innerHTML = header + blocks.join('');
    setStatus(`Зон в плане: ${plan.length}${raw ? ' · советы по классу включены' : ' · общий план'}.`);
  } catch (e) {
    el.innerHTML = `<p class="err">Ошибка: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
  }
}

export async function showBuildImport(code: string): Promise<void> {
  const el = out('out-build');
  if (!code?.trim()) {
    el.innerHTML = '<p class="err">Вставь share-код PoB.</p>';
    return;
  }
  el.innerHTML = '<em>Декодирование…</em>';
  setStatus('Декод PoB…');
  try {
    // toXml принимает И share-код, И ссылку (pobb.in → /raw, poe.ninja-pob),
    // с анти-HTML и таймаутом — раньше ссылки умирали на decodeShareCode (№208).
    const xml = await core.build.toXml(code.trim());
    const b = await core.build.importBuild(xml);
    _lastBuildNodes = Array.isArray(b.passiveNodes) ? b.passiveNodes.map((n) => String(n)) : [];
    const ls: string[] = ['<h3>Билд</h3>', '<ul class="kv">'];
    ls.push(`<li>Класс: <b>${esc(b.class ?? '—')}</b>${b.ascendancy ? ` / ${esc(b.ascendancy)}` : ''}</li>`);
    ls.push(`<li>Уровень: <b>${b.level ?? '—'}</b></li>`);
    if (b.skills.length) ls.push(`<li>Скиллы: ${b.skills.map(esc).join(', ')}</li>`);
    if (b.passiveNodes.length) ls.push(`<li>Узлы пассивок: <b>${b.passiveNodes.length}</b></li>`);
    const st = b.stats ?? {};
    if (st.TotalDPS != null || st.CombinedDPS != null) {
      ls.push(`<li>DPS: <b>${Math.round(st.TotalDPS ?? st.CombinedDPS!).toLocaleString('ru-RU')}</b></li>`);
    }
    const hp = st.Life ?? st['EnergyShield'];
    if (hp != null) ls.push(`<li>Жизнь/ES: <b>${Math.round(hp).toLocaleString('ru-RU')}</b></li>`);
    ls.push('</ul>');
    const gear =
      b.gear && Object.keys(b.gear).length
        ? Object.entries(b.gear).map(([s, v]) => `<li><b>${esc(s)}:</b> ${esc(v)}</li>`).join('')
        : '';
    if (gear) ls.push('<h4>Снаряжение</h4><ul class="kv">' + gear + '</ul>');
    if (b.passiveNodes.length) ls.push(`<p class="note">Пассивок: ${b.passiveNodes.length} · углублённый анализ — через ИИ (вкладка «AI»)/MCP.</p>`);
    el.innerHTML = ls.join('');
    // №266: саппорт-советы по активным гемам (офлайн-слои core.gemSupports).
    void renderSupportsAdvice(b.skills).catch(() => {
      /* блок уже показал свою ошибку — разбор билда не ломаем */
    });
    try {
      localStorage.setItem(
        'poe2k.lastBuild',
        JSON.stringify({
          class: b.class,
          ascendancy: b.ascendancy,
          level: b.level,
          skills: b.skills,
          passiveNodes: b.passiveNodes,
          gear: b.gear,
          stats: b.stats,
          summary: core.build.summarizeBuild(b),
        }),
      );
      // №223: исходный share-код — рядом с разбором, чтобы потребители
      // («Раскладка», оверлей, будущие вкладки) пересобирали advice того же
      // билда, а не просили вставить код заново. Ключи lastBuild/lastBuildCode
      // пишутся одной транзакцией импорта: меняются только вместе.
      localStorage.setItem('poe2k.lastBuildCode', code.trim());
    } catch {
      /* ignore */
    }
    setStatus('Билд разобран.');
  } catch (e) {
    el.innerHTML = `<p class="err">Ошибка декода: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
    setStatus('Ошибка декода.');
  }
}

// ── «Перелить в игру»: экспорт *.build через File System Access (E4) ────────

/** Типы FSA (File System Access API) — в TS lib нет, инжектим минимально. */
interface FsaWritableFile {
  createWritable(): Promise<{ write(data: string): Promise<void>; close(): Promise<void> }>;
}
interface FsaDirectoryHandle {
  getFileHandle(name: string, opts?: { create?: boolean }): Promise<FsaWritableFile>;
}
type ShowDirectoryPicker = (opts: { id: string; mode: 'readwrite'; startIn?: string }) => Promise<FsaDirectoryHandle>;

function directoryPicker(): ShowDirectoryPicker | undefined {
  return (window as unknown as { showDirectoryPicker?: ShowDirectoryPicker }).showDirectoryPicker;
}

/** Видимость кнопки «Перелить в игру» — только если браузер умеет FSA. */
export function decantSupported(): boolean {
  return typeof window !== 'undefined' && directoryPicker() !== undefined;
}

/**
 * Конвертировать билд PoB в *.build и записать в выбранную папку (обычно
 * Documents/My Games/Path of Exile 2/BuildPlanner) через File System Access.
 * Валидация — ДО записи: структурные ошибки (молчаливый отказ игры) блокируют
 * файл, юзер видит отчёт. Атрибуция: link/description с источником кода.
 */
export async function decantToBuildPlanner(code: string): Promise<void> {
  const el = out('out-build-decant');
  const picker = directoryPicker();
  if (!picker) {
    el.innerHTML = '<p class="err">Браузер не поддерживает выбор папки (File System Access) — сохрани JSON из MCP-тула poe2_export_build_planner вручную.</p>';
    return;
  }
  if (!code?.trim()) {
    el.innerHTML = '<p class="err">Вставь share-код PoB в поле выше и нажми «Разобрать».</p>';
    return;
  }
  el.innerHTML = '<em>Декод PoB…</em>';
  setStatus('Готовлю *.build…');
  try {
    const xml = await core.build.toXml(code.trim());
    const [imported, gearItems] = await Promise.all([
      core.build.importBuild(xml),
      core.build.buildCodeToGear(code.trim()).catch(() => []),
    ]);
    const isUrl = /^https?:\/\//i.test(code.trim());
    const res = core.buildPlanner.toBuildPlanner(imported, {
      ...(isUrl ? { link: code.trim() } : {}),
      description: `Источник: ${isUrl ? code.trim() : 'PoB share-код'} · сконвертировано poe2-kit`,
      ...(gearItems.length ? { gearItems } : {}),
    });

    // Гейт до записи: битый *.build игра молча не грузит (SCHEMA.md:5-6).
    const v = core.buildPlanner.validateBuildPlanner(res.build);
    if (!v.valid) {
      el.innerHTML =
        '<p class="err">Файл НЕ записан — структурные ошибки схемы:</p><ul class="kv">' +
        v.errors.map((e) => `<li>✖ ${esc(e)}</li>`).join('') +
        '</ul>';
      setStatus('Валидация не пройдена.');
      return;
    }

    const dir = await picker({ id: 'poe2-buildplanner', mode: 'readwrite' });
    const handle = await dir.getFileHandle(res.filename, { create: true });
    const writable = await handle.createWritable();
    await writable.write(res.json);
    await writable.close();

    const warnLines = [...v.warnings, ...res.warnings];
    el.innerHTML = [
      `<p><b>Записано: ${esc(res.filename)}</b> — перезапусти игру, Настройки → Импорт билда.</p>`,
      warnLines.length ? '<p class="note">' + warnLines.map(esc).join(' · ') + '</p>' : '',
    ].join('');
    setStatus('*.build записан.');
  } catch (e) {
    if (e instanceof Error && e.name === 'AbortError') {
      el.innerHTML = '<p class="note">Выбор папки отменён.</p>';
      return;
    }
    el.innerHTML = `<p class="err">Ошибка экспорта: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
    setStatus('Ошибка экспорта .build.');
  }
}

/** Узлы последнего разобранного билда (для карты дерева). */
let _lastBuildNodes: string[] = [];

/** Узлы последнего разобранного билда. */
export function getLastBuildNodes(): string[] {
  return _lastBuildNodes.slice();
}

/** Показать интерактивную карту дерева по списку ID узлов. */
export async function showBuildTree(ids: string[]): Promise<void> {
  const el = out('out-tree');
  const cleaned = (ids ?? []).map((x) => String(x).trim()).filter(Boolean);
  if (!cleaned.length) {
    el.innerHTML = '<p class="err">Нет ID узлов.</p>';
    return;
  }
  el.innerHTML = '<em>Загрузка карты дерева…</em>';
  setStatus('Строю карту дерева…');
  try {
    await renderTreeMap(el, cleaned);
    setStatus(`На карте узлов: ${cleaned.length}. Клик по узлу — статы, колесо — масштаб.`);
  } catch (e) {
    el.innerHTML = `<p class="err">Ошибка карты: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
    setStatus('Ошибка карты дерева.');
  }
}

/** Показать карту дерева по ID, введённым в поле (пробелы, запятые, переводы строк). */
export async function showBuildTreeFromText(text: string): Promise<void> {
  const ids = (text || '').split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
  await showBuildTree(ids);
}

/** Показать карту дерева последнего разобранного билда. */
export async function showBuildTreeFromLast(): Promise<void> {
  const el = out('out-tree');
  const ids = _lastBuildNodes.length ? _lastBuildNodes.slice() : [];
  if (!ids.length) {
    el.innerHTML = '<p class="err">Сначала разбери билд (вкладка «Импорт билда») или введи ID узлов в поле выше.</p>';
    return;
  }
  await showBuildTree(ids);
}

/** Прайс-чек всего снаряжения билда по живым ценам. */
export async function showBuildPrice(code: string): Promise<void> {
  const el = out('out-build-price');
  if (!code?.trim()) {
    el.innerHTML = '<p class="err">Вставь share-код PoB.</p>';
    return;
  }
  el.innerHTML = '<em>Оценка снаряжения по живым ценам…</em>';
  setStatus('Прайс-чек билда…');
  try {
    const report = await core.trade.priceBuild(code.trim());
    const lines: string[] = [
      '<h3>Прайс-чек билда</h3>',
      `<ul class="kv">
        <li>Лига: <b>${esc(report.league ?? '—')}</b></li>
        <li>Предметов обработано: <b>${report.totalItems}</b></li>
        <li>Оценено цен: <b>${report.pricedCount}</b></li>
        <li>Суммарная нижняя граница: <b>${report.totalMin.toFixed(2)}</b></li>
        <li>Время: ${report.elapsedMs} мс</li>
      </ul>`,
      '<table><thead><tr><th>Слот</th><th>Имя</th><th>Редкость</th><th>Медиана</th><th>min–max</th><th>Объявл.</th></tr></thead><tbody>',
    ];
    for (const it of report.items) {
      const median = it.estimate?.median;
      const range = it.estimate
        ? `${it.estimate.min.toFixed(2)}–${it.estimate.max.toFixed(2)}`
        : '—';
      lines.push(
        `<tr>
          <td>${esc(it.slot || '—')}</td>
          <td>${esc(it.name || '—')}</td>
          <td>${esc(it.rarity)}</td>
          <td>${median != null ? median.toFixed(2) : '—'}</td>
          <td>${range}</td>
          <td>${it.listingsCount}</td>
        </tr>`,
      );
    }
    lines.push('</tbody></table>');
    el.innerHTML = lines.join('');
    setStatus(`Прайс-чек: ${report.pricedCount}/${report.totalItems} оценено.`);
  } catch (e) {
    el.innerHTML = `<p class="err">Ошибка прайс-чека: ${esc(e instanceof Error ? e.message : String(e))}</p>`;
    setStatus('Ошибка прайс-чека билда.');
  }
}