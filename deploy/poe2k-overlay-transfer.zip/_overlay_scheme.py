# -*- coding: utf-8 -*-
"""Рендер детализированной схемы оверлея PoE2 Kit -> PNG."""
from PIL import Image, ImageDraw, ImageFont

SCALE = 2
W, H = 1760, 2300
BG = (13, 17, 23)
BORDER = (240, 136, 62)
FG = (230, 237, 243)
DIM = (154, 164, 176)
ACCENT = (240, 136, 62)
OK = (63, 185, 80)
WARN = (210, 153, 34)
RARE = (247, 200, 115)
MAGIC = (96, 165, 250)
UNIQUE = (230, 180, 34)
PANEL = (22, 27, 34)
PANEL2 = (28, 34, 42)
LINE = (60, 70, 84)

def f(size, bold=False):
    name = "segoeuib" if bold else "segoeui"
    for cand in ([name + ".ttf"] + (["arialb.ttf", "arial.ttf"] if bold else ["arial.ttf"])):
        try:
            return ImageFont.truetype(cand, size * SCALE)
        except OSError:
            continue
    return ImageFont.load_default()

img = Image.new("RGB", (W * SCALE, H * SCALE), BG)
d = ImageDraw.Draw(img)

def S(x):  # координаты в "логических" px
    return x * SCALE

def rr(box, r=10, fill=PANEL, outline=LINE, width=1):
    d.rounded_rectangle([S(box[0]), S(box[1]), S(box[2]), S(box[3])], radius=S(r), fill=fill, outline=outline, width=width)

def text(x, y, s, size=12, color=FG, bold=False, anchor=None):
    d.text((S(x), S(y)), s, font=f(size, bold), fill=color, anchor=anchor)

def arrow(x1, y1, x2, y2, color=ACCENT, width=2, dash=None):
    d.line([S(x1), S(y1), S(x2), S(y2)], fill=color, width=width * SCALE)
    # стрелка
    import math
    ang = math.atan2(y2 - y1, x2 - x1)
    L = 9
    for da in (2.6, -2.6):
        a = ang + (math.pi + (0.4 if da > 0 else -0.4))
        d.line([S(x2), S(y2), S(x2 + L * math.cos(ang + (0.5 if da > 0 else -0.5))), S(y2 + L * math.sin(ang + (0.5 if da > 0 else -0.5)))], fill=color, width=width * SCALE)

def line(x1, y1, x2, y2, color=LINE, width=1):
    d.line([S(x1), S(y1), S(x2), S(y2)], fill=color, width=width * SCALE)

MX = 40  # левый/правой отступ контента

# ═══ Заголовок ═══
text(W // 2, 26, "PoE2 Kit Overlay — детализированная схема", 20, FG, True, "ma")
text(W // 2, 58, "Electron: main (процесс) ↔ preload (мост) ↔ renderer (виджет) · поверх окна PoE2", 12, DIM, False, "ma")

# ═══ Секция 1: Архитектура ═══
Y = 88
text(MX, Y, "1. АРХИТЕКТУРА И ПОТОКИ ДАННЫХ", 14, ACCENT, True)
Y += 10
rr((MX, Y, W - MX, Y + 252), r=12, fill=PANEL2, outline=LINE)

# Окно игры
game_top, game_bot = Y + 16, Y + 236
d.rectangle([S(MX + 16), S(game_top), S(MX + 240), S(game_bot)], outline=LINE, width=2)
text(MX + 128, game_top + 14, "ОКНО ИГРЫ PoE2", 11, DIM, True, "ma")
text(MX + 128, game_top + 36, "(Win32: findGameWindow,\nfindWindowRect — через koffi)", 9, DIM, False, "ma")

# Main
mm_x0, mm_y0, mm_x1, mm_y1 = MX + 280, Y + 16, MX + 1060, Y + 138
rr((mm_x0, mm_y0, mm_x1, mm_y1), r=10, fill=(18, 22, 29), outline=ACCENT, width=2)
text(mm_x0 + 10, mm_y0 + 8, "MAIN-ПРОЦЕСС (main.ts)", 11, ACCENT, True)

def box(x, y, w, h, title, sub=None, tcolor=FG):
    rr((x, y, x + w, y + h), r=7, fill=PANEL, outline=LINE)
    text(x + w // 2, y + (10 if sub else 12), title, 10, tcolor, True, "ma")
    if sub:
        for i, ln in enumerate(sub.split("\n")):
            text(x + w // 2, y + 26 + i * 12, ln, 9, DIM, False, "ma")

b1x, b1y = mm_x0 + 14, mm_y0 + 32
box(b1x, b1y, 200, 64, "globalShortcut", "7 хоткеев\nregisterHotkeys()")
box(b1x + 214, b1y, 220, 64, "BrowserWindow", "overlayWindow: прозрачное,\nвсегда-поверх, click-through")
box(b1x + 448, b1y, 240, 64, "clipboard + win32.ts", "readText() · Ctrl+C из игры\nisGameForeground()")
box(b1x + 702, b1y, 316, 64, "@poe2-kit/core (ядро)", "priceCheck · parse · zoneNotes\nlog (Client.txt) · build · trade")

# IPC ядро
box(mm_x0 + 14, mm_y0 + 104, 240, 24, "ipcMain.handle", None, DIM)
text(mm_x0 + 160, mm_y0 + 112, "invoke ↓", 9, DIM, False, "ma")
# ядро webContents.send
text(b1x + 560, mm_y0 + 112, "price:result · price:busy · level:result · build:update · move:mode · settings:toggle/display", 9, DIM, False, "ma")

# Preload
pl_y = Y + 154
rr((MX + 280, pl_y, MX + 1060, pl_y + 34), r=8, fill=PANEL, outline=DIM)
text(MX + 670, pl_y + 17, "PRELOAD (preload.ts) — contextBridge: window.poe2k.*  (contextIsolation: true)", 10, DIM, True, "ma")

# Renderer
rn_y = Y + 198
rr((MX + 280, rn_y, MX + 1060, Y + 236), r=8, fill=(18, 22, 29), outline=BORDER)
text(MX + 670, rn_y + 19, "RENDERER (rendererHtml.ts) — один DOM, секции по действиям", 10, BORDER, True, "ma")

# Справа: секции DOM
sx = MX + 1088
rr((sx, Y + 16, W - MX - 16, Y + 236), r=10, fill=PANEL, outline=LINE)
text(sx + (W - MX - 16 - sx) // 2, Y + 28, "СЕКЦИИ DOM (#panel)", 10, FG, True, "ma")
dom_items = [
    ("#idle", "стартовый экран (Ctrl+F1/F3/F2)"),
    ("#body → #est / #buildNote / #err / #meta", "результат Ctrl+F1 + листинги"),
    ("#lvlWrap", "зона + подсказки (Ctrl+F4)"),
    ("#buildWrap", "шопинг-лист + 💎 камни (Ctrl+F2)"),
    ("#settingsPanel", "настройки (Ctrl+F6)"),
    ("#grab", "полоса тащи-меня (Ctrl+F5)"),
    ("#hint", "постоянная строка хоткеев внизу"),
]
for i, (t, s) in enumerate(dom_items):
    yy = Y + 46 + i * 25
    text(sx + 12, yy, t, 9.5 if False else 10, BORDER, True)
    text(sx + 262, yy + 1, s, 9.5 if False else 10, DIM)
    if i < len(dom_items) - 1:
        line(sx + 12, yy + 15, W - MX - 28, yy + 15, (40, 48, 60), 1)

# Стрелки архитектуры
arrow(MX + 240, game_top + 40, b1x, b1y + 20, DIM, 1)
text(MX + 252, game_top + 18, "привязка к углу", 9, DIM, False, "ma")
arrow(mm_x1 + 4, b1y + 40, mm_x0 + 4, b1y + 40)  # core -> main (обратная, стрелка влево)
arrow(MX + 670, mm_y1 + 2, MX + 670, pl_y - 2)
arrow(MX + 670, pl_y + 36, MX + 670, rn_y - 2)
arrow(MX + 670, rn_y - 2, MX + 670, pl_y + 36, DIM, 1)

# ═══ Секция 2: Хоткеи ═══
Y = Y + 282
text(MX, Y, "2. ГОРЯЧИЕ КЛАВИШИ — реестр registerHotkeys()", 14, ACCENT, True)
Y += 10
tbl_w = W - MX * 2
hdr = ["Действие", "По умолчанию", "Куда (IPC / реакция main)", "Результат в виджете"]
rows = [
    ("price", "Ctrl+F1", "runPriceCheck()", "прайс предмета из буфера (trade2/poe.ninja)"),
    ("buildPanel", "Ctrl+F2", "toggleBuildPanel()", "шопинг-лист билда + 💎 сетапы камней"),
    ("buildImport", "Ctrl+F3", "runBuildImport()", "импорт PoB-кода / автосинхронизация с персонажем"),
    ("leveling", "Ctrl+F4", "runLevelingContext()", "зона, подсказки, 3 следующие зоны (Client.txt)"),
    ("move", "Ctrl+F5", "toggleMoveMode()", "режим перемещения окна мышью"),
    ("settings", "Ctrl+F6", "toggleSettingsPanel()", "панель настроек (overlay-settings.json)"),
]
colw = [170, 150, 430, tbl_w - 750]
yy = Y
rr((MX, yy, W - MX, yy + 26), r=6, fill=(30, 36, 46), outline=LINE)
cx = MX + 12
for i, h in enumerate(hdr):
    text(cx, yy + 7, h, 10, DIM, True)
    cx += colw[i]
yy += 30
for name, hk, fn, out in rows:
    rr((MX, yy, W - MX, yy + 34), r=6, fill=PANEL, outline=LINE)
    cx = MX + 12
    text(cx, yy + 11, name, 10, FG, True)
    cx += colw[0]
    d.rounded_rectangle([S(cx), S(yy + 7), S(cx + 118), S(yy + 27)], radius=S(5), fill=(18, 22, 29), outline=ACCENT)
    text(cx + 59, yy + 17, hk, 10, ACCENT, True, "ma")
    cx += colw[1]
    text(cx, yy + 11, fn, 9.5 if False else 10, MAGIC)
    cx += colw[2]
    text(cx, yy + 11, out, 9.5 if False else 10, DIM)
    yy += 38
rr((MX, yy, W - MX, yy + 52), r=6, fill=PANEL, outline=DIM)
text(MX + 12, yy + 8, "Ctrl+Shift+F5  (жёстко, не переопределяется)  →  resetOverlayOffset()", 10, WARN, True)
text(MX + 12, yy + 26, "сброс пользовательского смещения: возвращает оверлей в штатный угол окна игры + выход из move-режима", 9.5 if False else 10, DIM)
Y = yy + 62
text(MX, Y, "Механика: hotkeyFor(action) = settings.hotkeys[action] ?? DEFAULT_HOTKEYS[action]. При «Сохранить» — globalShortcut.unregisterAll() и перерегистрация.", 9.5 if False else 10, DIM)

# ═══ Секция 3: Панель настроек ═══
Y += 26
text(MX, Y, "3. ПАНЕЛЬ НАСТРОЕК (Ctrl+F6) — OverlaySettings", 14, ACCENT, True)
Y += 10
sw = (tbl_w - 30) // 2
# левая: параметры
rr((MX, Y, MX + sw, Y + 214), r=10, fill=PANEL, outline=LINE)
text(MX + 12, Y + 10, "ПАРАМЕТРЫ (слайдеры/кнопки)", 10, FG, True)
params = [
    ("opacity — прозрачность фона", "25% – 100%  (default 86%)", "CSS-переменная --bg: альфа rgba(13,17,23,a); текст остаётся читаемым"),
    ("scale — масштаб UI", "70% – 140%, шаг 5  (default 100%)", "CSS zoom на #panel"),
    ("width — ширина панели", "280 – 640 px, шаг 10  (default 420)", "setBounds BrowserWindow (DIP)"),
    ("corner — угол привязки", "В·л / В·п / Н·л / Н·п  (default top-right)", "пересчёт позиции от rect окна игры (findWindowRect)"),
]
py = Y + 32
for name, rng, how in params:
    text(MX + 12, py, name, 10, FG, True)
    text(MX + 12, py + 15, rng, 10, ACCENT)
    text(MX + 12, py + 30, how, 9, DIM)
    py += 46
# правая: хоткеи
rx = MX + sw + 30
rr((rx, Y, W - MX, Y + 214), r=10, fill=PANEL, outline=LINE)
text(rx + 12, Y + 10, "ГОРЯЧИЕ КЛАВИШИ — hkGrid (6 полей)", 10, FG, True)
hkrows = [
    ("Прайс", "Ctrl+F1"), ("Прокачка", "Ctrl+F4"), ("Перемещение", "Ctrl+F5"),
    ("Импорт билда", "Ctrl+F3"), ("Панель билда", "Ctrl+F2"), ("Настройки", "Ctrl+F6"),
]
hy = Y + 32
for i, (label, defhk) in enumerate(hkrows):
    d.rounded_rectangle([S(rx + 12), S(hy - 2), S(rx + 150), S(hy + 18)], radius=S(5), fill=PANEL2, outline=LINE)
    text(rx + 16, hy, label, 9.5 if False else 10, FG)
    d.rounded_rectangle([S(rx + 162), S(hy - 2), S(W - MX - 16), S(hy + 18)], radius=S(5), fill=(18, 22, 29), outline=(60, 70, 84))
    text(W - MX - 26, hy, defhk, 9.5 if False else 10, DIM, anchor="ra")
    hy += 22
text(rx + 12, hy + 4, "Пустое поле = стандарт (подсвечен как placeholder). Формат: Control+F1, Alt+Shift+Q.", 9, DIM)
text(rx + 12, hy + 18, "Кнопки: «Сбросить клавиши» (очищает 6 полей) · «Сохранить» → settings:apply → normalizeSettings (вкладывает диапазоны)", 9, DIM)
text(rx + 12, hy + 42, "→ applySettings + запись userData/overlay-settings.json. Ошибка — на кнопке на 2,5 с.", 9, DIM)
Y += 226

# ═══ Секция 4: Файлы ═══
text(MX, Y, "4. ФАЙЛЫ В userData (app.getPath('userData') = %APPDATA%\\@poe2-kit\\overlay)", 14, ACCENT, True)
Y += 10
files = [
    ("overlay-settings.json", "corner / opacity / scale / width / hotkeys — переживает перезапуск"),
    ("overlay.log  (+ .1)", "тень console.log/warn/error; ротация > 1 МБ (rename → .1, старый удалён)"),
    ("game-log-path.txt", "опциональный путь к Client.txt (автодетект по дискам иначе)"),
    ("build-state.json", "slots (status todo/bought, worn), summary (EHP/gaps/DPS), gemSetups, panelVisible"),
    ("char-sync.json", "account/league/character/lastSyncAt — троттлинг 5 мин между запросами poe.ninja"),
    ("league.txt + localStorage 'poe2k.league'", "выбранная лига (league:get/set → core.trade.setLeague)"),
]
for i, (n, s) in enumerate(files):
    yy = Y + i * 27
    d.rounded_rectangle([S(MX), S(yy), S(MX + 330), S(yy + 22)], radius=S(5), fill=PANEL2, outline=LINE)
    text(MX + 8, yy + 5, n, 9.5 if False else 10, BORDER, True)
    text(MX + 344, yy + 5, s, 9.5 if False else 10, DIM)
Y += len(files) * 27 + 10

# ═══ Секция 5: Горячие пути ═══
text(MX, Y, "5. ГОРЯЧИЕ ПУТИ", 14, ACCENT, True)
Y += 10
paths = [
    ("Ctrl+F1 — прайс", "clipboard.readText() → core.parse.parseItemText → core.trade.priceCheck (trade2 + poe.ninja) → price:result.\nЕсли есть buildState: matchBuildSlot(имя/base) → отметка слота 'bought' + строка «✔ Слот билда: …».\nЕсли буфер похож на PoB-код → подсказка «нажмите Ctrl+F3» (buildCodeHint)."),
    ("Ctrl+F4 — прокачка", "core.log.getClientState (Client.txt, bounded tail) → core.zoneNotes.getLevelingContext → level:result.\nПоказ: зона (G{act}_{area}), русские заметки (notes_ru), hints, 3 следующие зоны (уровень, Δ, награды)."),
    ("Ctrl+F5 — перемещение", "toggleMoveMode: setIgnoreMouseEvents(false) + setFocusable(true) + полоса #grab.\nТаскание мышью → userOffset (DIP от закреплённого угла). Повторный Ctrl+F5 — закрепить. Ctrl+Shift+F5 — полный сброс."),
    ("Ctrl+F3 — импорт", "PoB share-код/ссылка → core.build.buildCodeToGear + estimateBuild → build-state.json → фоновый прайсинг слотов (token отмены).\nСсылка на персонажа poe.ninja → автосинхронизация worn-эквипа (не затирает целевой билд, троттлинг 5 мин)."),
]
pw = (tbl_w - 20) // 2
for i, (t, s) in enumerate(paths):
    bx = MX + (i % 2) * (pw + 20)
    by = Y + (i // 2) * 118
    rr((bx, by, bx + pw, by + 108), r=10, fill=PANEL, outline=LINE)
    text(bx + 12, by + 8, t, 10.5 if False else 11, ACCENT, True)
    lines = s.split("\n")
    for j, ln in enumerate(lines):
        text(bx + 12, by + 28 + j * 14, ln, 9, FG if j == 0 else DIM)
Y += 2 * 118 + 12

# ═══ Легенда/подвал ═══
line(MX, Y, W - MX, Y, LINE, 1)
text(MX, Y + 10, "Код: apps/overlay/src/{main.ts, preload.ts, rendererHtml.ts, win32.ts} · core: packages/core/src/{trade.ts, parse.ts, build.ts, log.ts, zoneNotes.ts, estimate.ts}", 9, DIM)
text(W - MX, Y + 10, "по коду на 25.09.2026", 9, DIM, anchor="ra")

img = img.resize((W, H), Image.LANCZOS)
out = r"C:\Users\mezhavikiserj\BildPOE2\poe2-kit\deploy\docs\overlay-scheme.png"
import os
os.makedirs(os.path.dirname(out), exist_ok=True)
img.save(out)
print("saved", out, img.size)
