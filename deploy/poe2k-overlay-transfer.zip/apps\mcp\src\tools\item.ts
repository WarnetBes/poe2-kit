/**
 * MCP-инструменты: разбор предмета и прайс-чек.
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { core } from '@poe2-kit/core';
import type { ModTierDossier, ParsedItem, PoeshopMarketLookup } from '@poe2-kit/core';
import { currentDefaultLeague } from '../leagues.js';

function fmtDef(def: { armour?: unknown; evasion?: unknown; energyShield?: unknown; blockChance?: unknown }): string {
  const parts: string[] = [];
  if (def.armour) parts.push(`Armour ${(def.armour as any)?.value}`);
  if (def.evasion) parts.push(`Evasion ${(def.evasion as any)?.value}`);
  if (def.energyShield) parts.push(`ES ${(def.energyShield as any)?.value}`);
  if (def.blockChance) parts.push(`Block ${(def.blockChance as any)?.value}`);
  return parts.join(', ') || '—';
}

/** Секция «Тиры модов» для parse_item: таблица тиров + свободные P/S-слоты
 *  (формат донора poe2-mcp-server formatEnrichmentSection, MIT). Пустое досье → ''. */
function formatTierDossier(dossier: ModTierDossier, item: ParsedItem): string {
  if (!dossier.modTiers.length && !dossier.base) return '';
  const lines: string[] = ['### Тиры модов (RePoE)'];
  if (dossier.base) {
    const bi = dossier.base;
    const statParts: string[] = [];
    if (bi.baseEs !== null) statParts.push(`база ES ${bi.baseEs}`);
    if (bi.baseArmour !== null) statParts.push(`база брони ${bi.baseArmour}`);
    if (bi.baseEvasion !== null) statParts.push(`база уклонения ${bi.baseEvasion}`);
    if (bi.basePhysDamageMin !== null && bi.basePhysDamageMax !== null) {
      statParts.push(`база физ ${bi.basePhysDamageMin}-${bi.basePhysDamageMax}`);
    }
    lines.push(`**База:** ${bi.name}${statParts.length ? ` — ${statParts.join(' | ')}` : ''}`);
  }
  if (dossier.modTiers.length) {
    const ilvlLabel = item.itemLevel !== null ? String(item.itemLevel) : '?';
    lines.push('', `Окна тиров при ilvl ${ilvlLabel}:`);
    lines.push('| Мод | Ролл | Тир | Диапазон | Идеал@ilvl | P/S | Ролл % |');
    lines.push('|---|---|---|---|---|---|---|');
    for (const t of dossier.modTiers) {
      const ps = t.prefixSuffix === 'prefix' ? 'P' : 'S';
      const best = t.bestTierAtIlvl !== null ? `T${t.bestTierAtIlvl}` : '—';
      const pct = t.rollPct !== null ? `${t.rollPct}%` : '—';
      lines.push(
        `| ${t.modText} | ${t.value} | T${t.tier}/${t.totalTiers} | ${t.range[0]}–${t.range[1]} | ${best} | ${ps} | ${pct} |`,
      );
    }
    if (dossier.maxPrefixes > 0 || dossier.maxSuffixes > 0) {
      const openP = dossier.openPrefix;
      const openS = dossier.openSuffix;
      lines.push('');
      lines.push(
        `Слоты аффиксов: **${openP >= 0 ? openP : 0} свободных префиксов / ${openS >= 0 ? openS : 0} свободных суффиксов** (макс ${dossier.maxPrefixes}P/${dossier.maxSuffixes}S для ${item.rarity}; заполнено ${dossier.prefixCount}P/${dossier.suffixCount}S)`,
      );
    }
  }
  if (dossier.unmatchedExplicits.length) {
    lines.push('', `Без тира (не в RePoE-индексе): ${dossier.unmatchedExplicits.length} шт.`);
  }
  return lines.join('\n');
}

export function registerItemTools(server: McpServer): number {
  server.registerTool(
    'poe2_parse_item',
    {
      title: 'PoE2 Parse Item',
      description: `Разобрать клир-текст предмета PoE2 (Ctrl+C в игре) в структурированный объект.

Аргументы:
  - item_text (string): полный текст предмета из игры, включая строки "Rarity:", "--------", моды.

Возвращает: редкость, имя, базовый тип, Item Class, Item Level, качество, защиты,
нападение (для оружия), требования и список модов с типами (explicit/implicit/rune/...).

Для Rare/Magic дополнительно enrichment по RePoE (P2): тиры каждого explicit-мода
(T{n}/{total}, диапазон тира, лучший тир при текущем ilvl, префикс/суффикс, совершенство
ролла в %), базовые статы базы и число открытых слотов аффиксов. Требует сеть только
на первый вызов (кэш RePoE); при недоступности данных секция тиров просто опускается.

Пример входных данных:
Rarity: Rare
Storm Warden
Leather Gloves
--------
Quality: +20%
Armour: 42
--------
Item Level: 68
--------
+45 to Strength (implicit)
Adds 3 to 8 Cold Damage
`,
      inputSchema: {
        item_text: z.string().min(5).describe('Клир-текст предмета из игры'),
      },
      annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true },
    },
    async ({ item_text }) => {
      try {
        const item = core.parse.parseItemText(item_text);
        // P2 mod-tier enrichment: тиры RePoE + открытые слоты (никогда не бросает;
        // офлайн/не-EN база → секции просто не будет, парсер остаётся чистым).
        const dossier = await core.modTiers.resolveModTiers(item_text);
        const mods = item.mods.map((m) => `- [${m.type}] ${m.text}`).join('\n');
        const req = item.requirements;
        const text = [
          '## Разбор предмета',
          `- **Редкость:** ${item.rarity}`,
          `- **Имя:** ${item.name ?? '—'}`,
          `- **Базовый тип:** ${item.baseType || '—'}`,
          `- **Item Class:** ${item.itemClass || '—'}`,
          `- **Item Level:** ${item.itemLevel ?? '—'}`,
          `- **Качество:** ${item.quality?.value != null ? item.quality.value + '%' : '—'}`,
          `- **Защита:** ${fmtDef(item.defences)}`,
          item.offense.physicalDamage
            ? `- **Физ. урон:** ${item.offense.physicalDamage.min}-${item.offense.physicalDamage.max}`
            : null,
          item.offense.attacksPerSecond
            ? `- **Атак/сек:** ${item.offense.attacksPerSecond.value}`
            : null,
          `- **Требования:** L${req.level ?? '?'}${req.strength ? `, ${req.strength} Str` : ''}${req.dexterity ? `, ${req.dexterity} Dex` : ''}${req.intelligence ? `, ${req.intelligence} Int` : ''}`,
          '',
          '### Моды',
          mods || '(нет модов)',
          '',
          formatTierDossier(dossier, item),
        ];
        return { content: [{ type: 'text', text: text.filter(Boolean).join('\n') }] };
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return { isError: true, content: [{ type: 'text', text: `Ошибка разбора: ${msg}` }] };
      }
    },
  );

  server.registerTool(
    'poe2_price_check',
    {
      title: 'PoE2 Price Check',
      description: `Прайс-чек предмета PoE2 по клир-тексту, либо SSF-разбор (без цены).
Использует бесплатные API (poe2scout, poe.ninja, официальный trade2), кроме mode=ssf.

Аргументы:
  - item_text (string): клир-текст предмета из игры.
  - league (string, опц.): название лиги. По умолчанию текущая/активная.
  - mode (string, опц.): "trade" (по умолчанию — цена по листингам) | "ssf" (без сети:
    план крафта, фрактуред-моды, ближайшая зона дропа базы по ilvl).

В режиме trade возвращает оценку цены (для уникальных — из poe2scout, для валют — poe.ninja,
для прочего — из объявлений trade2) и список листингов. В режиме ssf — эвристический
SSF-план: не тратит сеть и валюту, выдаёт рекомендации по крафту.
`,
      inputSchema: {
        item_text: z.string().min(5).describe('Клир-текст предмета из игры'),
        mode: z.enum(['trade', 'ssf']).optional().describe("Режим: trade (цена) | ssf (план крафта, без сети)"),
        league: z.string().optional().describe('Название лиги PoE2 (если не указана — актуальная текущая лига)'),
      },
      annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true },
    },
    async ({ item_text, league, mode }) => {
      try {
        if (mode === 'ssf') {
          const a = core.ssf.ssfAssessmentFromText(item_text);
          const lines = ['## SSF-разбор предмета', core.ssf.formatSsf(a)];
          return { content: [{ type: 'text', text: lines.join('\n') }] };
        }
        const leagueName = league ?? (await currentDefaultLeague());
        core.trade.setLeague(leagueName);
        const res = await core.trade.priceCheck(item_text, { league: leagueName });
        const lines = [
          `## Прайс-чек: ${res.itemName}`,
          `- **Редкость:** ${res.rarity}`,
        ];
        // Бейджи тиров RePoE (P2, additive): «T2 из 5». resolveModTiers сам гейтит
        // редкость (Rare/Magic only) и не бросает; пустое досье → секции нет.
        {
          const dossier = await core.modTiers.resolveModTiers(item_text);
          if (dossier.modTiers.length) {
            lines.push('', '### Тиры модов (RePoE)');
            for (const t of dossier.modTiers) {
              const badge = core.modTiers.tiersBadgeText(t);
              const pct = t.rollPct !== null ? `, ролл ${t.rollPct}%` : '';
              lines.push(`- ${t.modText} — **${badge}** (${t.prefixSuffix === 'prefix' ? 'префикс' : 'суффикс'}${pct})`);
            }
          }
        }
        if (res.estimate) {
          lines.push(
            `- **Оценка:** ${res.estimate.median} chaos (доверие: ${res.estimate.confidence}, диапазон ${res.estimate.min}-${res.estimate.max})`,
          );
        } else {
          lines.push('- **Оценка:** нет данных (предмет не найден в бесплатных источниках)');
        }
        // Витрина poeshop (офлайн-датасет): для уников — вторая оценка + вердикт
        // «не выкидывай»; особенно ценна, когда scout/trade2 оценки не дали.
        if (res.rarity === 'Unique') {
          try {
            const lk: PoeshopMarketLookup = core.poeshopMarket.lookupPoeshopMarket(
              res.itemName,
              leagueName,
            );
            const target = lk.entry ?? null;
            if (target && (lk.prices || lk.variants.length > 1)) {
              const p = lk.prices;
              lines.push('', '### Витрина poeshop (офлайн-датасет)');
              if (p) {
                const div = p.divine != null ? `${p.divine} div` : '—';
                const ex = p.exalt != null ? `${p.exalt} ex` : '';
                lines.push(
                  `- Рыночный агрегат (${lk.league ?? '?'}): **${div}**${ex ? ` (${ex})` : ''}${p.chaos != null ? `, ${p.chaos} chaos` : ''}`,
                );
                if (lk.verdict) lines.push(`- **${lk.verdict.text}**`);
                lines.push(`- Срез: ${lk.freshness ?? '?'}; без листингов сверяй с trade2`);
              } else if (lk.variants.length > 1) {
                lines.push(`- Несколько вариантов баз (${lk.variants.length}) — см. тул poe2_unique_market.`);
              }
              if (!res.estimate) lines.push('- ⚠️ Бесплатные источники оценки не дали — это единственная доступная оценка.');
            }
          } catch {
            // офлайн-датасет недоступен (браузер) — секции просто не будет
          }
        }
        if (res.listings.length) {
          lines.push('', '### Листинги (trade2)');
          for (const l of res.listings.slice(0, 10)) {
            lines.push(`- **${l.price}** ${l.currency}`);
          }
        }
        const srcs = res.sources.length ? res.sources.join(', ') : '—';
        lines.push('', `Источники (${res.league ?? league}: ${srcs})`);
        return { content: [{ type: 'text', text: lines.join('\n') }] };
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return { isError: true, content: [{ type: 'text', text: `Ошибка прайс-чека: ${msg}` }] };
      }
    },
  );

  return 2;
}