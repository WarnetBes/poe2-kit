# Headless-PoB2 оракул (CI)

Эталонный источник чисел для `poe2_build_estimate` и формул из `docs/POB2_CALC_FORMULAS.md`.
Запускает **настоящий движок PoB2** без GUI штатным способом (так же делает и сам
PoB2 в CI: `cd src; luajit HeadlessWrapper.lua`, см. `.github/workflows/test.yml`
репозитория PathOfBuilding-PoE2).

## Файлы

| Файл | Назначение |
|---|---|
| `oracle.lua` | Сценарии (customMods) → `build.calcsTab.calcsOutput` → JSON-строки. Ключи сортированы, числа — 4 знака (детерминизм) |
| `run-oracle.ps1` | Раннер: задаёт `LUA_PATH/LUA_CPATH`, `CI=true` (не трогать ModCache), снимок, сравнение/golden-update |
| `compare-golden.mjs` | Точное сравнение (tolerance 1e-4), диф в stdout, exit 1 при любом расхождении |
| `golden-oracle.json` | Эталонный снимок (обновляется ТОЛЬКО осознанно, см. ниже) |
| `bin/luajit.exe`, `bin/lua51.dll`, `bin/luajit.exe.manifest` | LuaJIT 2.1 (luapower mingw64-сборка, лицензия MIT — Copyright Mike Pall) |

## Использование

```powershell
# проверка против golden (CI-режим)
powershell -ExecutionPolicy Bypass -File oracle\run-oracle.ps1
# осознанное обновление golden (смена данных/версии PoB2)
powershell -ExecutionPolicy Bypass -File oracle\run-oracle.ps1 -UpdateGolden
```

Требования: PathOfBuilding-PoE2 в `C:\TestPE\_research` (переопределяется `-PobSrc`).

## Сценарии (5)
`novelist_default` (база PoE2: Life 65, Mana 50, res -50...), `resists_200`
(сверка с TestDefence_spec: PhysicalMaxHit 650/260/38...), `pool_conversions`,
`reduced_pools`, `big_life`. Числа `resists_200` и `reduced_pools` подобраны по
assert'ам PoB2-спеков — оракул взаимно проверяем с апстримом.

## Политика golden
1. CI-джоба падает при расхождении — не «обновить и забыть»: сначала diff,
   понять причину (данные PoB2 обновились? формула кита уехала?).
2. `-UpdateGolden` — только с коммитом, объясняющим причину, в паре с обновлением
   формул/датасетов кита.
3. Новые сценарии добавляются в `oracle.lua` + `-UpdateGolden` в том же PR.

## CI SourceCraft (актуальный)

Исполняется нативно из `.sourcecraft/ci.yaml` (⚠️ git.sourcecraft.dev НЕ исполняет
GitHub Actions — врезка ниже оставлена только как портативный шаблон переезда):

- workflow `pob-oracle`, push в main + еженедельный cron (ловим дрейф данных PoB2);
- Docker-куб на образе апстрима `ghcr.io/pathofbuildingcommunity/pathofbuilding-tests:latest`
  (тот же, что в CI самого PoB2; `apk add curl unzip nodejs` на месте);
- исходники PoB2 стейджатся codeload-zip'ом, **пинн `v0.23.1`** — версия, на которой
  выверен golden; смена пина ТОЛЬКО вместе с осознанным обновлением golden;
- `run-oracle.sh pob2/src` → снимок + `node compare-golden.mjs`, расхождение красит джобу;
- артефакт `oracle/oracle-output.jsonl` хранится 14 дней (панель CI/CD SourceCraft).

Проверено 2026-09-27: run #3 — success, `PASS: 5 сценариев совпали с golden`.

## GitHub Actions (портативный шаблон переезда)

```yaml
name: PoB2 oracle
on:
  push: { branches: [ main, dev ] }
  pull_request: { branches: [ main, dev ] }
  schedule: [{ cron: '0 6 * * 1' }]  # еженедельно ловим дрейф данных PoB2
jobs:
  oracle:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - name: Checkout PathOfBuilding-PoE2 (pinned)
        uses: actions/checkout@v4
        with:
          repository: PathOfBuildingCommunity/PathOfBuilding-PoE2
          ref: '<пинн tag для воспроизводимости>'
          path: _research/PathOfBuilding-PoE2
      - run: powershell -ExecutionPolicy Bypass -File oracle/run-oracle.ps1
        shell: pwsh
```

Linux-вариант: вместо luapower-бинаря — `ghcr.io/pathofbuildingcommunity/pathofbuilding-tests`
(тот же образ, что и CI PoB2; внутри есть `luajit`). Задачаائق: `cd src && LUA_PATH='?.lua;../runtime/lua/?.lua' luajit ../../oracle/oracle.lua`.

## Headless-хост v2 (эпика, Фазы 1–2 — 11.10.2026)

Интерактивный line-JSON-RPC хост `headless/pob_host.lua` поверх того же движка:
one-shot (stdin = запросы, EOF = выход), startup-фрейм `{ready, runtimeContract}` (контракт 2),
методы `ping/new_build/load_build_xml/set_level/set_config/stats` +
Фаза 2: `restore_config` (откат по снимку `before` из set_config), `get_config_schema`
(enum-списки движка), `snapshot_build`/`restore_build` (полный XML-откат).
`set_config` валидирует enum-значения (невалид → `{ok:false, errors}`, ничего не применяется)
и автоматически применяет резисты тира врага: Boss 30 / Pinnacle 50 / Uber 50 / None 0 —
апстрим в headless ставит их только как GUI-плейсхолдеры (ConfigOptions.lua apply → SetPlaceholder).
Потребляет MCP-тул `poe2_recompute` (обвязка `packages/core/src/pobHost.ts`).
Спека фаз и границы: `docs/pob_headless_epic.md`.

```powershell
# рантайм LuaJIT (luapower mingw64, MIT © Mike Pall; SHA256-гейт, в git не идёт):
node oracle\setup-headless.mjs
# env как у run-oracle.ps1 (+ POE2K_POB2_SRC для MCP-тула), дальше — stdio.
```

## Почему не GUI-экзешник
`runtime\Path{space}of{space}Building-PoE2.exe` аргументы скриптов не принимает
(проверено: запускает GUI) — headless-режим в PoB2 достигается только отдельным
интерпретатором LuaJIT. Строковая таблица `newBuild()`/`loadBuildFromXML()`
глобальна после `dofile("HeadlessWrapper.lua")`.
