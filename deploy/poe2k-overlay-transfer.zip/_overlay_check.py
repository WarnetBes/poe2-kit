# -*- coding: utf-8 -*-
"""Проверка наложений текста в схеме (bbox overlap)."""
from PIL import Image, ImageDraw, ImageFont

SCALE = 2
def f(size, bold=False):
    name = "segoeuib" if bold else "segoeui"
    try:
        return ImageFont.truetype(name + ".ttf", int(size * SCALE))
    except OSError:
        return ImageFont.load_default()

texts = []

def T(x, y, s, size=12, bold=False, anchor=None, w=1760):
    # приближённая ширина по font
    fo = f(size, bold)
    bb = fo.getbbox(s)
    tw = (bb[2] - bb[0]) / SCALE
    if anchor == "ma":
        x0 = x - tw / 2
    elif anchor == "ra":
        x0 = x - tw
    else:
        x0 = x
    y0 = y
    texts.append((x0, y0, x0 + tw, y0 + size, s[:40], x, anchor))

# ── Воспроизвести все тексты из _overlay_scheme.py ──
W = 1760; MX = 40
T(W//2, 26, "PoE2 Kit Overlay — детализированная схема", 20, True, "ma")
T(W//2, 58, "Electron: main (процесс) ↔ preload (мост) ↔ renderer (виджет) · поверх окна PoE2", 12, False, "ma")

Y = 88
T(MX, Y, "1. АРХИТЕКТУРА И ПОТОКИ ДАННЫХ", 14, True)
Y += 10
game_top, game_bot = Y+16, Y+236
T(MX+128, game_top+14, "ОКНО ИГРЫ PoE2", 11, True, "ma")
T(MX+128, game_top+36, "(Win32: findGameWindow,\nfindWindowRect — через koffi)", 9, False, "ma")
T(MX+128, game_top+49, "findWindowRect — через koffi)", 9, False, "ma")
mm_x0, mm_y0 = MX+280, Y+16
T(mm_x0+10, mm_y0+8, "MAIN-ПРОЦЕСС (main.ts)", 11, True)
b1x, b1y = mm_x0+14, mm_y0+32
for bx, t in [(b1x,"globalShortcut"),(b1x+214,"BrowserWindow"),(b1x+448,"clipboard + win32.ts"),(b1x+702,"@poe2-kit/core (ядро)")]:
    T(bx+100, b1y+10, t, 10, True, "ma")
T(b1x+100, b1y+26, "7 хоткеев", 9, False, "ma"); T(b1x+100, b1y+38, "registerHotkeys()", 9, False, "ma")
T(b1x+324, b1y+26, "overlayWindow: прозрачное,", 9, False, "ma"); T(b1x+324, b1y+38, "всегда-поверх, click-through", 9, False, "ma")
T(b1x+568, b1y+26, "readText() · Ctrl+C из игры", 9, False, "ma"); T(b1x+568, b1y+38, "isGameForeground()", 9, False, "ma")
T(b1x+860, b1y+26, "priceCheck · parse · zoneNotes", 9, False, "ma"); T(b1x+860, b1y+38, "log (Client.txt) · build · trade", 9, False, "ma")
T(mm_x0+14+120, mm_y0+112, "ipcMain.handle", 9, True, "ma")
T(mm_x0+160, mm_y0+112, "invoke ↓", 9, False, "ma")
T(b1x+560, mm_y0+112, "price:result · price:busy · level:result · build:update · move:mode · settings:toggle/display", 9, False, "ma")
T(MX+670, Y+154+17, "PRELOAD (preload.ts) — contextBridge: window.poe2k.*  (contextIsolation: true)", 10, True, "ma")
T(MX+670, Y+198+19, "RENDERER (rendererHtml.ts) — один DOM, секции по действиям", 10, True, "ma")
sx = MX+1088
T(sx+(W-MX-16-sx)//2, Y+28, "СЕКЦИИ DOM (#panel)", 10, True, "ma")
dom_items = [("#idle","стартовый экран (Ctrl+F1/F3/F2)"),("#body → #est / #buildNote / #err / #meta","результат Ctrl+F1 + листинги"),
             ("#lvlWrap","зона + подсказки (Ctrl+F4)"),("#buildWrap","шопинг-лист + 💎 камни (Ctrl+F2)"),
             ("#settingsPanel","настройки (Ctrl+F6)"),("#grab","полоса тащи-меня (Ctrl+F5)"),("#hint","постоянная строка хоткеев внизу")]
for i,(t,s) in enumerate(dom_items):
    yy = Y+46+i*25
    T(sx+12, yy, t, 10, True)
    T(sx+262, yy+1, s, 10, False)
T(MX+252, game_top+18, "привязка к углу", 9, False, "ma")

Y = Y+282
T(MX, Y, "2. ГОРЯЧИЕ КЛАВИШИ — реестр registerHotkeys()", 14, True)
Y += 10
tbl_w = W - MX*2
hdr = ["Действие","По умолчанию","Куда (IPC / реакция main)","Результат в виджете"]
colw = [170,150,430,tbl_w-750]
yy = Y
cx = MX+12
for i,h in enumerate(hdr):
    T(cx, yy+7, h, 10, True); cx += colw[i]
yy += 30
rows = [("price","Ctrl+F1","runPriceCheck()","прайс предмета из буфера (trade2/poe.ninja)"),
        ("buildPanel","Ctrl+F2","toggleBuildPanel()","шопинг-лист билда + 💎 сетапы камней"),
        ("buildImport","Ctrl+F3","runBuildImport()","импорт PoB-кода / автосинхронизация с персонажем"),
        ("leveling","Ctrl+F4","runLevelingContext()","зона, подсказки, 3 следующие зоны (Client.txt)"),
        ("move","Ctrl+F5","toggleMoveMode()","режим перемещения окна мышью"),
        ("settings","Ctrl+F6","toggleSettingsPanel()","панель настроек (overlay-settings.json)")]
for name,hk,fn,out in rows:
    yy += 0
    T(MX+12, yy+11, name, 10, True)
    T(MX+12+170+59, yy+17, hk, 10, True, "ma")
    T(MX+12+170+150, yy+11, fn, 10, False)
    T(MX+12+170+150+430, yy+11, out, 10, False)
    yy += 38
T(MX+12, yy+8, "Ctrl+Shift+F5  (жёстко, не переопределяется)  →  resetOverlayOffset()", 10, True)
T(MX+12, yy+26, "сброс пользовательского смещения: возвращает оверлей в штатный угол окна игры + выход из move-режима", 10, False)
Y = yy+62
T(MX, Y, "Механика: hotkeyFor(action) = settings.hotkeys[action] ?? DEFAULT_HOTKEYS[action]. При «Сохранить» — globalShortcut.unregisterAll() и перерегистрация.", 10, False)

Y += 26
T(MX, Y, "3. ПАНЕЛЬ НАСТРОЕК (Ctrl+F6) — OverlaySettings", 14, True)
Y += 10
sw = (tbl_w-30)//2
T(MX+12, Y+10, "ПАРАМЕТРЫ (слайдеры/кнопки)", 10, True)
params = [("opacity — прозрачность фона","25% – 100%  (default 86%)","CSS-переменная --bg: альфа rgba(13,17,23,a); текст остаётся читаемым"),
          ("scale — масштаб UI","70% – 140%, шаг 5  (default 100%)","CSS zoom на #panel"),
          ("width — ширина панели","280 – 640 px, шаг 10  (default 420)","setBounds BrowserWindow (DIP)"),
          ("corner — угол привязки","В·л / В·п / Н·л / Н·п  (default top-right)","пересчёт позиции от rect окна игры (findWindowRect)")]
py = Y+32
for name,rng,how in params:
    T(MX+12, py, name, 10, True)
    T(MX+12, py+15, rng, 10, False)
    T(MX+12, py+30, how, 9, False)
    py += 46
rx = MX+sw+30
T(rx+12, Y+10, "ГОРЯЧИЕ КЛАВИШИ — hkGrid (6 полей)", 10, True)
hkrows = [("Прайс","Ctrl+F1"),("Прокачка","Ctrl+F4"),("Перемещение","Ctrl+F5"),
          ("Импорт билда","Ctrl+F3"),("Панель билда","Ctrl+F2"),("Настройки","Ctrl+F6")]
hy = Y+32
for i,(label,defhk) in enumerate(hkrows):
    T(rx+16, hy, label, 10, False)
    T(W-MX-26, hy, defhk, 10, False, "ra")
    hy += 22
T(rx+12, hy+4, "Пустое поле = стандарт (подсвечен как placeholder). Формат: Control+F1, Alt+Shift+Q.", 9, False)
T(rx+12, hy+18, "Кнопки: «Сбросить клавиши» (очищает 6 полей) · «Сохранить» → settings:apply → normalizeSettings (вкладывает диапазоны)", 9, False)
T(rx+12, hy+42, "→ applySettings + запись userData/overlay-settings.json. Ошибка — на кнопке на 2,5 с.", 9, False)
Y += 226

T(MX, Y, "4. ФАЙЛЫ В userData (app.getPath('userData') = %APPDATA%\\@poe2-kit\\overlay)", 14, True)
Y += 10
files = [("overlay-settings.json","corner / opacity / scale / width / hotkeys — переживает перезапуск"),
         ("overlay.log  (+ .1)","тень console.log/warn/error; ротация > 1 МБ (rename → .1, старый удалён)"),
         ("game-log-path.txt","опциональный путь к Client.txt (автодетект по дискам иначе)"),
         ("build-state.json","slots (status todo/bought, worn), summary (EHP/gaps/DPS), gemSetups, panelVisible"),
         ("char-sync.json","account/league/character/lastSyncAt — троттлинг 5 мин между запросами poe.ninja"),
         ("league.txt + localStorage 'poe2k.league'","выбранная лига (league:get/set → core.trade.setLeague)")]
for i,(n,s) in enumerate(files):
    yy = Y+i*27
    T(MX+8, yy+5, n, 10, True)
    T(MX+344, yy+5, s, 10, False)
Y += len(files)*27+10

T(MX, Y, "5. ГОРЯЧИЕ ПУТИ", 14, True)
Y += 10
paths = [("Ctrl+F1 — прайс","clipboard.readText() → core.parse.parseItemText → core.trade.priceCheck (trade2 + poe.ninja) → price:result.\nЕсли есть buildState: matchBuildSlot(имя/base) → отметка слота 'bought' + строка «✔ Слот билда: …».\nЕсли буфер похож на PoB-код → подсказка «нажмите Ctrl+F3» (buildCodeHint)."),
         ("Ctrl+F4 — прокачка","core.log.getClientState (Client.txt, bounded tail) → core.zoneNotes.getLevelingContext → level:result.\nПоказ: зона (G{act}_{area}), русские заметки (notes_ru), hints, 3 следующие зоны (уровень, Δ, награды)."),
         ("Ctrl+F5 — перемещение","toggleMoveMode: setIgnoreMouseEvents(false) + setFocusable(true) + полоса #grab.\nТаскание мышью → userOffset (DIP от закреплённого угла). Повторный Ctrl+F5 — закрепить. Ctrl+Shift+F5 — полный сброс."),
         ("Ctrl+F3 — импорт","PoB share-код/ссылка → core.build.buildCodeToGear + estimateBuild → build-state.json → фоновый прайсинг слотов (token отмены).\nСсылка на персонажа poe.ninja → автосинхронизация worn-эквипа (не затирает целевой билд, троттлинг 5 мин).")]
pw = (tbl_w-20)//2
for i,(t,s) in enumerate(paths):
    bx = MX+(i%2)*(pw+20); by = Y+(i//2)*118
    T(bx+12, by+8, t, 11, True)
    lines = s.split("\n")
    for j,ln in enumerate(lines):
        T(bx+12, by+28+j*14, ln, 9, False)
Y += 2*118+12
T(MX, Y+10, "Код: apps/overlay/src/{main.ts, preload.ts, rendererHtml.ts, win32.ts} · core: packages/core/src/{trade.ts, parse.ts, build.ts, log.ts, zoneNotes.ts, estimate.ts}", 9, False)
T(W-MX, Y+10, "по коду на 25.09.2026", 9, False, "ra")

# Проверка пересечений
def overlap(a, b):
    ax0,ay0,ax1,ay1,_,_,_ = a
    bx0,by0,bx1,by1,_,_,_ = b
    return ax0 < bx1 and bx0 < ax1 and ay0 < by1 and by0 < ay1

bad = 0
for i in range(len(texts)):
    for j in range(i+1, len(texts)):
        a, b = texts[i], texts[j]
        if overlap(a, b):
            # игнор: одинаковые (многострочные dубликаты)
            if a[4] == b[4]: continue
            ax0,ay0,ax1,ay1 = a[:4]; bx0,by0,bx1,by1 = b[:4]
            ox = min(ax1,bx1)-max(ax0,bx0); oy = min(ay1,by1)-max(ay0,by0)
            if ox > 4 and oy > 3:
                bad += 1
                print(f"OVERLAP ({ox:.0f}x{oy:.0f}): [{a[4]}] y={a[1]:.0f}  vs  [{b[4]}] y={b[1]:.0f}")
print("total texts:", len(texts), "overlaps:", bad)
# проверка вылета за правый край
for t in texts:
    if t[2] > W - 30:
        print(f"RIGHT-EDGE: x1={t[2]:.0f} [{t[4]}] x={t[5]} anchor={t[6]}")
