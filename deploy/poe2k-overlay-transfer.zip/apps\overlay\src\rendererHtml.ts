/**
 * PoE2 Kit — Windows-оверлей: HTML + CSS + классический скрипт виджета.
 * Рендерер общается с main через preload-мост `window.poe2k`.
 * Скрипт без module-импортов, поэтому грузится из файла без CORS-проблем.
 */
import { T_DICT, CRAFT_SYSTEMS, TAB_INFO } from './rendererData.js';
import { SLANG_SECTIONS, SLANG_GLOSSARY } from '@poe2-kit/core';
import { liveIssues, listKnownTricks } from '@poe2-kit/core';
import { compactStarterBuildGuides, compactStarterClasses, compactStarterMeta } from './starterGuidesData.js';
import { OVERLAY_CSS } from './rendererCss.js';
import { OVERLAY_SHELL } from './rendererShell.js';

export const rendererHtml = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self'" />
<title>PoE2 Kit — оверлей</title>
<style>${OVERLAY_CSS}</style>
</head>
${OVERLAY_SHELL}<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ─── №158: EN-локализация панели ────────────────────────────────────────────
  // Механика: словарь RU→EN (T_DICT) + проход по DOM (applyLang): текстовые
  // узлы, title/placeholder. Составные фразы покрываются СЕГМЕНТАМИ словаря
  // ('Побед: '), промах = RU-фолбэк (ничего не ломается). Dynamic renders ловит
  // MutationObserver на #panel (debounce 50мс). Прогресс меряется CDP-скриптом:
  // кириллица в DOM при lang=en = backlog словаря.
  var LANG = null; // 'ru' | 'en' — устанавливается в applyLang()
  var T_DICT = ${JSON.stringify(T_DICT, null, 2)};
  // Отсортированные ключи по убыванию длины — сперва длинные, чтобы
  // «Акт 1» не побилось коротким ключом раньше составного.
  var T_KEYS = Object.keys(T_DICT).sort(function (a, b) { return b.length - a.length; });

  function tStr(s) {
    if (LANG !== 'en' || !s) return s;
    if (T_DICT[s] != null) return T_DICT[s];
    var out = s, idx;
    for (var i = 0; i < T_KEYS.length; i++) {
      idx = out.indexOf(T_KEYS[i]);
      if (idx >= 0) out = out.replace(T_KEYS[i], T_DICT[T_KEYS[i]]);
    }
    return out;
  }

  function applyLang(lang) {
    LANG = lang === 'en' ? 'en' : 'ru';
    document.documentElement.setAttribute('lang', LANG);
    document.title = LANG === 'en' ? 'PoE2 Kit — overlay' : 'PoE2 Kit — оверлей';
    if (LANG === 'en') {
      // Полный проход по DOM: text-узлы + title/placeholder.
      // SCRIPT/STYLE исключаем: их текст — исходник, не UI.
      var filter = { acceptNode: function (n) {
        var p = n.parentElement;
        if (p && (p.nodeName === 'SCRIPT' || p.nodeName === 'STYLE')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      } };
      var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, filter);
      var nodes = [];
      while (walker.nextNode()) nodes.push(walker.currentNode);
      nodes.forEach(function (n) { if (/[А-Яа-яЁё]/.test(n.nodeValue)) n.nodeValue = tStr(n.nodeValue); });
      var attrs = document.querySelectorAll('[title],[placeholder]');
      for (var i = 0; i < attrs.length; i++) {
        var el = attrs[i];
        if (el.title && /[А-Яа-яЁё]/.test(el.title)) el.title = tStr(el.title);
        if (el.placeholder && /[А-Яа-яЁё]/.test(el.placeholder)) el.placeholder = tStr(el.placeholder);
      }
    }
  }

  // №158: dynamic renders при lang=en — единый observer вместо правки 80 render-функций.
  var __langObserver = null;
  function startLangObserver() {
    if (__langObserver || LANG !== 'en' || !document.body) return;
    var pending = null;
    __langObserver = new MutationObserver(function () {
      if (pending) return;
      pending = setTimeout(function () {
        pending = null;
        if (LANG !== 'en') return;
        applyLang('en'); // повторный проход — новые узлы; старые уже без кириллицы (кроме данных предметов)
      }, 50);
    });
    __langObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  function stopLangObserver() {
    if (__langObserver) { __langObserver.disconnect(); __langObserver = null; }
  }


  function setBusy(b) {
    $('busy').classList.toggle('hide', !b);
    $('idle').classList.toggle('hide', b);
    $('body').classList.toggle('hide', b);
  }

  // ─── Watchlist ──────────────────────────────────────────────────────────────
  var watchTarget = null;        // предмет в детальном прайс-виде (для кнопки «Следить»)
  var batchWatchTargets = [];    // предметы в пачке (индекс ↔ data-idx кнопок «Следить»)

  function showToast(msg) {
    var t = $('toast');
    if (!t) return;
    t.innerHTML = msg;
    t.classList.remove('hide');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(function () { t.classList.add('hide'); }, 3500);
    requestSize();
  }

  function doWatchAdd(t, btn) {
    if (!t || !t.itemText) return;
    window.poe2k.watchAdd({ itemText: t.itemText, label: t.label, rarity: t.rarity }).then(function (r) {
      if (r && r.ok) {
        if (btn) { btn.textContent = '✓ В списке'; btn.disabled = true; }
        showToast('✓ Добавлено в watchlist: ' + esc(t.label));
      } else {
        showToast('Не удалось добавить в watchlist');
      }
    }).catch(function () {});
  }

  // Кнопка «Следить» в детальном прайс-токе.
  $('watchBtn').addEventListener('click', function () { doWatchAdd(watchTarget, this); });

  // Кнопки «Следить» в карточках пачки (делегирование).
  $('priceBatchList').addEventListener('click', function (ev) {
    var btn = ev.target && ev.target.closest ? ev.target.closest('.batch-ww') : null;
    if (!btn || btn.disabled) return;
    var idx = btn.getAttribute('data-idx');
    doWatchAdd(batchWatchTargets[idx], btn);
  });

  // Всплывающий алерт «цена упала с X до Y» из main.
  window.poe2k.onWatchAlert(function (a) {
    if (!a) return;
    var from = Number(a.from), to = Number(a.to), l = String(a.label || 'Предмет');
    var fromTxt = Number.isFinite(from) ? fmtChaosNum(from) : '—';
    var toTxt = Number.isFinite(to) ? fmtChaosNum(to) : '—';
    showToast('<b>📉 Цена упала:</b> ' + esc(l) + '<br/>' + fromTxt + ' → ' + toTxt + ' chaos');
  });

  // №85: агент -> оверлей: тост-уведомление поверх игры от MCP-агента.
  window.poe2k.onAgentNotify(function (m) {
    if (!m) return;
    var t = String(m.title || '🤖 Агент');
    var x = String(m.text || '');
    showToast('<b>' + esc(t) + '</b>' + (x ? '<br/>' + esc(x) : ''));
  });

  function refreshWatchlist() {
    window.poe2k.watchList().then(function (r) {
      var entries = (r && r.entries) || [];
      var box = $('watchList');
      if (!box) return;
      if (!entries.length) {
        box.innerHTML = '<div class="empty">Список пуст. Нажмите «👁 Следить» в прайс-токе или «➕ Из буфера».</div>';
        requestSize();
        return;
      }
      box.innerHTML = entries.map(function (e) {
        var px = (e.lastPrice == null) ? '—' : fmtChaosNum(e.lastPrice) + ' chaos';
        return '<div class="wl-row">' +
          '<span class="nm ' + (e.enabled ? '' : ' off') + '">' + esc(e.label) + (e.enabled ? '' : ' <small>(пауза)</small>') + '</span>' +
          '<span class="px ' + (e.enabled ? '' : ' off') + '">' + px + '</span>' +
          '<button data-act="tg" data-id="' + esc(e.id) + '">' + (e.enabled ? '⏸' : '▶') + '</button>' +
          '<button data-act="rm" data-id="' + esc(e.id) + '" title="Убрать">✕</button>' +
          '</div>';
      }).join('');
      requestSize();
    }).catch(function () {});
  }

  // Управление списком watchlist: пауза/вкл / удалить (делегирование).
  $('watchList').addEventListener('click', function (ev) {
    var btn = ev.target && ev.target.closest ? ev.target.closest('button[data-act]') : null;
    if (!btn) return;
    var act = btn.getAttribute('data-act');
    var id = btn.getAttribute('data-id');
    if (act === 'tg') window.poe2k.watchToggle(id).then(refreshWatchlist);
    else if (act === 'rm') window.poe2k.watchRemove(id).then(refreshWatchlist);
  });

  $('watchAddBuffer').addEventListener('click', function () {
    window.poe2k.watchAddBuffer().then(function (r) {
      refreshWatchlist();
      if (r && r.ok) showToast('✓ Предмет из буфера добавлен в watchlist');
      else showToast('Буфер пуст — нажмите Ctrl+C на предмете в игре');
    }).catch(function () {});
  });

  $('watchCheckNow').addEventListener('click', function () {
    showToast('Проверяю цены watchlist…');
    window.poe2k.watchCheck().then(function () { setTimeout(refreshWatchlist, 900); }).catch(function () {});
  });

  // Авторазмер окна: контент панели изменился — просим main подогнать высоту.
  // Панель не имеет CSS-клэмпа (иначе autosize зацикливается на размере окна,
  // лог-факты №60–61): меряем ЧЕСТНУЮ высоту контента без клэмпа, main возвращает
  // фактическую высоту окна (с учётом кэпа workArea) — ею клэмпим панель, чтобы
  // при кэпе включились локальные скроллы (#buildWrap/#listWrap/#lvlWrap).
  var _sizeTimer = null;
  function requestSize() {
    if (_sizeTimer) clearTimeout(_sizeTimer);
    _sizeTimer = setTimeout(function () {
      var p = document.getElementById('panel');
      var clamped = p.style.maxHeight;
      // Снимаем клэмп ТОЛЬКО на sync-измерение и возвращаем его В ТОЙ ЖЕ
      // задаче JS, ДО отрисовки кадра: асинхронный возврат (№61) держал панель
      // развёрнутой на естественную высоту (билд ~2000px) пару кадров —
      // визуально контент «скачет» (жалоба №63), ResizeObserver зацикливался.
      p.style.maxHeight = 'none';
      var h = Math.ceil(p.getBoundingClientRect().height);
      p.style.maxHeight = clamped || 'none';
      if (h > 40 && window.poe2k.autosize) {
        window.poe2k.autosize(h).then(function (actual) {
          var a = Math.max(0, Math.round(Number(actual) || 0));
          if (a > 0) p.style.maxHeight = a + 'px';
        }).catch(function () {});
      }
    }, 60);
  }
  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(requestSize).observe(document.getElementById('panel'));
  }
  requestSize();

  window.poe2k.onPriceBusy(function (b) {
    if (b) setBusy(true);
  });

  // Режим перемещения: показываем полосу перетаскивания и прячем контент.
  window.poe2k.onMoveMode(function (state) {
    var grab = $('grab');
    grab.classList.toggle('hide', !state.unlocked);
    document.body.style.background = state.unlocked ? 'rgba(198,154,82,0.04)' : 'transparent';
    if (state.unlocked) {
      $('idle').classList.remove('hide');
      $('body').classList.add('hide');
    }
  });

  $('resetOffset').addEventListener('click', function () {
    window.poe2k.resetOffset();
  });

  function showMode(mode) {
    // mode: 'price' | 'level' | 'build' | 'gems' | 'maps' | 'pinnacle' | 'slang' | 'craft' | 'rates' | 'gen' | 'import' | 'radar' — показываем только нужные блоки.
    $('est').classList.toggle('hide', mode !== 'price');
    $('augLine').classList.toggle('hide', mode !== 'price');
    $('statBanner').classList.toggle('hide', mode !== 'price');
    $('listWrap').classList.toggle('hide', mode !== 'price');
    $('buildNote').classList.toggle('hide', mode !== 'price');
    $('meta').classList.toggle('hide', mode !== 'price');
    $('watchBtnWrap').classList.toggle('hide', mode !== 'price');
    $('lvlWrap').classList.toggle('hide', mode !== 'level');
    $('buildWrap').classList.toggle('hide', mode !== 'build');
    $('gemsWrap').classList.toggle('hide', mode !== 'gems');
    $('mapsWrap').classList.toggle('hide', mode !== 'maps');
    $('pinnacleWrap').classList.toggle('hide', mode !== 'pinnacle');
    $('ritualWrap').classList.toggle('hide', mode !== 'ritual');
    $('slangWrap').classList.toggle('hide', mode !== 'slang');
    $('craftWrap').classList.toggle('hide', mode !== 'craft');
    $('ratesWrap').classList.toggle('hide', mode !== 'rates');
    $('genWrap').classList.toggle('hide', mode !== 'gen');
    $('importWrap').classList.toggle('hide', mode !== 'import');
    $('suppadvWrap').classList.toggle('hide', mode !== 'suppadv');
    $('radarWrap').classList.toggle('hide', mode !== 'radar');
    $('starterbuildsWrap').classList.toggle('hide', mode !== 'starterbuilds');
    updateScrollCtl();
  }

  // ─── №132: детерминированная прокрутка панели мышью (кнопки ▲/▼) ──────────
  // Живой репорт: колесо над оверлеем не прокручивает панель Билда —
  // окно нефокусируемое/click-through, доставка wheel-событий не гарантирована.
  // Кнопки работают во ВСЕХ режимах с локальным скроллом и не зависят от фокуса.
  var SCROLL_WRAPS = ['buildWrap', 'listWrap', 'lvlWrap', 'gemsWrap', 'mapsWrap', 'pinnacleWrap', 'ritualWrap', 'slangWrap', 'craftWrap', 'ratesWrap', 'genWrap', 'importWrap', 'suppadvWrap', 'radarWrap', 'starterbuildsWrap'];
  function activeScrollWrap() {
    for (var i = 0; i < SCROLL_WRAPS.length; i++) {
      var el = $(SCROLL_WRAPS[i]);
      if (el && !el.classList.contains('hide') && el.scrollHeight > el.clientHeight + 20) return el;
    }
    return null;
  }
  function updateScrollCtl() {
    var ctl = $('scrollCtl');
    if (!ctl) return;
    ctl.classList.toggle('hide', !activeScrollWrap());
  }
  (function () {
    var ctl = $('scrollCtl');
    if (!ctl) return;
    var SCROLL_STEP_PX = 220; // ~ треть высоты панели за клик
    $('scrlUp').addEventListener('click', function () {
      var w = activeScrollWrap();
      if (w) w.scrollBy({ top: -SCROLL_STEP_PX, behavior: 'smooth' });
    });
    $('scrlDn').addEventListener('click', function () {
      var w = activeScrollWrap();
      if (w) w.scrollBy({ top: SCROLL_STEP_PX, behavior: 'smooth' });
    });
  })();
  // Телеметрия №132: приходят ли wheel-события в renderer вообще (первое за
  // сессию пишем в консоль → overlay.log через console-message дубликатор).
  var wheelSeen = false;
  document.addEventListener('wheel', function (ev) {
    if (!wheelSeen) {
      wheelSeen = true;
      console.log('[overlay] renderer: wheel дошёл (deltaY=' + (ev.deltaY || 0) + ', режим=' + (winUnlocked ? 'move' : 'hover') + ')');
    }
  }, { passive: true, capture: true });
  // Контент в врапе вырос/скролл появился — перепроверяем кнопки.
  if (typeof ResizeObserver !== 'undefined') {
    var ro2 = new ResizeObserver(function () { updateScrollCtl(); });
    SCROLL_WRAPS.forEach(function (id) {
      var el = $(id);
      if (el) ro2.observe(el);
    });
  }

  // ─── Вкладка «📥 Импорт» (№101): собственный вью вместо прыжка на «Билд» ─────
  // Раньше клик по табу сразу запускал runBuildImport и onBuildUpdate
  // переключал showMode('build') — друг читал это как «вкладку перекинуло».
  // Теперь таб показывает инструкцию/результат; запуск — кнопкой или Ctrl+F3.
  var importResult = null; // последний build:update от импорта (для повтора клика)
  function showImportView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    showMode('import');
    var el = $('importContent');
    var html =
      '<div class="sub-h sub">📥 Импорт билда из буфера обмена</div>' +
      '<div class="lvl-hint">Скопируйте <b>PoB share-код</b>, ссылку профиля poe.ninja или .build JSON и нажмите кнопку ниже (или <b>Ctrl+F3</b>).</div>' +
      '<button class="watch-btn" id="importRun" style="margin:4px 0 6px">📥 Импортировать из буфера (Ctrl+F3)</button>';
    if (importResult) {
      if (importResult.error) {
        html += '<div class="err-box">⚠ ' + esc(importResult.error) + '</div>';
      } else if (importResult.ok) {
        html += '<div class="lvl-hint">✅ Импортировано: <b>' + esc(importResult.ok) +
          '</b><br/><span class="sub">Панель слотов — во вкладке «🛒 Билд» (Ctrl+F2).</span></div>';
      }
    } else if (lastBuildState && lastBuildState.slots && lastBuildState.slots.length) {
      html += '<div class="lvl-hint">Текущий билд: <b>' + esc(String(lastBuildState.className || '?')) + '</b>, ' +
        lastBuildState.slots.length + ' слотов — будет заменён новым импортом.</div>';
    }
    el.innerHTML = html;
    $('importRun').addEventListener('click', function () {
      el.innerHTML = '<div class="status-busy">Импорт из буфера…</div>';
      window.poe2k.panelOpen('import').catch(function () {});
    });
  }

  // ─── Вкладка «🧭 Плитки» (№85): крафт плиток смотрителя (Waystones) ────────
  // Статический справочник — факты poe2wiki.net (page 1720, проверено 2026-09-30).
  // Обновляется вручную при патче механик; источник даты — в подвале панели.
  function renderMapsTab() {
    var el = $('mapsContent');
    el.innerHTML =
      '<div class="lvl-hint">Плитки: тиры 1–16, моды до 6 (3 пре + 3 суф), обычная/волшебная/редкая. ' +
      'Моды переносятся на карту при активации.</div>' +
      '<table class="bld">' +
      '<tr><td colspan="4"><b>Самые ценные рецепты</b></td></tr>' +
      '<tr><td class="slot" colspan="4">1️⃣ <b>Тир 16</b> — только коррупцией Т15: 25% шанс «тир ±1» (реролл модов). ' +
      '<span class="sub">Единственный путь к Т16.</span></td></tr>' +
      '<tr class="wornrow"><td></td><td class="worn" colspan="3">Исходы коррупции (каждый 25%): ничего · тир ±1 · ' +
      'лок префиксов+рефж суффиксов (или наоборот, игнор лимита) · лок обоих + 0–4 доп. мода (до 8 всего)</td></tr>' +
      '<tr><td class="slot" colspan="4">2️⃣ <b>Верстак перековки</b>: 3 плитки одинакового тира и редкости → 1 плитка тиром выше. <span class="sub">Стабильный ап-тир без риска.</span></td></tr>' +
      '<tr><td class="slot" colspan="4">3️⃣ <b>Omens</b>: Omen of Chaotic Rarity / Quantity / Monsters — ' +
      'меняют редкость/количество/монстров необычным путём, недоступным базовой валюте. <span class="sub">Ключ к жирным картам.</span></td></tr>' +
      '<tr><td colspan="4" style="padding-top:6px"><b>Возрождения (revives)</b></td></tr>' +
      '<tr><td class="slot" colspan="4">Каждый явный мод плитки = −1 возрождение карты: 6 без модов → 0 при 6+ модах. ' +
      '<span class="sub">Жирная карта = без права на ошибку.</span></td></tr>' +
      '</table>' +
      '<div class="lvl-hint">🎯 Персональный план: скопируйте Waystone-плитку в игре (Ctrl+C) и нажмите Ctrl+F1 — ' +
      'кит покажет крафт-план под её тир (3:1 перековка / коррупция Т15→Т16 омены/качество).</div>' +
      '<div class="sub src-note">Источник: poe2wiki.net «Waystone» (проверено 30.09.2026). ' +
      'Механики меняются патчами — панель обновляется в ките.</div>';
  }
  function showMapsView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '🧭 Крафт плиток смотрителя';
    showMode('maps');
    renderMapsTab();
    requestSize();
  }

  // ─── Вкладка «📖 Слэнг» (№133): словарь игрового слэнга/сокращений ─────────
  // Жаргон PoE2 по-человечески: что говорят в чатах/гайдах и что это значит.
  // Только устоявшиеся термины сообщества; разделы переключаются чипсами
  // (паттерн №129 — мышь, без клавиатуры). Фильтр-чипсы + таблица.
  var SLANG_SECTIONS = ${JSON.stringify(SLANG_SECTIONS, null, 2)};
  // [ термин, пояснение по-человечески, раздел ]
  var SLANG_GLOSSARY = ${JSON.stringify(SLANG_GLOSSARY, null, 2)};
  var slangFilter = 'all';
  function renderSlangTab() {
    var host = $('slangContent');
    if (!host) return;
    var chips = SLANG_SECTIONS.map(function (s) {
      return '<button class="tree-chip' + (slangFilter === s[0] ? ' on' : '') +
        '" data-sf="' + s[0] + '">' + s[1] + '</button>';
    }).join('');
    var rows = SLANG_GLOSSARY
      .filter(function (e) { return slangFilter === 'all' || e[2] === slangFilter; })
      .sort(function (a, b) { return a[0].toLowerCase() < b[0].toLowerCase() ? -1 : 1; })
      .map(function (e) {
        return '<div class="slang-row"><div class="slang-term">' + e[0] + '</div>' +
          '<div class="slang-def">' + e[1] + '</div></div>';
      }).join('');
    host.innerHTML =
      '<div class="tree-chips" id="slangChips">' + chips + '</div>' +
      '<div class="slang-hint">Слэнг и сокращения PoE2 — по-человечески. Разделы — мышкой.</div>' +
      rows;
    var ch = host.querySelectorAll('#slangChips .tree-chip');
    for (var i = 0; i < ch.length; i++) {
      ch[i].addEventListener('click', function () {
        slangFilter = this.getAttribute('data-sf');
        renderSlangTab();
      });
    }
  }
  function showSlangView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '📖 Словарь слэнга PoE2';
    showMode('slang');
    renderSlangTab();
    requestSize();
  }

  // ─── Вкладка «⚒ Крафт» (№134): план + каталог рецептов в одном окне ────────
  // UX-паттерн друга: только мышь (чипсы/кнопки), никакого ввода с клавиатуры.
  // Данные — из ядра poe2-kit по IPC (единый источник правды craftGuide.ts):
  // каталог статичен → кэшируем ответ один раз за сессию.
  var CRAFT_SYSTEMS = ${JSON.stringify(CRAFT_SYSTEMS, null, 2)};
  // №262 Этап 2: радар-мини — live-баги и трюки запечены из ядра при сборке
  // (radar.ts known_issues/known_tricks): ноль IPC, ноль сети, офлайн-панель.
  var RADAR_LIVE = ${JSON.stringify(liveIssues(), null, 2)};
  var RADAR_TRICKS = ${JSON.stringify(listKnownTricks(), null, 2)};
  var radarSub = 'bugs'; // bugs | tricks — чипсы внутри вкладки
  function radarChips() {
    return '<div class="tree-chips">' +
      [['bugs', '🐞 Live-баги (' + RADAR_LIVE.length + ')'], ['tricks', '🎯 Трюки (' + RADAR_TRICKS.length + ')']]
        .map(function (s) {
          return '<button class="tree-chip' + (radarSub === s[0] ? ' on' : '') + '" data-rs="' + s[0] + '">' + s[1] + '</button>';
        }).join('') + '</div>';
  }
  function renderRadarTab() {
    var host = $('radarContent');
    if (!host) return;
    var html = radarChips();
    if (radarSub === 'bugs') {
      if (!RADAR_LIVE.length) {
        html += '<div class="lvl-hint">Live-багов в базе нет — база known_issues пуста для этого патча.</div>';
      } else {
        html += RADAR_LIVE.map(function (i) {
          return '<div class="slang-row"><div class="slang-term">' + esc(i.title) +
            (i.severity ? ' <span class="tag-dim">(' + esc(i.severity) + ')</span>' : '') + '</div>' +
            '<div class="slang-def">' + esc(i.mechanism) +
            (i.workaround ? '<br><b>Воркараунд:</b> ' + esc(i.workaround) : '') +
            (i.unverified ? '<br><span class="dim-note">unverified: ' + esc(i.unverified) + '</span>' : '') +
            '</div></div>';
        }).join('');
      }
    } else {
      if (!RADAR_TRICKS.length) {
        html += '<div class="lvl-hint">Трюков в базе нет.</div>';
      } else {
        html += RADAR_TRICKS.map(function (t) {
          return '<div class="slang-row"><div class="slang-term">' + esc(t.title) +
            (t.category ? ' <span class="tag-dim">' + esc(t.category) + '</span>' : '') + '</div>' +
            '<div class="slang-def"><b>Как:</b> ' + esc(t.usage) +
            '<br><b>Механизм:</b> ' + esc(t.mechanism) +
            (t.risk ? '<br><b>Риск:</b> ' + esc(t.risk) : '') +
            (t.unverified ? '<br><span class="dim-note">unverified: ' + esc(t.unverified) + '</span>' : '') +
            '</div></div>';
        }).join('');
      }
    }
    host.innerHTML = html;
    var chips = host.querySelectorAll('[data-rs]');
    for (var ci = 0; ci < chips.length; ci++) {
      chips[ci].addEventListener('click', function () {
        radarSub = this.getAttribute('data-rs');
        renderRadarTab();
      });
    }
  }
  function showRadarView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '🛡 Радар патча';
    showMode('radar');
    renderRadarTab();
    requestSize();
  }
  // ─── Вкладка «🧬 Стартовые» (№479): готовые сборки новичка 0.5.5 ────────────
  // Данные — компактификатор starterGuidesData.ts поверх core.starterBuildGuides,
  // запечены JSON-инжектом при сборке (паттерн №262 RADAR_LIVE): ноль IPC на
  // данные, ноль сети, офлайн-вкладка. Поиск не заводим — UX оверлея mouse-only
  // (№134/№133): фильтр — чипсы классов. PoB-ссылки открываются по IPC
  // starter:openpob (CSP default-src 'none' запрещает навигацию из оверлея).
  var STARTER_GUIDES = ${JSON.stringify(compactStarterBuildGuides(), null, 2)};
  var STARTER_CLASSES = ${JSON.stringify(compactStarterClasses(), null, 2)};
  var STARTER_META = ${JSON.stringify(compactStarterMeta(), null, 2)};
  var STARTER_STAGE_LABEL = { starter: 'Старт', mid: 'Мид', main: 'Мейн', max: 'Макс' };
  var starterFilter = 'all'; // 'all' | class_ru — чипс
  var starterSel = null;     // id выбранного билда | null — список
  function starterChips() {
    var chips = [['all', 'Все (' + STARTER_GUIDES.length + ')']].concat(STARTER_CLASSES.map(function (c) {
      return [c.ru, c.ru + ' (' + c.total + ')'];
    }));
    return '<div class="tree-chips">' + chips.map(function (s) {
      return '<button class="tree-chip' + (starterFilter === s[0] ? ' on' : '') + '" data-sb="' + esc(s[0]) + '">' + esc(s[1]) + '</button>';
    }).join('') + '</div>';
  }
  function starterCard(g) {
    var html = '<button class="tabbtn" id="starterBack" style="margin:4px 0">← Назад ко всем билдам</button>' +
      '<div class="sub-h sub" style="margin-top:2px">' + esc(g.t) + '</div>' +
      '<div class="sub">' + esc(g.cls) + (g.asc ? ' · ' + esc(g.asc) : '') +
      ' · скилл: <b>' + esc(g.main) + '</b>' + (g.mainLvl ? ' (гем ур. ' + g.mainLvl + ')' : '') + '</div>';
    if (g.warn) html += '<div class="err-box">⚠ ' + esc(g.warn) + '</div>';
    if (g.variant) html += '<div class="lvl-hint"><b>Вариант:</b> ' + esc(g.variant) + '</div>';
    html += '<div class="lvl-hint"><b>Механика:</b> ' + esc(g.mech) + '</div>';
    if (g.stages.length) {
      html += '<div class="sub-h sub">Стадии (бюджеты гайдов):</div><table class="bld">';
      for (var si = 0; si < g.stages.length; si++) {
        var st = g.stages[si];
        var cost = st.cost ? '<b>' + esc(st.cost) + '</b>' : '<span class="sub">цена не опубликована</span>';
        if (st.note) cost += ' <span class="sub">(' + esc(st.note) + ')</span>';
        html += '<tr><td class="slot">' + esc(STARTER_STAGE_LABEL[st.k] || st.k) + '</td><td>' + cost +
          (st.delta ? '<br><span class="sub">' + esc(st.delta) + '</span>' : '') + '</td></tr>';
      }
      html += '</table>';
    }
    if (g.uniques.length) {
      html += '<div class="sub-h sub">Ключевые уники:</div><div class="starter-row">';
      for (var ui = 0; ui < g.uniques.length; ui++) {
        var u = g.uniques[ui];
        html += '<span class="starter-btn" title="' + esc(u.note || '') + '">' + esc(u.name) +
          (u.note ? ' ❓' : '') + '</span>';
      }
      html += '</div>';
    }
    if (g.pobs.length) {
      html += '<div class="sub-h sub">PoB:</div><div class="starter-row">';
      for (var pi = 0; pi < g.pobs.length; pi++) {
        html += '<button class="tree-chip" data-sbp="' + esc(g.pobs[pi]) + '">PoB ' + (pi + 1) + '</button>';
      }
      html += '</div>';
    }
    return html;
  }
  function renderStartersTab() {
    var host = $('starterbuildsContent');
    if (!host) return;
    var html = '';
    if (starterSel) {
      var g = null;
      for (var gi = 0; gi < STARTER_GUIDES.length; gi++) {
        if (STARTER_GUIDES[gi].id === starterSel) { g = STARTER_GUIDES[gi]; break; }
      }
      html = g ? starterCard(g) : '<div class="lvl-hint">Билд не найден.</div>';
    } else {
      html = starterChips() +
        '<div class="slang-hint">Выбери класс чипсом выше — покажу готовые сборки: механика, стадии-бюджеты, уники, PoB.</div>';
      var shown = 0;
      for (var bi = 0; bi < STARTER_GUIDES.length; bi++) {
        var b = STARTER_GUIDES[bi];
        if (starterFilter !== 'all' && b.cls !== starterFilter) continue;
        shown++;
        var anyCost = null;
        for (var ci = 0; ci < b.stages.length; ci++) if (b.stages[ci].cost) { anyCost = b.stages[ci].cost; break; }
        html += '<div class="slang-row clickable" data-sbi="' + esc(b.id) + '">' +
          '<div class="slang-term">' + esc(b.t) + (b.warn ? ' <span class="warn-inline">⚠</span>' : '') + '</div>' +
          '<div class="slang-def">' + esc(b.cls) + (b.asc ? ' · ' + esc(b.asc) : '') +
          ' · <b>' + esc(b.main) + '</b>' +
          (anyCost ? ' · от <b>' + esc(anyCost) + '</b>' : '') + '</div></div>';
      }
      if (!shown) html += '<div class="lvl-hint">Билдов этого класса нет.</div>';
      html += '<div class="sub" style="color:#9aa4b0;margin-top:6px">' + esc(STARTER_META.patch || '0.5.5') +
        ' · срез гайдов ' + esc(STARTER_META.asOf || '—') + ' · цены НЕ живые (оффлайн-выжимка core.starterBuildGuides)</div>';
    }
    host.innerHTML = html;
    var chipEls = host.querySelectorAll('[data-sb]');
    for (var c0 = 0; c0 < chipEls.length; c0++) {
      chipEls[c0].addEventListener('click', function () {
        starterFilter = this.getAttribute('data-sb');
        renderStartersTab();
      });
    }
    var rowEls = host.querySelectorAll('[data-sbi]');
    for (var r0 = 0; r0 < rowEls.length; r0++) {
      rowEls[r0].addEventListener('click', function () {
        starterSel = this.getAttribute('data-sbi');
        renderStartersTab();
      });
    }
    var pobEls = host.querySelectorAll('[data-sbp]');
    for (var p0 = 0; p0 < pobEls.length; p0++) {
      pobEls[p0].addEventListener('click', function () {
        var url = this.getAttribute('data-sbp');
        if (url) window.poe2k.openPob(url).catch(function () {});
      });
    }
    var back = host.querySelector('#starterBack');
    if (back) back.addEventListener('click', function () {
      starterSel = null;
      renderStartersTab();
    });
  }
  function showStartersView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '🧬 Стартовые билды 0.5.5 для новичка';
    showMode('starterbuilds');
    renderStartersTab();
    requestSize();
  }
  var craftCatalog = null; // кэш ответа craft:catalog
  var lastCraftPlan = null; // №134: последний успешный план — переживает переключения под-вью
  var craftSub = 'plan';   // plan | recipes | essences | omens
  var craftSysFilter = 'all';
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function craftSubChips() {
    var subs = [['plan', '🎯 План'], ['recipes', '📋 Рецепты'], ['essences', '💧 Эссенции'], ['omens', '🔮 Омены']];
    return '<div class="tree-chips">' + subs.map(function (s) {
      return '<button class="tree-chip' + (craftSub === s[0] ? ' on' : '') +
        '" data-cs="' + s[0] + '">' + s[1] + '</button>';
    }).join('') + '</div>';
  }
  function renderCraftPlan(craftData) {
    // craftData: последний успешный ответ craft:plan (или null)
    if (!craftData) {
      return '<div class="lvl-hint">Наведи на предмет в игре → <b>Ctrl+C</b> → нажми кнопку ниже: ' +
        'кит составит пошаговый план «двух якорей» под этот слот' +
        ' (резисты/ЭС — эссенциями, орбы — с оменами, руны — в сокеты).</div>';
    }
    var rows = (craftData.plan || []).map(function (s, i) {
      return '<div class="slang-row"><div class="slang-term">' + (i + 1) + '. ' + esc(s.step) + '</div>' +
        '<div class="slang-def">' + esc(s.detail) + '</div></div>';
    }).join('');
    var ess = (craftData.essences || []).slice(0, 6).map(function (e) {
      return '<button class="tree-chip" title="' + esc(e.guaranteed) + '">' + esc(e.ru || e.en) + '</button>';
    }).join('');
    return '<div class="slang-hint">Предмет: <b>' + esc(craftData.name) + '</b>' +
      (craftData.ilvl ? ' · ilvl ' + esc(craftData.ilvl) : '') + '</div>' + rows +
      (ess ? '<div class="slang-hint">Эссенции под этот слот (наведи — мод):</div>' +
        '<div class="tree-chips">' + ess + '</div>' : '');
  }
  function renderCraftView(craftData) {
    var host = $('craftContent');
    if (!host) return;
    var html = craftSubChips();
    if (craftSub === 'plan') {
      html += renderCraftPlan(craftData) +
        '<button id="craftPlanBtn" class="tabbtn" style="margin-top:6px">📋 План по предмету (буфер обмена)</button>' +
        '<div class="slang-hint">Порядок: Ctrl+C по предмету в игре → кнопка. План обновится под этот предмет.</div>';
    } else if (craftSub === 'recipes') {
      var cat = craftCatalog;
      if (!cat || !cat.ok) {
        html += '<div class="lvl-hint">Каталог загружается… если не появился — см. overlay.log.</div>';
      } else {
        html += '<div class="tree-chips">' + CRAFT_SYSTEMS.map(function (s) {
          return '<button class="tree-chip' + (craftSysFilter === s[0] ? ' on' : '') +
            '" data-csys="' + s[0] + '">' + s[1] + '</button>';
        }).join('') + '</div>';
        var list = cat.recipes.filter(function (r) {
          return craftSysFilter === 'all' || r.system === craftSysFilter;
        });
        html += list.map(function (r) {
          return '<div class="slang-row"><div class="slang-term">' + esc(r.name) + '</div>' +
            '<div class="slang-def">' + esc(r.recipe) +
            (r.ssfNote ? ' <span style="color:var(--dim)">SSF: ' + esc(r.ssfNote) + '</span>' : '') +
            '</div></div>';
        }).join('');
        html += '<div class="slang-hint">Всего рецептов в базе: ' + cat.recipes.length +
          ' · источник: crafting_knowledge_base.md (0.5.5).</div>';
      }
    } else if (craftSub === 'essences') {
      var cat2 = craftCatalog;
      if (!cat2 || !cat2.ok) {
        html += '<div class="lvl-hint">Каталог загружается…</div>';
      } else {
        html += cat2.essences.map(function (e) {
          return '<div class="slang-row"><div class="slang-term">' + esc(e.ru || e.en) +
            (e.ru ? ' <span style="color:var(--dim)">' + esc(e.en) + '</span>' : '') + '</div>' +
            '<div class="slang-def">' + esc(e.guaranteed) +
            ' · ' + (e.action === 'magicToRare' ? 'Magic → Rare + мод' : 'Rare: заменить мод') +
            (e.perfect ? ' <span style="color:var(--dim)">Perfect: ' + esc(e.perfect) + '</span>' : '') +
            '</div></div>';
        }).join('');
        html += '<div class="lvl-hint">' + esc(cat2.perfectHint) + '</div>';
        if (cat2.specEssences && cat2.specEssences.length) {
          html += '<div class="lvl-group" style="margin:6px 0"><div class="lvl-title" style="color:#c88">Спец-эссенции (Rare: удалить мод + гарантированный)</div>' +
            cat2.specEssences.map(function (e) {
              return '<div class="slang-row"><div class="slang-term">' + esc(e.en) + '</div>' +
                '<div class="slang-def">' + esc(e.perSlot) + '</div></div>';
            }).join('') + '</div>';
        }
        if (cat2.alloys && cat2.alloys.length) {
          html += '<div class="lvl-group" style="margin:6px 0"><div class="lvl-title" style="color:#c88">Alloys (Экспедиция, Runes of Aldur; занимает crafted-слот)</div>' +
            cat2.alloys.map(function (e) {
              return '<div class="slang-row"><div class="slang-term">' + esc(e.en) + '</div>' +
                '<div class="slang-def">' + esc(e.perSlot) + '</div></div>';
            }).join('') + '</div>';
        }
      }
    } else if (craftSub === 'omens') {
      var cat3 = craftCatalog;
      if (!cat3 || !cat3.ok) {
        html += '<div class="lvl-hint">Каталог загружается…</div>';
      } else {
        html += cat3.omens.map(function (o) {
          return '<div class="slang-row"><div class="slang-term">' + esc(o.en) + '</div>' +
            '<div class="slang-def">' + esc(o.purpose) +
            (o.drop ? ' <span style="color:var(--dim)">[' + esc(o.drop) + ']</span>' : '') +
            '</div></div>';
        }).join('');
        html += '<div class="slang-hint">Омены активируются ДО применения валюты и действуют на ОДНУ операцию. ' +
          'Крафтовые (Ritual) стакаются; часть отключена от дропа — помечена ⚠️. Полная таблица: poe2db.tw/us/Omen.</div>';
      }
    }
    host.innerHTML = html;
    // Кнопки под-вью
    var subBtns = host.querySelectorAll('[data-cs]');
    for (var i = 0; i < subBtns.length; i++) {
      subBtns[i].addEventListener('click', function () {
        craftSub = this.getAttribute('data-cs');
        renderCraftView(craftData);
      });
    }
    // Чипсы-фильтр систем рецептов
    var sysBtns = host.querySelectorAll('[data-csys]');
    for (var j = 0; j < sysBtns.length; j++) {
      sysBtns[j].addEventListener('click', function () {
        craftSysFilter = this.getAttribute('data-csys');
        renderCraftView(craftData);
      });
    }
    // План по буферу
    var planBtn = host.querySelector('#craftPlanBtn');
    if (planBtn) planBtn.addEventListener('click', function () {
      planBtn.textContent = '⏳ Читаю буфер…';
      window.poe2k.craftPlanBuffer().then(function (res) {
        if (!res || !res.ok) {
          craftLastError = (res && res.error) || 'Ошибка плана (см. overlay.log)';
          renderCraftView(null);
          return;
        }
        craftLastError = null;
        lastCraftPlan = res;
        renderCraftView(res);
      }).catch(function (err) {
        craftLastError = 'IPC error: ' + err;
        renderCraftView(null);
      });
    });
  }
  var craftLastError = null;
  function showCraftView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '⚒ Крафт: план и рецепты';
    showMode('craft');
    if (craftLastError) {
      var host = $('craftContent');
      if (host) host.innerHTML = craftSubChips() + '<div class="lvl-hint" style="color:#e08080">' + craftLastError + '</div>';
      craftLastError = null; // показали один раз
    } else {
      renderCraftView(lastCraftPlan);
    }
    requestSize();
    // Каталог нужен для вью рецептов/эссенций/оменов — тянем один раз за сессию.
    if (!craftCatalog) {
      window.poe2k.craftCatalog().then(function (res) {
        craftCatalog = res;
        if (craftSub !== 'plan') renderCraftView(null);
      }).catch(function (err) {
        console.warn('[overlay] renderer: craft:catalog failed: ' + err);
      });
    }
  }

  // ─── Вкладка «💱 Курс» (№135): курсы валют по лигам ────────────────────────
  // IPC currency:rates (main): лиги чипсами (✦ — актуальная), таблица
  // валюта → chaos (+divine и тренд ▲/▼, если poe.ninja отдаёт sparkline).
  // Кэш main 10 мин; в renderer держим последний ответ для мгновенного рендера.
  var ratesData = null;   // последний ответ currency:rates
  var ratesLeague = null; // выбранная лига (чипс)
  function fmtChaos(v) {
    if (v == null) return '—';
    if (v >= 100) return v.toFixed(0);
    if (v >= 1) return v.toFixed(2);
    if (v >= 0.01) return v.toFixed(2);
    return '<0.01';
  }
  function renderRatesView() {
    var host = $('ratesContent');
    if (!host) return;
    if (!ratesData || !ratesData.ok) {
      host.innerHTML = '<div class="lvl-hint">' +
        (ratesData && ratesData.error ? ratesData.error : 'Загружаю курсы валют…') + '</div>';
      return;
    }
    var leagues = ratesData.leagues || [];
    var chips = '<div class="tree-chips">' + leagues.map(function (l) {
      return '<button class="tree-chip' + (ratesLeague === l.name ? ' on' : '') +
        '" data-league="' + esc(l.name) + '">' + (l.isCurrent ? '✦ ' : '') + esc(l.name) + '</button>';
    }).join('') + '</div>';
    var rows = (ratesData.rates || []).map(function (r) {
      var tr = r.trend == null ? '' :
        ' <span class="' + (r.trend > 0 ? 'trend-up' : 'trend-down') + '">' +
        (r.trend > 0 ? '▲+' : r.trend < 0 ? '▼' : '') + r.trend.toFixed(1) + '%</span>';
      var dv = r.divine != null ? ' <span style="color:var(--dim)">' + curIcon('div', 14) + r.divine.toFixed(1) + ' div</span>' : '';
      // №138-ter: RU-имя (из словаря poe2db) + EN рядом приглушённо; нет RU — только EN.
      var nm = r.ru && r.ru.toLowerCase() !== String(r.name).toLowerCase()
        ? esc(r.ru) + ' <span style="color:#9aa4b0">' + esc(r.name) + '</span>'
        : esc(r.name);
      return '<div class="slang-row"><div class="slang-term">' + nm + '</div>' +
        '<div class="slang-def">' + curIcon('chaos', 14) + fmtChaos(r.chaos) + ' chaos' + dv + tr + '</div></div>';
    }).join('');
    host.innerHTML = chips +
      '<div class="slang-hint">Лига: <b>' + esc(ratesData.league) + '</b> · ' +
      (ratesData.cached ? 'кэш' : 'свежие данные') + ' · источник: poe2scout + poe.ninja</div>' +
      (rows || '<div class="lvl-hint">Для этой лиги нет данных о валютах.</div>');
    var btns = host.querySelectorAll('[data-league]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener('click', function () {
        ratesLeague = this.getAttribute('data-league');
        loadRates();
      });
    }
  }
  function loadRates() {
    var host = $('ratesContent');
    if (host) host.innerHTML = '<div class="lvl-hint">Загружаю курсы (' + (ratesLeague || 'актуальная лига') + ')…</div>';
    window.poe2k.currencyRates(ratesLeague || undefined).then(function (res) {
      ratesData = res;
      if (res && res.ok && !ratesLeague) ratesLeague = res.league;
      renderRatesView();
    }).catch(function (err) {
      ratesData = { ok: false, error: 'IPC error: ' + err };
      renderRatesView();
    });
  }
  function showRatesView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '💱 Курсы валют по лигам';
    showMode('rates');
    // Первый вход: грузим; повторный (другая вкладка → назад) — рисуем кэш.
    if (ratesData) renderRatesView();
    else loadRates();
    requestSize();
  }

  // ─── Вкладка «🧬 Билды» (№136): генератор по ладдеру poe.ninja ────────────
  // IPC buildgen:meta (main): один запрос ладдера → группировка по классам:
  // частые скиллы/ключевые узлы, медианные DPS/EHP, топ-3 примера. Ни один
  // «совет» не выдуман — всё из живых билдов топ-игроков.
  var genData = null;   // последний ответ buildgen:meta
  var genLeague = null; // выбранный slug лиги
  var genClass = null;  // выбранный класс (чипс)
  function renderGenView() {
    var host = $('genContent');
    if (!host) return;
    // №139: два режима — мета ладдера и конструктор связок.
    if (genMode === 'combo') { renderComboView(); return; }
    if (!genData || !genData.ok) {
      host.innerHTML = '<div class="lvl-hint">' +
        (genData && genData.error ? genData.error : 'Загружаю мета билдов…') + '</div>';
      return;
    }
    var lc = (genData.slugs || []).map(function (s) {
      return '<button class="tree-chip' + (genLeague === s ? ' on' : '') +
        '" data-genslug="' + esc(s) + '">' + esc(s) + '</button>';
    }).join('');
    var cc = (genData.classes || []).map(function (c) {
      return '<button class="tree-chip' + (genClass === c.label ? ' on' : '') +
        '" data-genclass="' + esc(c.label) + '">' + esc(c.label) + ' <span style="color:var(--dim)">' + c.count + '</span></button>';
    }).join('');
    var cls = genData.classes.find(function (c) { return c.label === genClass; });
    var body = '';
    if (cls) {
      body += '<div class="slang-hint"><b>' + esc(cls.label) + '</b> · ' + cls.count + ' билдов · медианные <b>DPS ' +
        (cls.medianDps || '—') + '</b> / <b>EHP ' + (cls.medianEhp || '—') + '</b></div>';
      body += '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#c88">Скиллы (частые)</div>' +
        cls.topSkills.map(function (s) {
          return '<div class="slang-row"><div class="slang-term">' + esc(s.name) + '</div><div class="slang-def">×' + s.count + '</div></div>';
        }).join('') + '</div>';
      if (cls.topPassives && cls.topPassives.length) {
        body += '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#c88">Ключевые узлы (частые)</div>' +
          cls.topPassives.map(function (p) {
            return '<div class="slang-row"><div class="slang-term">' + esc(p.name) + '</div><div class="slang-def">×' + p.count + '</div></div>';
          }).join('') + '</div>';
      }
      body += '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#c88">Примеры (топ по уровню)</div>' +
        cls.top.map(function (t) {
          return '<div class="slang-row"><div class="slang-term">ур.' + t.level + ' · ' + esc(String(t.name)) + '</div>' +
            '<div class="slang-def">DPS ' + t.dps + ' · EHP ' + t.ehp + '<br><span style="color:var(--dim)">' +
            (t.skills || []).map(esc).join(', ') + '</span></div></div>';
        }).join('') + '</div>';
    } else {
      body = '<div class="lvl-hint">Выбери класс чипсом выше — покажу, что играют топы: скиллы, узлы, DPS/EHP.</div>';
    }
    host.innerHTML =
      genModeChips() +
      '<div class="tree-chips">' + lc + '</div>' +
      '<div class="slang-hint">Выборка: ' + genData.sample + ' билдов · ' + (genData.cached ? 'кэш' : 'свежие данные') + ' · poe.ninja</div>' +
      '<div class="tree-chips">' + cc + '</div>' + body;
    var s1 = host.querySelectorAll('[data-genslug]');
    for (var i = 0; i < s1.length; i++) {
      s1[i].addEventListener('click', function () {
        genLeague = this.getAttribute('data-genslug');
        genClass = null; // классы меняются вместе с лигой
        loadGen();
      });
    }
    var s2 = host.querySelectorAll('[data-genclass]');
    for (var j = 0; j < s2.length; j++) {
      s2[j].addEventListener('click', function () {
        genClass = this.getAttribute('data-genclass');
        renderGenView();
      });
    }
    bindGenMode(host);
  }
  // ─── №139: «🔗 Конструктор связок» — актив + саппорты, фильтр по типам ─────
  // Данные: офлайн-датасет (skillTypes у активов, compatible_with у саппортов),
  // RU-имена гемов — верифицированный gemsRuEn. Совпадения — чистая арифметика
  // по датасету, ничего не выдумано. Саппорты совместимы по attack/spell.
  var genMode = 'meta';          // 'meta' | 'combo'
  var comboData = null;          // ответ buildgen:gemdata (офлайн, на сессию)
  var comboTags = [];            // выбранные EN-теги (AND-фильтр)
  var comboStyle = null;         // №192: выбранный вид атаки (один; null = все)
  var comboSel = [];             // EN-имена выбранных активных (макс 5)
  var comboSups = {};            // EN(актив) -> [EN(саппорт), …]
  var COMBO_TAGS = [
    ['Молния', 'Lightning'], ['Приспешники', 'Minion'], ['По площади', 'Area'],
    ['Снаряды', 'Projectile'], ['Чары', 'Spell'], ['Атака', 'Attack'],
    ['Холод', 'Cold'], ['Огонь', 'Fire'], ['Хаос', 'Chaos'],
    ['Физический', 'Physical'], ['Длительность', 'Duration'],
  ];
  // №192: «зоопарк атак» — виды из style, назначенном в main (приоритет
  // специфичное→общее: лук/арбалет/копьё раньше снарядов, melee последним).
  var STYLE_LABELS = [
    ['Melee', 'Ближний бой'], ['Projectile', 'Снаряды'], ['Bow', 'Лук'],
    ['Crossbow', 'Арбалет'], ['Spear', 'Копьё'], ['Slam', 'Слэм'],
    ['Nova', 'Нова'], ['Totem', 'Тотем'], ['Minion', 'Приспешники'],
    ['Movement', 'Движение'], ['Spell', 'Чары'],
  ];
  var STYLE_EMOJI = {
    Melee: '⚔', Projectile: '🏹', Bow: '🏹', Crossbow: '🔫', Spear: '🔱',
    Slam: '🔨', Nova: '💥', Totem: '🗿', Minion: '👹', Movement: '💨', Spell: '✨',
  };
  function comboName(x) {
    var ru = x.ru ? esc(x.ru) : esc(x.en);
    return x.ru && x.ru.toLowerCase() !== String(x.en).toLowerCase()
      ? ru + ' <span style="color:#9aa4b0">' + esc(x.en) + '</span>'
      : ru;
  }
  // №194: точки цветов гема (№56, hex как в gem-check): синий=Инт / красный=Сила / зелёный=Ловк.
  var GEM_HEX = { blue: '#7f8cff', red: '#e0574f', green: '#57d980' };
  function gemDots(colors) {
    if (!colors || !colors.length) return '';
    var out = '';
    for (var i = 0; i < colors.length; i++) {
      out += '<span style="color:' + (GEM_HEX[colors[i]] || '#9aa4b0') + '">●</span>';
    }
    return out + ' ';
  }
  // №196 (S9-UI): kind-строки — человекочитаемая причина вместо сырого текста
  // ошибки (kinds = core.result: network/notfound/ratelimit/parse/timeout).
  var KIND_TEXT = {
    network: 'нет соединения с источником (проверьте сеть, повтор позже)',
    ratelimit: 'источник ограничил запросы — подождите около минуты',
    timeout: 'источник не ответил (таймаут)',
    parse: 'источник вернул некорректный ответ (проблема на его стороне)',
    notfound: 'не найдено в источниках',
  };
  function priceErrText(res) {
    var k = res && res.errorKind ? String(res.errorKind) : '';
    var t = KIND_TEXT[k];
    if (t) {
      var src = res && res.parseError ? String(res.parseError).slice(0, 140) : '';
      return t + (src ? ' [' + src + ']' : '');
    }
    return String(res && res.parseError ? res.parseError : '');
  }
  function bindGenMode(host) {
    var m = host.querySelectorAll('[data-genmode]');
    for (var i = 0; i < m.length; i++) {
      m[i].addEventListener('click', function () {
        genMode = this.getAttribute('data-genmode');
        renderGenView();
      });
    }
  }
  function genModeChips() {
    return '<div class="tree-chips">' +
      '<button class="tree-chip' + (genMode === 'meta' ? ' on' : '') + '" data-genmode="meta">🏆 Мета ладдера</button>' +
      '<button class="tree-chip' + (genMode === 'combo' ? ' on' : '') + '" data-genmode="combo">🔗 Конструктор связок</button>' +
      '</div>';
  }
  function loadCombo() {
    var host = $('genContent');
    if (host) host.innerHTML = '<div class="lvl-hint">Загружаю датасет гемов…</div>';
    // №141: датасет ~2000 гемов одним IPC-пакетом лагал рендерер —
    // тянем ЧАНКАМИ по 400, между запросами рендерер свободен.
    comboData = null;
    var acts = [], sups = [], nA = 0, nS = 0, got = 0, total = 0;
    function pull(offset) {
      return window.poe2k.buildgenGemData({ offset: offset, limit: 400 }).then(function (res) {
        if (!res || !res.ok) throw new Error(res && res.error ? res.error : 'датасет недоступен');
        nA = res.nActive || nA; nS = res.nSupport || nS; total = res.total || total;
        var items = res.items || [];
        for (var i = 0; i < items.length; i++) {
          if (items[i].kind === 'support') sups.push(items[i]); else acts.push(items[i]);
        }
        got += items.length;
        if (host && !comboData) host.innerHTML = '<div class="lvl-hint">Загружаю датасет гемов… ' + got + (total ? '/' + total : '') + '</div>';
        if (res.done || (total && got >= total)) {
          comboData = { ok: true, actives: acts, supports: sups, nActive: nA, nSupport: nS };
          renderGenView();
          // №193: если открыт советчик саппортов — он ждёт этот же датасет.
          var sw = $('suppadvWrap');
          if (sw && !sw.classList.contains('hide')) renderSuppadvView();
        } else {
          return pull(offset + items.length);
        }
      });
    }
    pull(0).catch(function (err) {
      comboData = { ok: false, error: 'IPC error: ' + err };
      renderGenView();
    });
  }
  function renderComboView() {
    var host = $('genContent');
    if (!host) return;
    if (!comboData) { loadCombo(); return; }
    if (!comboData.ok) {
      host.innerHTML = genModeChips() + '<div class="lvl-hint">' +
        (comboData.error ? comboData.error : 'Датасет гемов недоступен.') + '</div>';
      bindGenMode(host);
      return;
    }
    var A = comboData.actives || [];
    var S = comboData.supports || [];
    // №192: ряд «Вид» — один стиль за раз (клик по другому = замена, повтор = снять).
    var styleCounts = {};
    for (var ai = 0; ai < A.length; ai++) {
      var st = A[ai].style;
      if (st) styleCounts[st] = (styleCounts[st] || 0) + 1;
    }
    var styleChips = STYLE_LABELS.filter(function (x) { return styleCounts[x[0]]; }).map(function (x) {
      return '<button class="tree-chip' + (comboStyle === x[0] ? ' on' : '') +
        '" data-cmbstyle="' + x[0] + '">' + (STYLE_EMOJI[x[0]] || '') + ' ' + x[1] +
        ' <span style="color:var(--dim)">' + styleCounts[x[0]] + '</span></button>';
    }).join('');
    var tc = COMBO_TAGS.map(function (t) {
      return '<button class="tree-chip' + (comboTags.indexOf(t[1]) >= 0 ? ' on' : '') +
        '" data-cmbtag="' + t[1] + '">' + t[0] + '</button>';
    }).join('');
    var filtered = A.filter(function (a) {
      if (comboStyle && a.style !== comboStyle) return false;
      return comboTags.every(function (t) { return (a.types || []).indexOf(t) >= 0; });
    }).sort(function (a, b) { return (a.unlock || 0) - (b.unlock || 0); });
    // №192: подсказка зоопарка в списке — у активов, чей вид уже в связке.
    function dupStyleMark(a) {
      if (!a.style) return '';
      var inCombo = comboSel.some(function (en2) {
        var o = A.find(function (x) { return x.en === en2; });
        return o && o !== a && o.style === a.style;
      });
      if (!inCombo) return '';
      var lb = '';
      for (var si2 = 0; si2 < STYLE_LABELS.length; si2++) if (STYLE_LABELS[si2][0] === a.style) lb = STYLE_LABELS[si2][1];
      return ' <span style="color:#e0b060">⚠ вид «' + lb + '» уже в связке</span>';
    }
    var MAX_SHOW = 60;
    var shown = filtered.slice(0, MAX_SHOW);
    var actRows = shown.map(function (a) {
      var ix = comboSel.indexOf(a.en);
      return '<div class="slang-row" data-cmben="' + esc(a.en) + '"><div class="slang-term">' +
        (ix >= 0 ? '<span style="color:#7fc97f">№' + (ix + 1) + '</span> ' : '') + comboName(a) +
        '</div><div class="slang-def">ур.' + (a.unlock || 0) + dupStyleMark(a) +
        (ix >= 0 ? ' · <span style="color:var(--dim)">тап — убрать из связки</span>' : '') +
        '</div></div>';
    }).join('');
    var actList = '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#c88">' +
      'Активные навыки (клик — в связку)</div>' +
      (filtered.length > MAX_SHOW
        ? '<div class="lvl-hint">Показаны первые ' + MAX_SHOW + ' из ' + filtered.length + ' — уточни фильтром выше.</div>'
        : '') +
      '<div data-cmblist>' + (actRows || '<div class="lvl-hint">Ничего не найдено — сними часть фильтров.</div>') + '</div></div>';
    // Блоки выбранных активов + их саппорты.
    // №192: приоритет — рекомендации (reco: эталон меты / poe2db-ранги);
    // только при их отсутствии — compat-fallback по attack/spell (как раньше).
    var supBlocks = comboSel.map(function (en) {
      var a = A.find(function (x) { return x.en === en; });
      if (!a) return '';
      var picked = comboSups[en] || [];
      var supChips = '';
      var supNote = '';
      var recoLabel = '';
      if ((a.reco || []).length) {
        var MAX_RC = 20;
        recoLabel = (a.reco[0] && a.reco[0].note) ? a.reco[0].note : 'базово: poe2db Recommended Support Gems (ранг = приоритет)';
        var rshown = a.reco.slice(0, MAX_RC);
        supChips = rshown.map(function (r) {
          var sp = S.find(function (x) { return x.en === r.en; });
          var nm = sp ? gemDots(sp.colors) + comboName(sp) : esc(r.en);
          var on = picked.indexOf(r.en) >= 0;
          var badge = r.tier === 'meta'
            ? '<span style="color:#e8c667">★</span> '
            : (r.rank ? '<span style="color:var(--dim)">' + r.rank + '</span> ' : '');
          return '<button class="tree-chip' + (on ? ' on' : '') +
            '" data-cmbsup="' + esc(en) + '||' + esc(r.en) + '">' +
            (on ? '✔ ' : '') + badge + nm + '</button>';
        }).join('');
        if (a.reco.length > MAX_RC) supNote = '<div class="lvl-hint">Показаны ' + MAX_RC + ' из ' + a.reco.length + ' рекомендованных.</div>';
      } else {
        var lo = (a.types || []).map(function (t) { return String(t).toLowerCase(); });
        var comp = S.filter(function (sp) {
          return (sp.compat || []).some(function (c) { return lo.indexOf(String(c)) >= 0; });
        });
        if (!comp.length) comp = S; // редкий случай: unknown compat — показываем все
        var MAX_SP = 24;
        supChips = comp.slice(0, MAX_SP).map(function (sp) {
          var on = picked.indexOf(sp.en) >= 0;
          return '<button class="tree-chip' + (on ? ' on' : '') +
            '" data-cmbsup="' + esc(en) + '||' + esc(sp.en) + '">' +
            (on ? '✔ ' : '') + gemDots(sp.colors) + comboName(sp) + '</button>';
        }).join('');
        supNote = comp.length > MAX_SP ? '<div class="lvl-hint">Показаны ' + MAX_SP + ' из ' + comp.length + ' (без рекомендаций — уточнение только attack/spell).</div>' : '';
      }
      var pickedList = picked.length
        ? '<div class="lvl-hint" style="margin-top:3px"> В связке: <b>' +
          picked.map(function (p) { return esc(p); }).join('</b>, <b>') + '</b></div>'
        : '';
      return '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#7fc97f">' +
        gemDots(a.colors) + comboName(a) + ' · ур.' + (a.unlock || 0) + ' · ' + (a.types || []).slice(0, 6).join(', ') +
        (recoLabel ? '<div class="lvl-hint" style="color:#e8c667">' + recoLabel + '</div>' : '') +
        '</div><div class="tree-chips">' + supChips + '</div>' + supNote + pickedList + '</div>';
    }).join('');
    // №142: шаговые слоты — связка собирается ПО ПОРЯДКУ: 5 пронумерованных
    // строк, следующий пустой слот подсвечен «← в списке ниже». Друг живет
    // мышью: порядок «первый → второй → третий» обязан быть виден сразу.
    var MAX_SLOTS = 5;
    var rows = '';
    for (var si = 0; si < Math.max(MAX_SLOTS, comboSel.length); si++) {
      var en = comboSel[si];
      if (en !== undefined) {
        var a = A.find(function (x) { return x.en === en; });
        var ps = (comboSups[en] || []);
        var stl = '';
        if (a && a.style) {
          for (var sl = 0; sl < STYLE_LABELS.length; sl++) {
            if (STYLE_LABELS[sl][0] === a.style) stl = ' <span style="color:var(--dim)">· ' + STYLE_LABELS[sl][1] + '</span>';
          }
        }
        rows += '<div class="slang-row"><div class="slang-term"><span style="color:#7fc97f">' + (si + 1) + '.</span> ' +
          (a && a.style ? (STYLE_EMOJI[a.style] || '') + ' ' : '') + (a ? gemDots(a.colors) : '') + comboName(a) +
          '</div><div class="slang-def">Uncut Skill Gem ур.' + (a ? (a.unlock || 0) : 0) + stl +
          (ps.length ? ' <span style="color:var(--dim)">+ ' + ps.length + ' сапп.</span>' : '') +
          '</div></div>';
      } else {
        var isNext = (si === comboSel.length);
        rows += '<div class="slang-row" style="' + (isNext ? 'border:1px dashed #7fc97f' : '') + '">' +
          '<div class="slang-term" style="color:var(--dim)">' + (si + 1) + '. —</div>' +
          '<div class="slang-def">' + (isNext
            ? '<span style="color:#7fc97f">← тапни навык в списке ниже</span>'
            : 'пусто') + '</div></div>';
      }
    }
    var slotsUi = '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#7fc97f">' +
      'Связка по порядку (до ' + MAX_SLOTS + ')' +
      (comboSel.length ? ' <button class="tree-chip" data-cmbclear="1" style="margin-left:6px">🗑 Сброс</button>' : '') +
      '</div>' + rows +
      '<div class="lvl-hint">Тап по навыку в списке = следующий номер; тап по выбранному (№) — убрать. Саппорты к каждому — ниже, под списком.</div></div>';
    // №141-bis: кнопка кода ВСЕГДА видима (друг живёт мышью; пустая связка →
    // внятная ошибка от IPC, а не исчезнувшая кнопка).
    var comboCodeUi = '<div class="tree-chips" style="margin:6px 0">' +
      '<button class="tree-chip" data-cmbcode="1">📋 Код импорта (в буфер)</button></div>' +
      '<div class="lvl-hint" data-cmbcodemsg style="min-height:14px"></div>';
    host.innerHTML = genModeChips() +
      '<div class="lvl-hint">Связка — по порядку: тапни первый навык, потом второй и так далее (до 5). Вид атаки — один чипс за раз.</div>' +
      (styleChips ? '<div class="lvl-group" style="margin:2px 0"><div class="lvl-title">Вид (зоопарк атак)</div><div class="tree-chips">' + styleChips + '</div></div>' : '') +
      (tc ? '<div class="tree-chips">' + tc + '</div>' : '') +
      slotsUi + actList + supBlocks + comboCodeUi;
    bindGenMode(host);
    var clr = host.querySelector('[data-cmbclear]');
    if (clr) clr.addEventListener('click', function () {
      comboSel = [];
      comboSups = {};
      renderComboView();
    });
    var cc = host.querySelector('[data-cmbcode]');
    if (cc) cc.addEventListener('click', function () {
      var msgEl = host.querySelector('[data-cmbcodemsg]');
      if (msgEl) msgEl.textContent = 'Собираю код…';
      var payload = {
        actives: comboSel.map(function (en) {
          var a = A.find(function (x) { return x.en === en; });
          return { en: en, unlock: a ? (a.unlock || 0) : 0 };
        }),
        supports: comboSups,
      };
      // №141: main собирает PoB-XML (nameSpec-формат) → encodeShareCode → буфер.
      window.poe2k.buildgenComboCode(payload).then(function (res) {
        if (!msgEl) return;
        if (res && res.ok) {
          msgEl.textContent = '✅ Код (' + res.chars + ' симв.) в буфере — Ctrl+F3 вставит билд сюда; Paste в PoB2 тоже должен принять.';
        } else {
          msgEl.style.color = '#e07070';
          msgEl.textContent = res && res.error ? res.error : 'Не удалось собрать код.';
        }
      });
    });
    var tt = host.querySelectorAll('[data-cmbtag]');
    for (var i = 0; i < tt.length; i++) {
      tt[i].addEventListener('click', function () {
        var t = this.getAttribute('data-cmbtag');
        var ix = comboTags.indexOf(t);
        if (ix >= 0) comboTags.splice(ix, 1); else comboTags.push(t);
        renderComboView();
      });
    }
    // №192: чипс вида — одиночный выбор (замена/снятие), не AND-стек.
    var sc = host.querySelectorAll('[data-cmbstyle]');
    for (var i2 = 0; i2 < sc.length; i2++) {
      sc[i2].addEventListener('click', function () {
        var s2 = this.getAttribute('data-cmbstyle');
        comboStyle = (comboStyle === s2) ? null : s2;
        renderComboView();
      });
    }
    var ll = host.querySelectorAll('[data-cmblist] .slang-row');
    for (var k = 0; k < ll.length; k++) {
      ll[k].addEventListener('click', function () {
        var en = this.getAttribute('data-cmben');
        if (!en) return;
        var ix = comboSel.indexOf(en);
        if (ix >= 0) { comboSel.splice(ix, 1); delete comboSups[en]; }
        else if (comboSel.length < 5) comboSel.push(en);
        renderComboView();
      });
    }
    var ss = host.querySelectorAll('[data-cmbsup]');
    for (var q = 0; q < ss.length; q++) {
      ss[q].addEventListener('click', function () {
        var kv = this.getAttribute('data-cmbsup').split('||');
        if (!comboSups[kv[0]]) comboSups[kv[0]] = [];
        var arr = comboSups[kv[0]];
        var ix = arr.indexOf(kv[1]);
        if (ix >= 0) arr.splice(ix, 1);
        else if (arr.length < 5) arr.push(kv[1]);
        renderComboView();
      });
    }
  }
  // ─── Вкладка «🧩 Саппорты» (№193): советчик камней поддержки ────────────────
  // Репорт друга: «советчик по камням умений перестал работать» — саппорты
  // жили ТОЛЬКО в конструкторе связок и в прайс-вью гема (Ctrl+F1). Здесь —
  // отдельная вкладка, не конфликтующая с конструктором: под выбранный
  // активный навык — ПРИОРИТЕТНЫЙ список саппортов. Движок тот же (№40/№192):
  // reco (★ эталон меты → poe2db-ранги) → при их отсутствии compat-fallback.
  // Данные — comboData (buildgen:gemdata, офлайн, чанками по 400).
  var suppadvQuery = '';
  var suppadvStyle = null; // вид атаки (один; null = все)
  var suppadvSel = null;   // EN активного навыка, для которого показываем саппорты
  function suppadvBuildNames() {
    // Ключи камней текущего билда (RU-имена из build:update) — метка «✅ в билде».
    var out = {};
    var b = lastBuildState;
    if (b && b.gemSetups) {
      for (var i = 0; i < b.gemSetups.length; i++) {
        var g = b.gemSetups[i];
        if (g.active) out[gemKeySh(g.active)] = 1;
        var sp = g.supports || [];
        for (var j = 0; j < sp.length; j++) out[gemKeySh(sp[j])] = 1;
      }
    }
    return out;
  }
  function renderSuppadvView() {
    var host = $('suppadvContent');
    if (!host) return;
    if (!comboData) {
      host.innerHTML = '<div class="lvl-hint">Загружаю датасет гемов…</div>';
      return;
    }
    if (!comboData.ok) {
      host.innerHTML = '<div class="lvl-hint">' +
        (comboData.error ? comboData.error : 'Датасет гемов недоступен.') + '</div>';
      return;
    }
    var A = comboData.actives || [];
    var S = comboData.supports || [];
    var q = suppadvQuery.trim().toLowerCase();
    var styleCounts = {};
    for (var ai = 0; ai < A.length; ai++) {
      var st = A[ai].style;
      if (st) styleCounts[st] = (styleCounts[st] || 0) + 1;
    }
    var sysChips = STYLE_LABELS.filter(function (x) { return styleCounts[x[0]]; }).map(function (x) {
      return '<button class="tree-chip' + (suppadvStyle === x[0] ? ' on' : '') +
        '" data-sastyle="' + x[0] + '">' + (STYLE_EMOJI[x[0]] || '') + ' ' + x[1] +
        ' <span style="color:var(--dim)">' + styleCounts[x[0]] + '</span></button>';
    }).join('');
    var html = '<div class="sub-h sub">🧩 Советчик саппортов: приоритет для активного навыка</div>' +
      '<input id="suppadvQ" placeholder="Найти навык: имя RU/EN или ур. (например: ice, ладонь, 12)"' +
      ' style="width:100%;box-sizing:border-box;margin:4px 0 3px;padding:3px 6px;border:1px solid #2a3344;border-radius:4px;background:rgba(0,0,0,0.35);color:var(--fg);font-size:11px" value="' + esc(suppadvQuery) + '"/>' +
      '<div class="tree-chips">' + sysChips + '</div>';
    var sel = suppadvSel ? A.find(function (x) { return x.en === suppadvSel; }) : null;
    if (sel) {
      var stl = '';
      var emo = sel.style ? (STYLE_EMOJI[sel.style] || '') : '';
      for (var sl2 = 0; sl2 < STYLE_LABELS.length; sl2++) {
        if (sel.style && STYLE_LABELS[sl2][0] === sel.style) stl = ' · ' + STYLE_LABELS[sl2][1];
      }
      html += '<div class="lvl-group" style="margin:4px 0"><div class="lvl-title" style="color:#e8c667">' +
        (emo ? emo + ' ' : '') + gemDots(sel.colors) + comboName(sel) + ' · ур.' + (sel.unlock || 0) + esc(stl) +
        ' <span style="color:var(--dim);cursor:pointer" data-saoff>✕</span></div>' +
        '<div class="lvl-hint">' + (sel.types || []).slice(0, 8).join(', ') + '</div></div>';
      var inBuild = suppadvBuildNames();
      var supRows = '';
      // №194: ранги — цветные бейджи (1-3 призовые, далее приглушённые),
      // мета-эталон — золотая полоса; точки ● = атрибуты гема.
      var RANK_BG = { '1': 'background:rgba(232,198,103,0.18);color:#e8c667', '2': 'background:rgba(176,190,210,0.16);color:#c8d2e0', '3': 'background:rgba(205,127,50,0.18);color:#e0a068' };
      function rankBadge(r, ix2) {
        if (r.tier === 'meta') return '<span style="color:#e8c667;font-size:13px">★</span>';
        var rn = r.rank != null ? String(r.rank) : String(ix2 + 1);
        return '<span style="' + (RANK_BG[rn] || 'background:rgba(255,255,255,0.06);color:#9aa4b0') +
          ';border-radius:8px;padding:0 6px;font-size:10px" title="' +
          (r.rank ? 'ранг poe2db ' + r.rank : 'приоритет №' + (ix2 + 1)) + '">' + rn + '</span>';
      }
      if ((sel.reco || []).length) {
        var rl = (sel.reco[0] && sel.reco[0].note) ? sel.reco[0].note
          : 'базово: poe2db Recommended Support Gems (ранг = приоритет)';
        var hasMeta = sel.reco.some(function (r2) { return r2.tier === 'meta'; });
        html += '<div class="lvl-hint" style="color:#e8c667">' + (hasMeta ? '★ ' : '') + rl + '</div>';
        supRows = sel.reco.map(function (r, ix2) {
          var sp2 = S.find(function (x) { return x.en === r.en; });
          var nm = sp2 ? gemDots(sp2.colors) + comboName(sp2) : esc(r.en);
          var key = sp2 && sp2.ru ? gemKeySh(sp2.ru) : gemKeySh(r.en);
          var have = inBuild[key] ? ' <span style="color:#7fc97f">✅ в билде</span>' : '';
          var metaRow = r.tier === 'meta'
            ? 'background:rgba(232,198,103,0.08);border-left:3px solid #e8c667;' : '';
          return '<div class="slang-row" style="' + metaRow + 'padding:3px 6px"><div class="slang-term">' +
            rankBadge(r, ix2) + ' ' + nm + have + '</div></div>';
        }).join('');
      } else {
        var lo = (sel.types || []).map(function (t) { return String(t).toLowerCase(); });
        var comp = S.filter(function (sp3) {
          return (sp3.compat || []).some(function (c2) { return lo.indexOf(String(c2)) >= 0; });
        });
        if (!comp.length) comp = S;
        supRows = comp.slice(0, 24).map(function (sp4) {
          var key2 = sp4.ru ? gemKeySh(sp4.ru) : gemKeySh(sp4.en);
          var have2 = inBuild[key2] ? ' <span style="color:#7fc97f">✅ в билде</span>' : '';
          return '<div class="slang-row" style="padding:3px 6px"><div class="slang-term">· ' +
            gemDots(sp4.colors) + comboName(sp4) + have2 + '</div></div>';
        }).join('');
        html += '<div class="lvl-hint">Без рекомендаций (датасеты 0.5.5 знают только attack/spell) — список без приоритета.</div>';
      }
      html += '<div class="lvl-title" style="color:#c88;margin-top:2px">Саппорты по приоритету</div>' +
        (supRows || '<div class="lvl-hint">Не найдено.</div>');
    } else {
      var filtered = A.filter(function (a) {
        if (suppadvStyle && a.style !== suppadvStyle) return false;
        if (!q) return true;
        return ((a.ru || '').toLowerCase().indexOf(q) >= 0) ||
          ((a.en || '').toLowerCase().indexOf(q) >= 0) ||
          (String(a.unlock || 0) === q);
      }).sort(function (a, b) { return (a.unlock || 0) - (b.unlock || 0); });
      var MAX_SA = 30;
      var rows = filtered.slice(0, MAX_SA).map(function (a) {
        var stl3 = '';
        for (var sl3 = 0; sl3 < STYLE_LABELS.length; sl3++) {
          if (a.style && STYLE_LABELS[sl3][0] === a.style) stl3 = ' · ' + STYLE_LABELS[sl3][1];
        }
        return '<div class="slang-row" data-saen="' + esc(a.en) + '" style="cursor:pointer"><div class="slang-term">' +
          (a.style ? (STYLE_EMOJI[a.style] || '') + ' ' : '') + gemDots(a.colors) + comboName(a) +
          '</div><div class="slang-def">ур.' + (a.unlock || 0) + esc(stl3) +
          ' · <span style="color:var(--dim)">саппорты →</span></div></div>';
      }).join('');
      html += '<div class="lvl-hint">' + (q || suppadvStyle
        ? 'Найдено: ' + filtered.length + (filtered.length > MAX_SA ? ' (первые ' + MAX_SA + ')' : '')
        : 'Все активные: ' + A.length + ' — уточни поиском/чипсом вида. Тап по навыку — приоритет саппортов.') + '</div>' +
        '<div data-salist>' + (rows || '<div class="lvl-hint">Ничего не найдено.</div>') + '</div>';
    }
    host.innerHTML = html;
    bindSuppadvView(host);
  }
  function bindSuppadvView(host) {
    var inp = host.querySelector('#suppadvQ');
    if (inp) inp.addEventListener('input', function () {
      suppadvQuery = this.value;
      renderSuppadvView();
      // Поле пересобирается — возвращаем фокус и каретку в конец.
      var n = $('suppadvQ');
      if (n) { n.focus(); try { n.setSelectionRange(n.value.length, n.value.length); } catch (e2) {} }
    });
    var chips = host.querySelectorAll('[data-sastyle]');
    for (var i = 0; i < chips.length; i++) {
      chips[i].addEventListener('click', function () {
        var s2 = this.getAttribute('data-sastyle');
        suppadvStyle = (suppadvStyle === s2) ? null : s2;
        renderSuppadvView();
      });
    }
    var off = host.querySelector('[data-saoff]');
    if (off) off.addEventListener('click', function () { suppadvSel = null; renderSuppadvView(); });
    var rows = host.querySelectorAll('[data-saen]');
    for (var k = 0; k < rows.length; k++) {
      rows[k].addEventListener('click', function () {
        suppadvSel = this.getAttribute('data-saen');
        renderSuppadvView();
      });
    }
  }
  function showSuppadvView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = '🧩 Советчик саппортов (PoE2)';
    showMode('suppadv');
    if (!comboData) loadCombo();
    renderSuppadvView();
  }
  function loadGen() {
    var host = $('genContent');
    if (host) host.innerHTML = '<div class="lvl-hint">Загружаю ладдер ' + (genLeague || '') + '…</div>';
    window.poe2k.buildgenMeta(genLeague || undefined).then(function (res) {
      genData = res;
      if (res && res.ok && !genLeague) genLeague = res.league;
      renderGenView();
    }).catch(function (err) {
      genData = { ok: false, error: 'IPC error: ' + err };
      renderGenView();
    });
  }
  function showGenView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    $('itemName').textContent = genMode === 'combo'
      ? '🧬 Конструктор связок (датасет PoE2)'
      : '🧬 Генератор билдов (ладдер poe.ninja)';
    showMode('gen');
    if (genMode === 'combo') {
      if (comboData) renderGenView(); else loadCombo();
    } else if (genData) renderGenView();
    else loadGen();
    requestSize();
  }

  // ─── Вкладка «💎 Камни» (№66): сетапы камней билда — отдельная панель ──────
  // Данные — из payload build:update (gemSetups/gemColors/gemSeen), main не менялся.
  var lastBuildState = null;
  function gemKeySh(n) {
    return String(n || '').replace(/ё/g, 'е').replace(/\s+/g, ' ').trim().toLowerCase();
  }
  function gemMarkSh(b, en, expLvl) {
    var sv = (b.gemSeen || {})[gemKeySh(en)];
    if (!sv) return '⬜';
    var lvlTxt = sv.level != null ? (' ур.' + sv.level) : '';
    return '<span title="Скопирован ' + (sv.level != null ? 'ур.' + sv.level : '') +
      (expLvl != null ? ' · в билде ур.' + expLvl : '') + '">✅' + lvlTxt + '</span>';
  }
  function gemDotSh(b, n) {
    var c = (b.gemColors || {})[gemKeySh(n)];
    if (!c) return '';
    return c.split(',').map(function (h) { return '<span style="color:' + h + '">●</span>'; }).join('') + ' ';
  }
  function renderGemsTab(b) {
    if (!$('gemsWrap').classList.contains('hide')) {
      $('itemName').textContent = b ? '💎 Камни билда' : '💎 Камни: билд не загружен';
    }
    var el = $('gemsContent');
    if (!b || !b.gemSetups || !b.gemSetups.length) {
      el.innerHTML = '<div class="lvl-hint">Сетапы камней появятся после импорта билда — Ctrl+F3 или вкладка «📥 Импорт».<br/>' +
        'Скопируйте камень навыка (Ctrl+C в окне умений) — он отметится ✅ здесь и в списке.</div>';
      return;
    }
    el.innerHTML = '<div class="lvl-hint">Куда вставлять. Ctrl+C по камню в игре отметит его ✅.</div>' +
      '<table class="bld">' + b.gemSetups.map(function (g) {
        var lvl = g.activeLevel != null ? (' <span class="sub">ур. ' + g.activeLevel + '</span>') : '';
        // №106: бейдж привязки к оружейному набору (set1/set2 из PoB).
        var wset = '';
        if (g.weaponSet === '1' || g.weaponSet === '2') {
          wset = ' <span class="wset-badge" title="Камень привязан к набору оружия — вне набора игра пишет «нельзя использовать с текущими настройками оружия». В игре: окно умения → привязка набора, или переключите набор (X).">⚔ набор ' + (g.weaponSet === '1' ? 'I' : 'II') + '</span>';
        } else if (g.weaponSet === 'both') {
          wset = ' <span class="sub" title="Работает в любом наборе оружия (set1+set2 в PoB)">· любой набор</span>';
        }
        var html = '<tr><td>' + gemMarkSh(b, g.active, g.activeLevel) + '</td>' +
          '<td class="slot" colspan="3">' + gemDotSh(b, g.active) + '<b>' + esc(g.active) + '</b>' + lvl + wset +
          ' <span class="sub">→ ' + esc(g.where) + '</span></td></tr>';
        if (g.supports && g.supports.length) {
          var sup = g.supports.map(function (s) {
            return '<span>' + gemDotSh(b, s) + gemMarkSh(b, s, null) + ' ' + esc(s) + '</span>';
          }).join(' · ');
          html += '<tr class="wornrow"><td></td><td class="worn" colspan="3">+ ' + sup + '</td></tr>';
        }
        return html;
      }).join('') + '</table>';
  }
  // Клик по вкладке «💎 Камни»: чисто рендерерская панель (без IPC) — данные
  // приходят с build:update; повторный клик обновляет из последнего payload.
  function showGemsView() {
    $('idle').classList.add('hide');
    $('body').classList.remove('hide'); // №66-fix: с idle-экрана body был скрыт — вкладка показывала пустоту
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
    showMode('gems');
    renderGemsTab(lastBuildState);
  }

  // ─── Билд-ассистент (Ctrl+F2 / Ctrl+F3) ─────────────────────────────────────
  var SLOT_RU = {
    'Helm': 'Шлем', 'Body Armour': 'Броня', 'Gloves': 'Перчатки', 'Boots': 'Обувь',
    'Belt': 'Ремень', 'Amulet': 'Амулет', 'Ring': 'Кольцо', 'Ring 1': 'Кольцо 1',
    'Ring 2': 'Кольцо 2', 'Weapon 1': 'Оружие', 'Weapon 2': 'Оружие 2',
    'Weapon 3': 'Оружие 3', 'Gloves 2': 'Перчатки 2', 'Boots 2': 'Обувь 2',
    'Flask': 'Флакон', 'Flask 1': 'Флакон 1', 'Flask 2': 'Флакон 2',
    'Flask 3': 'Флакон 3', 'Flask 4': 'Флакон 4', 'Flask 5': 'Флакон 5'
  };

  // №92: блок стартового билда — выбор асценданси (кейстоуны из датасета)
  // и приоритеты дерева (реальные нотабли по статам гайда).
  function renderStarterInfo(b) {
    var st = b.starter;
    var host = $('buildSlots');
    if (!host || !st) return;
    var html = '<div class="starter-info">'
      + '<div class="sub-h sub">🏆 Асценданси (кейстоуны — из датасета дерева):</div><div class="starter-row">';
    st.ascendancies.forEach(function (a) {
      var on = st.ascPicked === a.name;
      var t = a.name + (a.hint ? '\\n⚡ ' + a.hint : '');
      html += '<button class="starter-btn' + (on ? ' on' : '') + '" data-asc="' + esc(a.name) + '" title="' + esc(t) + '">' + esc(a.name) + '</button>';
    });
    html += '</div>';
    if (st.ascKeystones && st.ascKeystones.length) {
      html += '<div class="sub" style="margin:2px 0 6px">⚡ ' + st.ascKeystones.map(esc).join(' · ') + '</div>';
    }
    if (st.treePriorities && st.treePriorities.length) {
      html += '<div class="sub-h sub">🌳 Приоритеты дерева (нотабли — поиск по датасету):</div><div class="sub">';
      st.treePriorities.slice(0, 8).forEach(function (p) {
        html += '• ' + esc(p.priority) + ' → <b>' + p.notables.map(esc).join(', ') + '</b><br/>';
      });
      html += '</div>';
    }
    html += '</div>';
    host.insertAdjacentHTML('beforeend', html);
    var btns = host.querySelectorAll('[data-asc]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener('click', function () {
        window.poe2k.starterPickAsc(this.getAttribute('data-asc')).catch(function () {});
      });
    }
  }

  function slotRu(s) {
    return SLOT_RU[s] || s || '—';
  }

  // №91: стартовые билды новичка (сюжет) — кнопки 8 классов на пустой панели билда.
  function renderStarterBuilds() {
    var host = $('buildSlots');
    if (!host) return;
    host.innerHTML = '<div class="sub-h sub">🌱 Стартовый билд новичка (проход сюжета)</div>' +
      '<div class="starter-row" id="starterRow"><span class="sub">Загрузка классов…</span></div>' +
      '<div class="sub-h sub">…или импорт готового билда</div>';
    window.poe2k.starterList().then(function (list) {
      var row = $('starterRow');
      if (!row || !list || !list.length) return;
      var html = '';
      list.forEach(function (c) {
        html += '<button class="starter-btn" data-class="' + esc(c.className) + '" title="' + esc(c.tagline) + '">' +
          esc(c.className) + '</button>';
      });
      row.innerHTML = html;
      var btns = row.querySelectorAll('.starter-btn');
      for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener('click', function () {
          window.poe2k.starterImport(this.getAttribute('data-class')).catch(function () {});
        });
      }
    }).catch(function () {});
  }

  // №113c: адаптивная точность (медиана бывает < 0.1 хаоса — toFixed(1) давал «0.0»).
  function fmtChaosNum(v) {
    var a = Math.abs(Number(v));
    if (!Number.isFinite(a)) return String(v);
    if (a >= 10) return a.toFixed(1);
    if (a >= 1) return a.toFixed(2);
    return a.toFixed(3);
  }

  function fmtPrice(v) {
    if (v == null) return '…';
    return Number(v) >= 1000
      ? (Number(v) / 1000).toFixed(1) + 'k chaos'
      : fmtChaosNum(v) + ' chaos';
  }

  // ─── №586: иконки валют рядом с ценой ────────────────────────────────────────
  // Иконки — userData/currency_icons/<key>.webp (main синхронизирует из датасета
  // core, пробелы → '_'). Ключ строго [a-z_]: попадание чужих символов → нет
  // иконки (безопасность src), цена остаётся текстом без поломки.
  var CUR_ALIASES = {
    chaos: 'chaos orb', div: 'divine orb', divine: 'divine orb',
    exalted: 'exalted orb', ex: 'exalted orb', exalt: 'exalted orb',
    mirror: 'mirror of kalandra', vaal: 'vaal orb', regal: 'regal orb',
    alch: 'orb of alchemy', annul: 'orb of annulment',
    augmentation: 'orb of augmentation', aug: 'orb of augmentation',
    transmute: 'orb of transmutation', chance: 'orb of chance'
  };
  function curIcon(name, size) {
    var k = String(name == null ? '' : name).toLowerCase().replace(/\s+/g, ' ').trim();
    if (CUR_ALIASES[k]) k = CUR_ALIASES[k];
    if (!/^[a-z][a-z\s'\-]*$/.test(k)) return '';
    return '<img class="cur-ico" src="currency_icons/' + k.replace(/\s+/g, '_') + '.webp" alt="" width="' +
      (size || 18) + '" height="' + (size || 18) + '" />';
  }

  // ── Помощник по пассивному дереву: кейнстоуны/нотабли PoB-билда + поиск нод ──
  var treeSearchTimer = null;
  function treeNodeRow(n) {
    var stats = (n.stats || []).slice(0, 2).map(esc).join(' / ');
    var asc = n.ascendancy ? ' <span class="tstats">[' + esc(n.ascendancy) + ']</span>' : '';
    var mark = n.isKeystone ? '⚡ ' : (n.isNotable ? '★ ' : '· ');
    return '<div class="tnode">' + mark + '<b>' + esc(n.name) + '</b>' + asc +
      (stats ? ' <span class="tstats">' + stats + '</span>' : '') + '</div>';
  }
  function renderTreeBlock(t) {
    var host = $('buildTree');
    if (!t || ((!t.keystones || !t.keystones.length) && (!t.notables || !t.notables.length))) {
      host.innerHTML = '';
      return;
    }
    var html = '<div class="sub-h sub">🌳 Дерево билда: ' + t.resolved + '/' + t.total + ' нод' +
      (t.version ? ' (v' + esc(t.version) + ')' : '') +
      (t.missing ? ' <span class="tstats">нераспознанных: ' + t.missing + '</span>' : '') + '</div>';
    if (t.keystones && t.keystones.length) {
      html += '<div class="sub">Кейнстоуны:</div>' + t.keystones.map(treeNodeRow).join('');
    }
    var notables = t.notables || [];
    html += '<div class="sub">Нотабли (' + notables.length + '):</div>';
    if (notables.length > 8) {
      html += '<div id="treeNotList" class="hide">' + notables.map(treeNodeRow).join('') + '</div>' +
        '<div class="tstats"><a href="#" id="treeNotToggle">показать все ' + notables.length + '</a></div>';
    } else if (notables.length) {
      html += notables.map(treeNodeRow).join('');
    }
    html += '<input id="treeSearch" placeholder="Поиск узлов: имя или стат (напр. cold damage)">' +
      // №129: кликабельный фильтр по нодам — ввод текста у друга не гарантирован
      // (окно зависит от focus-режимов), popular-запросы должны работать мышью.
      '<div id="treeChips" class="tree-chips"></div>' +
      '<div id="treeResults"></div>';
    host.innerHTML = html;
    var QUICK_TREE = [
      ['резисты', 'resist', 'resists'],
      ['жизнь', 'life', 'life'],
      ['эн. щит', 'energy shield', 'ES'],
      ['урон', 'damage', 'damage'],
      ['крит', 'critical', 'crit'],
      ['скор. атаки', 'attack speed', 'atk speed'],
      ['скор. магии', 'cast speed', 'cast speed'],
      ['мана', 'mana', 'mana'],
    ];
    var chipsBox = $('treeChips');
    if (chipsBox) {
      chipsBox.innerHTML = QUICK_TREE.map(function (q, i) {
        var label = LANG === 'en' ? q[2] : q[0];
        return '<button class="chip" data-q="' + esc(q[1]) + '" title="Показать узлы: ' + esc(q[1]) + '">' + esc(label) + '</button>';
      }).join('');
    }
    function runTreeSearch(q) {
      clearTimeout(treeSearchTimer);
      if (q.length < 2) { res.innerHTML = ''; return; }
      treeSearchTimer = setTimeout(function () {
        window.poe2k.treeSearch(q).then(function (nodes) {
          res.innerHTML = (nodes || []).length
            ? '<div class="sub">Найдено: ' + nodes.length + '</div>' + nodes.map(treeNodeRow).join('')
            : '<div class="tstats">ничего не найдено</div>';
        }).catch(function () {});
      }, 120);
    }
    if (chipsBox) {
      chipsBox.onclick = function (ev) {
        var b = ev.target;
        if (!b || !b.getAttribute || !b.getAttribute('data-q')) return;
        // подсветка активного чипа; повторный клик — сброс
        var was = b.classList.contains('on');
        var all = chipsBox.querySelectorAll('button.chip');
        for (var i = 0; i < all.length; i++) all[i].classList.remove('on');
        if (was) { res.innerHTML = ''; return; }
        b.classList.add('on');
        var q = b.getAttribute('data-q');
        if (inp) inp.value = ''; // чипсы и текстовый поиск не смешиваются
        runTreeSearch(q);
      };
    }
    var tg = $('treeNotToggle');
    if (tg) {
      tg.onclick = function (ev) {
        ev.preventDefault();
        var list = $('treeNotList');
        list.classList.toggle('hide');
        tg.textContent = list.classList.contains('hide')
          ? 'показать все ' + notables.length
          : 'свернуть';
      };
    }
    var inp = $('treeSearch');
    var res = $('treeResults');
    inp.oninput = function () {
      // сброс подсветки чипсов при ручном вводе
      if (chipsBox) {
        var all = chipsBox.querySelectorAll('button.chip');
        for (var i = 0; i < all.length; i++) all[i].classList.remove('on');
      }
      runTreeSearch(inp.value.trim());
    };
    inp.onkeydown = function (ev) { ev.stopPropagation(); };
  }

  function renderBuild(state) {
    var wrap = $('buildWrap');
    var err = $('buildErr');
    var berr = $('buildErr');
    err.classList.add('hide');

    if (!state || !state.build) {
      $('itemName').textContent = 'Билд не загружен';
      if (state && state.error) {
        berr.classList.remove('hide');
        berr.textContent = '⚠ ' + state.error;
      }
      $('buildHead').textContent = '';
      $('buildBudget').textContent = '';
      $('buildSlots').innerHTML = '';
      $('buildSum').textContent = 'Ctrl+F3 — импорт: скопируйте PoB share-код / .build JSON и нажмите.';
      renderStarterBuilds();
      lastBuildState = null;
      renderGemsTab(null);
      return;
    }

    var b = state.build;
    var who = [b.ascendancy || b.className || 'Билд', b.level ? ('ур. ' + b.level) : '']
      .filter(Boolean).join(' · ');
    $('itemName').textContent = '🛒 Шопинг-лист билда';
    $('buildHead').innerHTML = esc(who) +
      (b.skills && b.skills.length
        ? ' <span class="sub">' + esc(b.skills.slice(0, 3).join(', ')) + '</span>'
        : '');

    var done = b.boughtCount + '/' + b.totalSlots + ' собрано';
    $('buildBudget').innerHTML =
      'Бюджет: ' + esc(fmtPrice(b.budgetLeft)) +
      '<span class="done"> · ' + esc(done) +
      (b.pricedCount < b.totalSlots ? ' · оценяется ' + b.pricedCount + '/' + b.totalSlots : '') +
      '</span>';

    // Индикатор автосинхронизации с персонажем poe.ninja.
    if (b.charSync && b.charSync.character) {
      var age = b.charSync.lastSyncAt ? Math.round((Date.now() - b.charSync.lastSyncAt) / 60000) : null;
      $('buildBudget').innerHTML +=
        '<span class="done"> · 🧍 ' + esc(b.charSync.character) +
        (b.charSync.syncing ? ' ⟳' : (age != null ? ' (' + (age < 1 ? 'свежо' : age + ' мин') + ')' : '')) +
        '</span>';
    }

    var rows = (b.slots || []).map(function (s) {
      var icon = s.status === 'bought' ? '✔' : '⬜';
      var price = s.median != null ? fmtPrice(s.median) : (state.pricing ? '…' : '—');
      var row = '<tr class="' + (s.status === 'bought' ? 'bought' : '') + '">' +
        '<td>' + icon + '</td>' +
        '<td class="slot">' + esc(slotRu(s.slot)) + '</td>' +
        '<td class="nm" title="' + esc(s.name) + (s.note ? ' — искать: ' + esc(s.note) : '') + '">' + esc(s.name) + '</td>' +
        '<td class="num">' + (s.median != null ? curIcon('chaos', 14) : '') + esc(price) + '</td>' +
        '</tr>';
      // №92-бис: подсказка «что искать» видима строкой (тултип никто не найдёт),
      // не только в title.
      if (s.note && s.status !== 'bought') {
        row += '<tr class="wornrow"><td></td><td></td>' +
          '<td class="worn" title="' + esc(s.note) + '">🔍 иск: ' + esc(s.note) + '</td>' +
          '<td></td></tr>';
      }
      // Что сейчас надето в этом слоте на персонаже (poe.ninja), если не совпадает.
      if (s.worn && s.status !== 'bought') {
        row += '<tr class="wornrow"><td></td><td></td>' +
          '<td class="worn" colspan="1" title="Надето сейчас (poe.ninja)">↑ носите: ' + esc(s.worn) + '</td>' +
          '<td></td></tr>';
      }
      return row;
    }).join('');
    $('buildSlots').innerHTML = '<table class="bld">' + rows + '</table>';
    // №91+92: стартовые билды доступны и с загруженным билдом — полоска внизу таблицы.
    var stWrap = document.createElement('div');
    stWrap.className = 'starter-row';
    stWrap.innerHTML = '<span class="sub-h sub">🌱 Стартовый билд новичка:</span>';
    window.poe2k.starterList().then(function (list) {
      if (!list) return;
      list.forEach(function (c) {
        var btn = document.createElement('button');
        btn.className = 'starter-btn';
        btn.title = c.tagline;
        btn.textContent = c.className;
        btn.addEventListener('click', function () {
          // №92-бис: случайный клик не должен стереть импортированный PoB-билд.
          if (lastBuildState && !lastBuildState.isStarter &&
              !window.confirm('Заменить текущий билд стартовым (' + c.className + ')?\\n' +
                'Импортированный билд будет удалён из панели (слоты/цены/чек-лист).')) {
            return;
          }
          window.poe2k.starterImport(c.className).catch(function () {});
        });
        stWrap.appendChild(btn);
      });
      $('buildSlots').appendChild(stWrap);
      if (b.starter) renderStarterInfo(b);
    }).catch(function () {});
    // №66: вкладка «💎 Камни» обновляется из того же payload.
    lastBuildState = b;
    renderGemsTab(b);

    // Дерево билда: кейнстоуны/нотабли PoB + поиск по всему дереву (офлайн).
    renderTreeBlock(b.tree);

    var sum = [];
    if (b.summary) {
      if (b.summary.worstEhp != null) {
        sum.push('Слабейший EHP: <b>' + Math.round(b.summary.worstEhp).toLocaleString('ru-RU') +
          '</b> (' + esc(b.summary.worstEhpType) + ')');
      }
      if (b.summary.weaponDps != null && b.summary.weaponDps > 0) {
        // №131: полноценный DPS-блок с разбивкой + честная пометка «расчётный, не живой»
        var dpsParts = [];
        if (b.summary.weaponPhysDps != null && b.summary.weaponPhysDps > 0) dpsParts.push('физ ' + Math.round(b.summary.weaponPhysDps).toLocaleString('ru-RU'));
        if (b.summary.weaponElemDps != null && b.summary.weaponElemDps > 0) dpsParts.push('элем ' + Math.round(b.summary.weaponElemDps).toLocaleString('ru-RU'));
        var dpsBreak = dpsParts.length ? ' <span class="sub" style="color:#9aa4b0">(' + dpsParts.join(' + ') +
          (b.summary.weaponAps ? ' · ' + b.summary.weaponAps + ' уд/с' : '') + ')</span>' : '';
        sum.push('⚔ DPS по гиру (' + esc(b.summary.weapon || '?') + '): <b title="Расчётный DPS из гира (PoB-оценка), не живой замер: GGG не отдаёт урон внешним тулам. Живой замер — время убийства тренировочного манекена в убежище.">' +
          Math.round(b.summary.weaponDps).toLocaleString('ru-RU') + '</b>' + dpsBreak);
      }
      (b.summary.gaps || []).forEach(function (g) {
        sum.push('<span class="gap">⚠ ' + esc(g.description) + '</span>');
      });
    }
    // №85: мост core.advice — диагноз + чек-лист «что чинить/покупать следующим».
    if (b.advice) {
      if (b.advice.classification) sum.push('Диагноз: <b>' + esc(b.advice.classification) + '</b>' +
        ' <span class="sub" style="color:#9aa4b0">(' + esc(b.advice.summary) + ')</span>');
      var PRIO_MARK = { blocking: '🔴', high: '🟠', medium: '🟡', low: '🟢' };
      (b.advice.items || []).slice(0, 3).forEach(function (it) {
        sum.push('<span class="gap">' + (PRIO_MARK[it.priority] || '•') + ' ' + esc(it.title) +
          ' <span class="sub" style="color:#9aa4b0">— ' + esc(it.action) + '</span></span>');
      });
      (b.advice.checklist || []).slice(0, 3).forEach(function (c) {
        sum.push('✔ ' + esc(c));
      });
    }
    if (b.metaSkills && b.metaSkills.length) {
      sum.push('Мета ладдера: ' + b.metaSkills.slice(0, 3).map(function (s) {
        return esc(s.name) + ' ×' + s.count;
      }).join(', '));
    }
    sum.push('<span class="sub" style="color:#9aa4b0">Ctrl+F1 на купленном предмете — отметит слот ✔</span>');
    $('buildSum').innerHTML = sum.join('<br/>');

    if (state.error) {
      berr.classList.remove('hide');
      berr.textContent = '⚠ ' + state.error;
    }
  }

  window.poe2k.onBuildUpdate(function (state) {
    if (!state) return;
    if (!state.visible && !(state.error && !state.build) && !state.info) return;
    // №101: пользователь на вкладке «Импорт» и это результат импорта (успех/ошибка) —
    // остаёмся во вью импорта, рисуем итог там; showMode('build') не дёргаем.
    if (activeTab === 'import' && (state.error || state.visible)) {
      importResult = state.error
        ? { error: state.error }
        : {
            ok:
              (state.build.className ? state.build.className + ' / ' : '') +
              (state.build.ascendancy ? state.build.ascendancy + ' / ' : '') +
              (state.build.slots ? state.build.slots.length : 0) + ' слотов',
          };
      showImportView();
      return;
    }
    // №138-бис (живой репорт: «открыл Курс — перекидывает на Билд»): build:update
    // приходит фоном (charSync/watch/прайсинг) — НЕ воровать активную вкладку.
    // Данные рендерим (buildSum свежий при возврате), но showMode('build')
    // дёргаем только если юзер на Билде или панель ещё в idle-старте.
    const steal = activeTab === '' || activeTab === 'build';
    if (steal) {
      setBusy(false);
      $('idle').classList.add('hide');
      $('body').classList.remove('hide');
      $('est').classList.add('hide');
      $('busy').classList.add('hide');
      showMode('build');
    }
    renderBuild(state);
    // Инфо-сообщение (например, «синхронизация включена») — тем же блоком, но без «⚠».
    if (state.info) {
      $('buildErr').classList.remove('hide');
      $('buildErr').textContent = state.info;
    }
  });


  window.poe2k.onLevelResult(function (lvl) {
    if (!lvl) return;
    setBusy(false);
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    $('itemName').innerHTML = esc(lvl.summary || 'Персонаж');
    $('err').classList.add('hide');
    $('meta').classList.add('hide');
    showMode('level');

    var zoneEl = $('lvlZone');
    zoneEl.textContent = lvl.zone && (lvl.zone.name || lvl.zone.code)
      ? '📍 ' + (lvl.zone.name || lvl.zone.code)
      : (lvl.available ? 'Зона неизвестна' : '⚠️ ' + (lvl.reason || 'Client.txt не найден'));

    // №140: маршрут акта + прогресс (лига/сброс) для шапки renderCamp
    window.poe2k.__lastLevelProgress = lvl.progress || null;
    // №143: таймер босса текущей зоны (для карточек боссов).
    window.poe2k.__bossTimer = lvl.bossTimer || null;
    renderCamp(lvl.camp);
    // №104: бестиарий боссов (№143: + bt — таймер/статистика текущей зоны)
    renderBosses(lvl.bosses, lvl.camp, window.poe2k.__bossTimer);
    // №108: чек-лист неполученных квестовых наград
    renderQuests(lvl.quests);
    // №112-lite: обзор эндгейм-механик + этажность Sekhemas
    renderEndgame(lvl.endgame);

    var hints = $('lvlHints');
    hints.innerHTML = '';
    // №140: причина недавнего сброса прогресса — первой строкой (одноразовая:
    // в main сброс живёт до первого нового визита зоны).
    if (lvl.progress && lvl.progress.resetNote) {
      var rn = document.createElement('div');
      rn.className = 'lvl-hint';
      rn.style.color = '#e0b060';
      rn.textContent = '🔄 Прогресс прокачки сброшен: ' + lvl.progress.resetNote +
        '. Открой зоны по порядку — статусы «пройдено» восстановятся по логу.';
      hints.appendChild(rn);
    }
    var items = (lvl.hints || []).slice(0, 5);
    for (var i = 0; i < items.length; i++) {
      var d = document.createElement('div');
      d.className = 'lvl-hint';
      d.textContent = items[i].replace('📍 ', '').replace('➡️ ', '➡ ');
      hints.appendChild(d);
    }
    if (!items.length) {
      hints.innerHTML = '<div class="lvl-hint">Подсказок нет — идите вперёд по плану.</div>';
    }
    // №103: пока открыта панель прокачки — подпитывать контекст каждые 20 с
    // (зоны меняются часто; panelOpen — no-op если панель уже открыта).
    campStartPoll(lvl.camp);
  });

  /** №103: отрисовать маршрут акта (campWrap). */
  function renderCamp(camp) {
    var wrap = $('campWrap');
    wrap.innerHTML = '';
    if (!camp || !camp.rows || !camp.rows.length) return;

    var head = document.createElement('div');
    head.className = 'camp-head';
    // №140: шапка с лигой-владельцем прогресса + чужой сброс для нового перса.
    var prog = window.poe2k.__lastLevelProgress || null;
    head.textContent = camp.actName + '  ·  ' + camp.done + '/' + camp.total + ' зон' +
      (prog && prog.league ? '  ·  лига: ' + prog.league : '');
    // №140: ручной сброс — новый персонаж в той же лиге (КДЫ зон очищаются,
    // по логу статусы восстановятся по мере прохождения этим персонажем).
    var resetBtn = document.createElement('button');
    resetBtn.className = 'tree-chip';
    resetBtn.style.cssText = 'margin:0 0 0 8px;padding:1px 8px;font-size:11px;vertical-align:middle';
    resetBtn.title = 'Новый персонаж в этой лиге? Сбросит пройденные зоны и «забранные» награды — статусы соберутся заново по логу.';
    resetBtn.textContent = '🔄 Сброс';
    resetBtn.addEventListener('click', function () {
      window.poe2k.levelReset();
    });
    head.appendChild(resetBtn);
    wrap.appendChild(head);

    var prog = document.createElement('div');
    prog.className = 'camp-prog';
    var bar = document.createElement('i');
    bar.style.width = Math.round(((camp.done + (camp.currentIndex >= 0 ? 1 : 0)) / camp.total) * 100) + '%';
    prog.appendChild(bar);
    wrap.appendChild(prog);

    for (var i = 0; i < camp.rows.length; i++) {
      var r = camp.rows[i];
      var row = document.createElement('div');
      row.className = 'camp-row ' + r.status;

      var name = document.createElement('div');
      name.className = 'camp-zname';
      name.textContent = r.status === 'current' ? '📍 ' + r.zone :
        (r.status === 'done' ? '✔ ' + r.zone : '○ ' + r.zone);
      var meta = document.createElement('span');
      meta.className = 'camp-meta';
      meta.textContent = 'ур. ' + r.monsterLevel +
        (r.levelDelta != null && r.status !== 'done'
          ? (r.levelDelta < -2 ? ' (⚠ зона на ' + (-r.levelDelta) + ' выше вас)' : (r.levelDelta > 3 ? ' (зона на ' + r.levelDelta + ' ниже вас — быстро)' : (r.levelDelta < 0 ? ' (выше вас на ' + (-r.levelDelta) + ')' : '')))
          : '');
      name.appendChild(meta);
      if (r.hasWaypoint) {
        var wp = document.createElement('span');
        wp.className = 'camp-wp';
        wp.title = 'В зоне есть вайпоинт (быстрый телепорт)';
        wp.textContent = '⌖WP';
        name.appendChild(wp);
      }
      for (var j = 0; j < (r.rewards || []).length; j++) {
        var b = document.createElement('span');
        b.className = 'camp-badge';
        b.textContent = r.rewards[j];
        name.appendChild(b);
      }
      if (r.boss) {
        var bo = document.createElement('span');
        bo.className = 'camp-boss';
        bo.textContent = '⚔ ' + r.boss.name;
        if (r.boss.reward) bo.title = r.boss.reward;
        name.appendChild(bo);
      }
      row.appendChild(name);

      if (r.note) {
        var note = document.createElement('div');
        note.className = 'camp-note';
        note.textContent = r.note;
        row.appendChild(note);
      }
      wrap.appendChild(row);
    }

    if (camp.actNote) {
      var an = document.createElement('div');
      an.className = 'camp-actnote';
      an.textContent = '🎁 ' + camp.actNote;
      wrap.appendChild(an);
    }
  }

  /** №104: бестиарий боссов (все сюжетные по актам + триалы + пиннакл). */
  // №143: mm:ss (или h:mm:ss) для таймера босса.
  function fmtBossMs(ms) {
    if (!isFinite(ms) || ms < 0) return '—';
    var s = Math.floor(ms / 1000);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var ss = s % 60;
    var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
    return h > 0 ? h + ':' + pad(m) + ':' + pad(ss) : m + ':' + pad(ss);
  }
  // №143: один глобальный тикер для всех видимых таймеров (без утечки интервалов).
  if (!window.__bossTick) {
    window.__bossTick = window.setInterval(function () {
      var els = document.querySelectorAll('[data-boss-elapsed]');
      for (var i = 0; i < els.length; i++) {
        var st = Number(els[i].getAttribute('data-boss-start'));
        if (isFinite(st) && st > 0) els[i].textContent = fmtBossMs(Date.now() - st);
      }
    }, 1000);
  }
  function renderBosses(bosses, camp, bt) {
    var wrap = $('campWrap');
    if (!bosses || !bosses.story) return;
    var curAct = camp && camp.act;

    var sec = document.createElement('div');
    sec.className = 'boss-sec';
    var head = document.createElement('div');
    head.className = 'camp-head';
    head.textContent = '⚔ Боссы';
    sec.appendChild(head);

    function entry(b, cur) {
      var e = document.createElement('div');
      e.className = 'boss-entry' + (cur ? ' boss-cur' : '') + (b.verified === false ? ' boss-unverified' : '');
      var nm = document.createElement('div');
      nm.className = 'boss-name';
      // №109: двойное имя, если RU-локализация подтверждена (name_ru задан).
      nm.textContent = (b.floor ? 'Этаж ' + b.floor + ' · ' : '') + b.name +
        (b.name_ru ? ' (' + b.name_ru + ')' : '');
      if (b.verified === false) {
        // №109: ничего не выдумываем — запись из источников, но не подтверждена.
        var unv = document.createElement('span');
        unv.className = 'boss-unv-mark';
        unv.textContent = 'не подтверждено';
        unv.title = b.unverifiedNote || 'Запись не верифицирована по живым источникам — проверить в игре.';
        nm.appendChild(unv);
      }
      e.appendChild(nm);
      var sub = document.createElement('div');
      sub.className = 'boss-sub';
      sub.textContent = (b.zone ? b.zone : (b.access ? '🔑 ' + b.access : '')) +
        (b.act && b.zone ? ' · акт ' + b.act : '') +
        (b.reward ? ' · 🎁 ' + b.reward : '');
      e.appendChild(sub);
      if (b.access && b.zone) {
        var ac = document.createElement('div');
        ac.className = 'boss-sub';
        ac.textContent = '🔑 ' + b.access;
        e.appendChild(ac);
      }
      if (b.tips) {
        for (var t = 0; t < b.tips.length; t++) {
          var tp = document.createElement('div');
          tp.className = 'boss-tip';
          tp.textContent = '• ' + b.tips[t];
          e.appendChild(tp);
        }
      }
      // №143: расширенная карточка — только верифицированные данные.
      if (b.strengths) {
        var stw = document.createElement('div');
        stw.className = 'boss-tip';
        stw.innerHTML = '<span style="color:#e0a34c">💪 Сильные стороны:</span>';
        e.appendChild(stw);
        for (var si2 = 0; si2 < b.strengths.length; si2++) {
          var st2 = document.createElement('div');
          st2.className = 'boss-tip';
          st2.textContent = '  • ' + b.strengths[si2];
          e.appendChild(st2);
        }
      }
      if (b.weaknesses) {
        var wkw = document.createElement('div');
        wkw.className = 'boss-tip';
        wkw.innerHTML = '<span style="color:#7fc97f">🎯 Как бить:</span>';
        e.appendChild(wkw);
        for (var wi2 = 0; wi2 < b.weaknesses.length; wi2++) {
          var wk2 = document.createElement('div');
          wk2.className = 'boss-tip';
          wk2.textContent = '  • ' + b.weaknesses[wi2];
          e.appendChild(wk2);
        }
      }
      if (b.farm) {
        var fmw = document.createElement('div');
        fmw.className = 'boss-tip';
        fmw.innerHTML = '<span style="color:#9db4e8">🪙 Что фармится / зачем идут:</span>';
        e.appendChild(fmw);
        for (var fi = 0; fi < b.farm.length; fi++) {
          var fm = document.createElement('div');
          fm.className = 'boss-tip';
          fm.textContent = '  • ' + b.farm[fi];
          e.appendChild(fm);
        }
      }
      // №143: свой таймер — только у босса ТЕКУЩЕЙ зоны (старт = вход в зону по логу).
      if (b.zoneCode && bt && bt.zoneCode === b.zoneCode) {
        var tm = document.createElement('div');
        tm.className = 'boss-timer';
        var hasStart = bt.startedAt != null && bt.startedAt > 0;
        tm.innerHTML =
          '<div style="font-size:12px;color:#fff">⏱ Попытка: <span data-boss-elapsed data-boss-start="' +
          (hasStart ? bt.startedAt : 0) + '" style="font-size:13px;font-weight:700">' +
          (hasStart ? fmtBossMs(Date.now() - bt.startedAt) : '—') + '</span>' +
          ' <span class="tree-chips" style="display:inline-block;margin-left:4px">' +
          '<button class="tree-chip" data-btzone="' + esc(b.zoneCode) + '" data-btkind="kill">🏆 Убит</button> ' +
          '<button class="tree-chip" data-btzone="' + esc(b.zoneCode) + '" data-btkind="death">💀 Смерть</button></span></div>' +
          '<div class="lvl-hint" data-btstats>' +
          (bt.stats && bt.stats.kills
            ? 'Побед: ' + bt.stats.kills + ' · провалов: ' + (bt.stats.deaths || 0) +
              ' · лучшее: ' + fmtBossMs(bt.stats.best) + ' · прошлое: ' + fmtBossMs(bt.stats.last)
            : 'Попыток ещё не записано. Жми «🏆 Убит» сразу после убийства — время зафиксируется от входа в зону.') +
          '</div>';
        e.appendChild(tm);
        var btns = tm.querySelectorAll('[data-btzone]');
        for (var bi = 0; bi < btns.length; bi++) {
          btns[bi].addEventListener('click', function () {
            var zc = this.getAttribute('data-btzone');
            var kd = this.getAttribute('data-btkind');
            var statsEl = this.closest('.boss-timer')?.querySelector('[data-btstats]');
            if (statsEl) statsEl.textContent = '⏳ фиксирую…';
            window.poe2k.bossTimerDone(zc, kd).then(function (r) {
              if (r && r.ok) {
                if (statsEl) {
                  statsEl.textContent = (kd === 'kill' ? '🏆 Убит за ' : '💀 Провал через ') +
                    fmtBossMs(r.ms) + ' — записано. Обновляю…';
                }
                // свежий payload: onLevelResult перерисует бестиарий с новой статистикой
                window.poe2k.panelOpen('level');
              } else if (statsEl) {
                statsEl.textContent = '⚠ ' + ((r && r.error) || 'не удалось записать');
              }
            });
          });
        }
      }
      return e;
    }

    // Сюжет — по актам
    var byAct = {};
    for (var i = 0; i < bosses.story.length; i++) {
      var b = bosses.story[i];
      var k = b.act;
      (byAct[k] = byAct[k] || []).push(b);
    }
    var actKeys = Object.keys(byAct);
    actKeys.sort(function (a, b2) { return a.localeCompare(b2, 'ru', { numeric: true }); });
    for (var a = 0; a < actKeys.length; a++) {
      var grp = document.createElement('div');
      grp.className = 'boss-grp';
      var gt = document.createElement('div');
      gt.className = 'boss-grp-title';
      var isInter = actKeys[a] === 'I' || actKeys[a] === 'II' || actKeys[a] === 'III';
      gt.textContent = isInter ? 'Интерлюдия ' + actKeys[a] : 'Акт ' + actKeys[a];
      grp.appendChild(gt);
      var list = byAct[actKeys[a]];
      for (var j = 0; j < list.length; j++) grp.appendChild(entry(list[j], !isInter && Number(actKeys[a]) === curAct));
      sec.appendChild(grp);
    }
    if (bosses.trials && bosses.trials.length) {
      var tg = document.createElement('div');
      tg.className = 'boss-grp';
      var tt = document.createElement('div');
      tt.className = 'boss-grp-title';
      tt.textContent = 'Триалы асценданси';
      tg.appendChild(tt);
      for (var x = 0; x < bosses.trials.length; x++) tg.appendChild(entry(bosses.trials[x]));
      sec.appendChild(tg);
    }
    if (bosses.sekhemas && bosses.sekhemas.length) {
      var sg = document.createElement('div');
      sg.className = 'boss-grp';
      var st = document.createElement('div');
      st.className = 'boss-grp-title';
      st.textContent = 'Trial of the Sekhemas (лестница этажей)'
      sg.appendChild(st);
      // №109: лестница этажей — сортировка по floor, вход через Djorn Barya (act 2).
      var sk = bosses.sekhemas.slice().sort(function (a, b3) { return (a.floor || 0) - (b3.floor || 0); });
      for (var s = 0; s < sk.length; s++) sg.appendChild(entry(sk[s]));
      sec.appendChild(sg);
    }
    if (bosses.pinnacle && bosses.pinnacle.length) {
      var pg = document.createElement('div');
      pg.className = 'boss-grp';
      var pt = document.createElement('div');
      pt.className = 'boss-grp-title';
      pt.textContent = 'Пиннакл (эндгейм)';
      pg.appendChild(pt);
      for (var y = 0; y < bosses.pinnacle.length; y++) pg.appendChild(entry(bosses.pinnacle[y]));
      sec.appendChild(pg);
    }
    wrap.appendChild(sec);
  }

  /** №108: чек-лист неполученных квестовых наград (Spirit/резисты/асц/пассивки). */
  function renderQuests(quests) {
    var wrap = $('campWrap');
    var sec = document.createElement('div');
    sec.className = 'boss-sec';
    var list = (quests && quests.list) || [];
    var head = document.createElement('div');
    head.className = 'camp-head';
    head.textContent = '🎖 Неполученные квесты' + (list.length ? ' · ' + list.length : '');
    sec.appendChild(head);
    if (!list.length) {
      var okRow = document.createElement('div');
      okRow.className = 'boss-tip';
      okRow.textContent = 'Все важные награды собраны или отмечены «забрал».';
      sec.appendChild(okRow);
    } else if (quests && quests.coverage) {
      var cov = document.createElement('div');
      cov.className = 'boss-tip';
      cov.textContent = quests.coverage;
      sec.appendChild(cov);
    }
    var res = quests ? quests.resists : null;
    for (var i = 0; i < list.length; i++) {
      var q = list[i];
      var row = document.createElement('div');
      row.className = 'quest-row' + (q.status === 'missed' ? ' quest-missed' : '');
      var t = document.createElement('div');
      t.className = 'boss-sub';
      t.textContent = (q.status === 'missed' ? '⚠ упущено · ' : '◻ впереди · ') +
        'Акт ' + q.act + ' · ' + q.zone + ' — ' + q.rewardRu +
        (q.boss ? ' (за ' + q.boss + ')' : '');
      row.appendChild(t);
      // №108: подсветка — у персонажа этот резист < 75%, награда закрывает дыру.
      if (q.kind === 'resist' && res) {
        var low = q.resistKind === 'all'
          ? Math.min(res.fire, res.cold, res.lightning)
          : res[q.resistKind];
        if (low != null && low < 75) {
          var w = document.createElement('div');
          w.className = 'quest-warn';
          w.textContent = q.resistKind === 'all'
            ? 'Ваш худший элем. резист ' + low + '% (меньше 75%) — награда очень желательна'
            : 'Резист сейчас ' + low + '% (меньше 75%) — взять в первую очередь';
          row.appendChild(w);
        }
      }
      var btn = document.createElement('button');
      btn.className = 'quest-claim';
      btn.textContent = '✔ забрал';
      btn.title = 'Отметить награду полученной — уйдёт из чек-листа навсегда';
      btn.addEventListener('click', (function (rowEl, key) {
        return function () {
          rowEl.style.opacity = '0.4';
          rowEl.querySelector('.quest-claim').disabled = true;
          window.poe2k.levelClaim(key).then(function (r) {
            if (r && r.ok) {
              rowEl.remove();
            } else {
              rowEl.style.opacity = '';
              rowEl.querySelector('.quest-claim').disabled = false;
              showToast('Не удалось отметить награду — прогресс прокачки ещё не создан. Побывайте в любой зоне и попробуйте снова.');
            }
          }).catch(function () { rowEl.style.opacity = ''; });
        };
      })(row, q.key));
      row.appendChild(btn);
      sec.appendChild(row);
    }
    wrap.appendChild(sec);
  }

  /** №112-lite: обзор эндгейм-механик атласа + этажность Sekhemas по уровню. */
  function renderEndgame(endgame) {
    var wrap = $('campWrap');
    var sec = document.createElement('div');
    sec.className = 'boss-sec';
    var head = document.createElement('div');
    head.className = 'camp-head';
    head.textContent = '🗺 Эндгейм';
    sec.appendChild(head);
    if (!endgame) { wrap.appendChild(sec); return; }

    if (endgame.sekhemasFloors != null) {
      var fl = document.createElement('div');
      fl.className = 'boss-sub';
      fl.style.marginBottom = '4px';
      fl.textContent = '💒 Trial of the Sekhemas на вашем уровне: этажей до финала — ' + endgame.sekhemasFloors +
        ' (лестница боссов — раздел «⚔ Боссы» выше).';
      sec.appendChild(fl);
    }
    var rows = endgame.overview || [];
    for (var i = 0; i < rows.length; i++) {
      var m = rows[i];
      var r = document.createElement('div');
      r.className = 'boss-entry boss-cur';
      var nm = document.createElement('div');
      nm.className = 'boss-sub';
      nm.textContent = (m.name_ru || m.name) +
        (m.region ? ' · ' + (m.region === 'SE' ? 'ЮВ' : m.region === 'S' ? 'Ю' : m.region === 'W' ? 'З' : m.region === 'N' ? 'С' : m.region === 'E' ? 'В' : m.region) : '') +
        (m.kind === 'trial' ? ' · триал' : m.kind === 'citadel' ? ' · цитадель' : '');
      r.appendChild(nm);
      var sh = document.createElement('div');
      sh.className = 'boss-tip';
      sh.textContent = m.short_ru || '';
      r.appendChild(sh);
      if (m.access_ru) {
        var ac2 = document.createElement('div');
        ac2.className = 'boss-tip';
        ac2.textContent = '🔑 ' + m.access_ru;
        r.appendChild(ac2);
      }
      sec.appendChild(r);
    }
    var tips = endgame.waystoneTips || [];
    if (tips.length) {
      var wt = document.createElement('div');
      wt.className = 'boss-grp-title';
      wt.textContent = 'Плитки смотрителя (Waystones)';
      sec.appendChild(wt);
      for (var w2 = 0; w2 < tips.length; w2++) {
        var tr2 = document.createElement('div');
        tr2.className = 'boss-tip';
        tr2.textContent = '• ' + tips[w2].text_ru + (tips[w2].verified === false ? ' (цифры не верифицированы — проверить в игре)' : '');
        sec.appendChild(tr2);
      }
    }
    renderMapPrep(sec, endgame.mapPrep);
    wrap.appendChild(sec);
  }

  /** №234-Э4: «Вердикт карты» в панели «🗺 Эндгейм» — мост к core.mapPrep
   * (вся логика в main через IPC mapprep:check; здесь только UI-минимализм:
   * карта + тир + строка модов + кнопка). */
  function renderMapPrep(sec, mp) {
    if (!mp || !mp.maps || !mp.maps.length) return;
    var grp = document.createElement('div');
    grp.className = 'boss-grp-title';
    grp.textContent = 'Вердикт карты (waystone)';
    sec.appendChild(grp);
    var box = document.createElement('div');
    box.className = 'quest-row';
    box.style.marginBottom = '6px';

    var selMap = document.createElement('select');
    selMap.style.cssText = 'max-width:42%;font-size:11px;margin-right:4px;background:rgba(0,0,0,0.45);color:var(--fg);border:1px solid #2a3344;border-radius:4px';
    var opts = '<option value="">— карта —</option>';
    for (var i = 0; i < mp.maps.length; i++) {
      var m = mp.maps[i];
      opts += '<option value="' + esc(m.id) + '">' + esc(m.name) + '</option>';
    }
    selMap.innerHTML = opts;

    var selTier = document.createElement('select');
    selTier.style.cssText = 'font-size:11px;margin-right:4px;background:rgba(0,0,0,0.45);color:var(--fg);border:1px solid #2a3344;border-radius:4px';
    var topts = '<option value="">T?</option>';
    for (var t = 1; t <= 16; t++) topts += '<option value="' + t + '">T' + t + '</option>';
    selTier.innerHTML = topts;

    var inpMods = document.createElement('input');
    inpMods.placeholder = 'моды камня через ;';
    inpMods.spellcheck = false;
    inpMods.style.cssText = 'width:100%;box-sizing:border-box;margin:4px 0 3px 0;padding:3px 6px;border:1px solid #2a3344;border-radius:4px;background:rgba(0,0,0,0.35);color:var(--fg);font-size:11px';

    var btn = document.createElement('button');
    btn.textContent = 'Вердикт';
    btn.className = 'quest-claim';

    var out = document.createElement('div');
    out.style.cssText = 'margin-top:4px;font-size:11px;line-height:1.45';

    btn.addEventListener('click', function () {
      var mods = inpMods.value.split(/[;\\n|]/).map(function (s) { return s.trim(); }).filter(Boolean);
      out.textContent = 'Считаю…';
      var res = (mp.resists && typeof mp.resists.fire === 'number') ? mp.resists : null;
      window.poe2k.mapPrepCheck({ map: selMap.value, tier: selTier.value, mods: mods, resists: res })
        .then(function (r) { renderMapPrepResult(out, r); })
        .catch(function (e) { out.textContent = 'Ошибка: ' + (e && e.message ? e.message : e); });
    });

    box.appendChild(selMap);
    box.appendChild(selTier);
    box.appendChild(btn);
    box.appendChild(inpMods);
    box.appendChild(out);
    sec.appendChild(box);
  }

  function renderMapPrepResult(out, r) {
    out.innerHTML = '';
    if (!r || r.ok === false) {
      out.textContent = (r && r.error) ? '⚠ ' + r.error : 'Не удалось построить вердикт.';
      return;
    }
    var th = r.threat || {};
    var rows = [];
    rows.push('area level ' + (th.area_level != null ? th.area_level : '?') +
      ' · босс: ' + (th.boss && th.boss.name ? th.boss.name : 'шаблонный') +
      (((th.monsterEleBonus || 0) > 0 || (th.monsterChaosRes || 0) > 0)
        ? ' · монстрам +' + (th.monsterEleBonus || 0) + '% элем / +' + (th.monsterChaosRes || 0) + '% chaos резиста'
        : ''));
    var danger = (th.matchedMods || []).filter(function (m) { return m.threat; });
    for (var i = 0; i < danger.length; i++) {
      var d = danger[i].threat;
      var icon = d.kind === 'player_debuff' ? '⚠' : d.kind === 'monster_res' ? '🛡' :
        (d.element === 'fire' ? '🔥' : d.element === 'cold' ? '❄' : d.element === 'lightning' ? '⚡' : d.element === 'chaos' ? '☠' : '⚔');
      rows.push(icon + ' ' + danger[i].name + ' (ступень ' + (danger[i].tierIndex + 1) + ')' +
        (d.value != null ? ' −' + d.value + '%' : ''));
    }
    var unk = th.unknownMods || [];
    for (var u = 0; u < unk.length; u++) rows.push('❓ не распознан: ' + unk[u]);
    if (r.pool_assumed) rows.push('ℹ пул жизни неизвестен — использованы условные 3000 (резисты из билда)');
    if (!r.build_provided) rows.push('ℹ билд не импортирован — персональные EHP-чеки пропущены (Ctrl+F3)');
    var checks = r.checks || [];
    for (var c = 0; c < checks.length; c++) {
      if (checks[c].passed && checks[c].severity < 3) continue;
      rows.push((checks[c].passed ? '✅' : '⛔') + ' ' + checks[c].advice_ru +
        (checks[c].unverified ? ' ⚠ unverified' : '') + ' (severity ' + (Math.round(checks[c].severity * 10) / 10) + ')');
    }
    var notes = th.unverifiedNotes || [];
    for (var n = 0; n < notes.length; n++) rows.push('⚠️ ' + notes[n]);
    for (var r2 = 0; r2 < rows.length; r2++) {
      var div = document.createElement('div');
      div.className = 'boss-tip';
      div.textContent = rows[r2];
      out.appendChild(div);
    }
  }

  /** №103: автообновление контекста прокачки, пока вкладка видима. */
  var campTimer = null;
  function campStartPoll(camp) {
    if (campTimer) { clearInterval(campTimer); campTimer = null; }
    if (!camp || !camp.rows || !camp.rows.length) return;
    campTimer = setInterval(function () {
      // Панель сменилась/закрылась — таймер не нужен (у панелей single-mode,
      // но showMode других вкладок прячет lvlWrap).
      var wrap = $('campWrap');
      if (!wrap || wrap.classList.contains('hide') || !$('lvlWrap') || $('lvlWrap').classList.contains('hide')) {
        clearInterval(campTimer);
        campTimer = null;
        return;
      }
      window.poe2k.panelOpen('level');
    }, 20000);
  }

  function priceSingleView() {
    $('priceBatchWrap').classList.add('hide');
    var h = $('priceHead');
    if (h) h.classList.remove('hide');
  }
  function priceBatchView() {
    var h = $('priceHead');
    if (h) h.classList.add('hide');
    $('est').classList.add('hide');
    $('augLine').classList.add('hide');
    $('buildNote').classList.add('hide');
    $('meta').classList.add('hide');
    $('listWrap').classList.add('hide');
    $('err').classList.add('hide');
    $('watchBtnWrap').classList.add('hide');
    $('priceBatchWrap').classList.remove('hide');
  }

  // Один предмет из буфера — привычный детальный вид.
  function renderSinglePrice(res) {
    priceSingleView();

    // Название + редкость цветом.
    var name = $('itemName');
    name.classList.remove('rarity-rare','rarity-unique','rarity-magic','rarity-currency','rarity-normal','rarity-common');
    var rar = String(res.rarity || '').toLowerCase();
    name.classList.add('rarity-' + rar);
    name.innerHTML = esc(res.itemName || 'Предмет');

    // Оценка.
    var est = $('est');
    var note = $('buildNote');
    if (res.buildMatch) {
      note.classList.remove('hide');
      note.textContent = '✔ Слот билда: ' + res.buildMatch.slot + ' — отмечен собранным';
      note.title = res.buildMatch.name || '';
    } else {
      note.classList.add('hide');
      note.textContent = '';
    }
    // P10 (§4.3): вердикт «предмет vs билд» (opt-in verdictLayer + импорт билда).
    // Одна строка причинности (ITEM_CHECK_PRESENTATION-паттерн): gain/loss в лбу.
    var vdEl = $('verdictLine');
    if (res.verdict && res.verdict.verdict) {
      var V_ICON = { upgrade: '✅', minor_upgrade: '🔼', sidegrade: '⚖️', downgrade: '❌', uncertain: '❓', not_viable: '⛔' };
      var V_COLOR = { upgrade: '#7ec97e', minor_upgrade: '#a8d08d', sidegrade: '#d6c25a', downgrade: '#e07a6a', uncertain: '#9aa4b0', not_viable: '#c08a8a' };
      var vk = String(res.verdict.verdict);
      vdEl.classList.remove('hide');
      vdEl.innerHTML =
        '<b style="color:' + (V_COLOR[vk] || 'inherit') + '">' + (V_ICON[vk] || '') + ' ' +
        esc(res.verdict.headline || vk) + '</b>' +
        (res.verdict.slot ? ' <span class="tag-dim">[' + esc(res.verdict.slot) + ']</span>' : '');
      vdEl.title = (res.verdict.reasons || []).join(' · ');
    } else {
      vdEl.classList.add('hide');
      vdEl.innerHTML = '';
      vdEl.title = '';
    }

    if (res.estimate && res.estimate.median != null) {
      est.classList.remove('hide');
      var conf = res.estimate.confidence === 'exact' ? 'точно' : (res.estimate.confidence === 'approx' ? 'приблизительно' : 'грубо');
      var range = (res.estimate.min != null && res.estimate.max != null)
        ? ' ~' + fmtChaosNum(res.estimate.min) + '–' + fmtChaosNum(res.estimate.max) + ' chaos'
        : '';
      est.innerHTML = '<span class="value">' + curIcon('chaos') + fmtChaosNum(res.estimate.median) + ' chaos</span>' +
        '<span class="range">' + esc(range) + '</span>' +
        '<span class="conf">(' + esc(conf) + ')</span>';
      // №586-фаза-2: range (min–max) снова показывается; прежнее затирание
      // .range (труп-строка) удаляло полезный сигнал оценки.
    } else {
      est.classList.add('hide');
    }

    // №110: руна/ядро души в предмете — тир и вид (эффект НЕ выдумываем).
    var augEl = $('augLine');
    if (res.augment && res.augment.kindRu) {
      augEl.classList.remove('hide');
      augEl.innerHTML = '⇗ эффект: <b>' + esc(res.augment.kindRu) + '</b> · тир <b>' +
        esc(res.augment.tierRu || res.augment.tier || '?') + '</b>' +
        (res.augment.name ? ' · ' + esc(res.augment.name) : '');
      augEl.title = 'Руна/ядро души: тир и вид из core.runes. Точный эффект смотрите в игре — в датасете его нет.';
    } else {
      augEl.classList.add('hide');
      augEl.innerHTML = '';
    }

    // Ошибка (если только парсинг).
    var err = $('err');
    if (res.buildCodeHint) {
      err.classList.remove('hide');
      err.textContent = res.buildCodeHint;
    } else if (res.parseError) {
      err.classList.remove('hide');
      err.textContent = 'Оценка: ' + priceErrText(res);
    } else if (res.gemCheck) {
      // Гем: не предмет рынка — «не найдено в источниках» не показываем.
      err.classList.add('hide');
      err.textContent = '';
    } else if (!res.estimate) {
      err.classList.remove('hide');
      err.textContent = 'Оценка: не найдено в бесплатных источниках.';
    } else {
      err.classList.add('hide');
    }

    // №196-bis (S7-UI): баннер «N модов не распознано» — сигнал деградации
    // оценки (search по статам построен не на всех explicit-модах).
    var sb = $('statBanner');
    if (res.unmatchedMods && res.unmatchedMods.length) {
      var unm = res.unmatchedMods;
      sb.classList.remove('hide');
      sb.innerHTML = '⚠ Не распознаны моды: <b>' + unm.length + '</b>' +
        (res.statMatch ? ' из ' + res.statMatch.total : '') +
        ' — оценка может идти по базовому типу.' +
        '<div class="sb-list" title="' + esc(unm.join(' | ')) + '">' +
          esc(unm.slice(0, 3).join('; ') + (unm.length > 3 ? '; …' : '')) + '</div>' +
        '<button id="statReloadBtn" class="batch-ww" title="Сбросить кэш каталога статов trade2 и повторить поиск живым каталогом (после патча GGG)">🔄 Обновить каталог</button>';
      var rb = $('statReloadBtn');
      if (rb) {
        rb.onclick = function () {
          rb.disabled = true;
          rb.textContent = '⏳ Обновляю…';
          window.poe2k.reloadTradeStats().then(function (r) {
            if (r && r.ok) {
              sb.innerHTML = '✔ Каталог статов сброшен (' +
                (r.after && r.after.offlineEntries != null ? r.after.offlineEntries + ' записей' : '') +
                '). Нажмите Ctrl+F1 — прайс пойдёт по свежим данным.';
            } else {
              sb.innerHTML = '✖ Не удалось сбросить каталог. Повторите позже.';
            }
          });
        };
      }
    } else {
      sb.classList.add('hide');
      sb.innerHTML = '';
    }

    // Мета-источники.
    var meta = $('meta');
    if (res.sources && res.sources.length) {
      meta.classList.remove('hide');
      meta.innerHTML = 'Источники: <span class="src">' + esc(res.sources.join(', ')) + '</span>';
    } else {
      meta.classList.add('hide');
    }

    // Список похожих объявлений ИЛИ рекомендуемые саппорты гема.
    var lw = $('listWrap');
    var list = $('list');
    if (res.gemSupports && res.gemSupports.length) {
      var label = res.sources && res.sources[0] ? res.sources[0] : 'Рекомендуемые саппорты';
      var isMeta = res.gemSupports[0] && res.gemSupports[0].tier === 'meta';
      var srows = res.gemSupports.map(function (r) {
        var mark = r.inBuild ? ' <span class="done">✓ в билде</span>' : '';
        var rankCell = r.rank == null ? '—' : r.rank;
        var dot = r.color ? r.color.split(',').map(function (h) { return '<span style="color:' + h + '">●</span>'; }).join('') + ' ' : '';
        return '<tr><td class="num">' + rankCell + '</td><td colspan="2">' + dot + esc(r.name || r.ru || r.en) + mark + '</td></tr>';
      }).join('');
      var badge = isMeta
        ? '<span class="src" style="color:#7fd18c">⚡ эталон</span>'
        : '<span class="src" style="color:#9aa4b0">базово</span>';
      list.innerHTML =
        '<tr><td colspan="3" style="color:#9aa4b0">Саппорты ' + badge + ' — ' + esc(label) + ':</td></tr>' + srows;
      lw.classList.remove('hide');
    } else if (res.listings && res.listings.length) {
      // №67: сравнение с рынком — листинги сгруппированы по валюте, отсортированы
      // по возрастанию цены, полоска = доля от максимума группы, показана медиана.
      var ls = res.listings.slice().sort(function (a, b) { return (a.price || 0) - (b.price || 0); });
      var groups = {};
      for (var li = 0; li < ls.length; li++) {
        var cur = String(ls[li].currency || '?');
        (groups[cur] = groups[cur] || []).push(ls[li]);
      }
      var curNames = Object.keys(groups).sort(function (a, b) {
        return (groups[a][0].price || 0) - (groups[b][0].price || 0);
      });
      var rows = '';
      for (var gi = 0; gi < curNames.length; gi++) {
        var g = groups[curNames[gi]];
        var gmax = g[g.length - 1].price || 1;
        var gmid = g[Math.floor(g.length / 2)].price;
        // №68: медиана группы в chaos — если core проставил l.chaos (курс известен).
        var chVals = [];
        for (var ck = 0; ck < g.length; ck++) {
          if (g[ck].chaos != null) chVals.push(g[ck].chaos);
        }
        chVals.sort(function (a, b) { return a - b; });
        var chMid = chVals.length
          ? ' · ≈<b style="color:var(--accent)">' + curIcon('chaos', 14) + fmtChaosNum(chVals[Math.floor(chVals.length / 2)]) + '</b> chaos'
          : '';
        rows += '<tr><td colspan="3" class="grp">' + curIcon(curNames[gi], 14) + esc(curNames[gi]) +
          ' · предложений: ' + g.length + ' · медиана: <b>' + esc(String(gmid)) + '</b>' + chMid + '</td></tr>';
        for (var gj = 0; gj < g.length; gj++) {
          var l = g[gj];
          var w = Math.max(2, Math.round(((l.price || 0) / gmax) * 100));
          // №197 (S10): скам-флаги от core — предупреждающая пометка, не фильтр
          // (сообщение продавцу отправляет сам игрок своим решением).
          var flagHtml = '';
          if (l.flags && l.flags.length) {
            for (var fij = 0; fij < l.flags.length; fij++) {
              if (l.flags[fij] === 'too-cheap') {
                flagHtml += ' <span class="scam-flag" title="Цена сильно ниже рыночной медианы — типичный price-bait. Проверяйте предмет и продавца вручную.">⚠ подозрительно дёшево</span>';
              } else if (l.flags[fij] === 'overpriced') {
                flagHtml += ' <span class="scam-flag scam-flag-over" title="Цена сильно выше рыночной медианы — завышенный листинг.">✖ дороже рынка</span>';
              }
            }
          }
          rows += '<tr><td class="num">' + esc(String(l.price)) + '</td>' +
            '<td colspan="2"><span class="cmpbar" style="display:inline-block;width:' + w + '%"></span>' +
            flagHtml +
            (l.whisper ? ' <span class="sub">' + esc(l.whisper) + '</span>' : '') + '</td></tr>';
        }
      }
      list.innerHTML = '<tr><td colspan="3" style="color:#9aa4b0">Рынок (по возрастанию цены):</td></tr>' + rows;
      lw.classList.remove('hide');
    } else {
      lw.classList.add('hide');
    }

    // Кнопка «Следить»: добавить предмет в watchlist (гемы не прайсятся — прячем).
    var ww = $('watchBtnWrap');
    if (res.itemText && !res.gemCheck) {
      watchTarget = { itemText: res.itemText, label: res.itemName || 'Предмет', rarity: res.rarity };
      ww.classList.remove('hide');
      var wb = $('watchBtn');
      wb.textContent = '👁 Следить за ценой';
      wb.disabled = false;
    } else {
      ww.classList.add('hide');
    }
  }

  // Несколько предметов из буфера — список с оценками в одном виджете.
  function renderBatchPrice(payload) {
    priceBatchView();
    var items = payload.items || [];
    batchWatchTargets = [];
    var head = $('priceBatchHead');
    var total = payload.totalEstimate;
    var headTxt = '📦 Предметов: ' + items.length;
    if (total != null) headTxt += ' · сумма ~' + curIcon('chaos') + fmtChaosNum(total) + ' chaos';
    if (payload.elapsedMs != null) headTxt += ' · ' + Math.round(payload.elapsedMs / 1000) + 'с';
    head.textContent = headTxt;

    var cards = items.map(function (res, i) {
      var rar = String(res.rarity || '').toLowerCase();
      var estTxt;
      if (res.estimate && res.estimate.median != null) {
        var conf = res.estimate.confidence === 'exact' ? '' : (res.estimate.confidence === 'approx' ? ' ~' : ' грубо');
        estTxt = '<span class="value">≈' + curIcon('chaos') + fmtChaosNum(res.estimate.median) + ' chaos</span>' + '<span class="conf">(' + esc(conf) + ')</span>';
      } else {
        estTxt = '<span class="muted">н/д</span>';
      }
      var note = '';
      if (res.buildMatch) {
        note = '<span style="color:var(--ok)">✔ слот: ' + esc(res.buildMatch.slot) + '</span>';
      } else if (res.buildCodeHint) {
        note = '<span class="err-inline">' + esc(res.buildCodeHint) + '</span>';
      } else if (res.parseError) {
        note = '<span class="err-inline">' + esc('Оценка: ' + priceErrText(res)) + '</span>';
      } else if (!res.estimate) {
        note = '<span class="muted">не найдено в бесплатных источниках</span>';
      }
      // №196-bis: сокращённый сигнал распознавания в батч-вью (полный баннер — в одиночном).
      if (res.unmatchedMods && res.unmatchedMods.length) {
        note += '<span class="muted"> · ⚠ не распознано модов: ' + res.unmatchedMods.length + '</span>';
      }
      batchWatchTargets.push(
        res.itemText ? { itemText: res.itemText, label: res.itemName || ('Предмет ' + (i + 1)), rarity: res.rarity } : null,
      );
      if (res.itemText) {
        note = note + '<button class="batch-ww" data-idx="' + i + '">👁 Следить</button>';
      }
      return '<div class="batch-item rar-' + (rar || 'common') + '">' +
        '<div class="bi-name rarity-' + rar + '">' + esc(res.itemName || ('Предмет ' + (i + 1))) + '</div>' +
        '<div class="bi-est">' + estTxt + '</div>' +
        '<div class="bi-note">' + note + '</div>' +
        '</div>';
    }).join('') || '<div class="muted">Пустой буфер.</div>';
    $('priceBatchList').innerHTML = cards;
  }

  window.poe2k.onPriceBatch(function (payload) {
    if (!payload || !payload.items) { setBusy(false); return; }
    setBusy(false);
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    showMode('price');
    if (payload.items.length === 1) {
      renderSinglePrice(payload.items[0]);
    } else {
      renderBatchPrice(payload);
    }
  });

  // №111 «Чекап перед пиннаклом» (Ctrl+F7 / таб «🛡 Пиннакл»).
  window.poe2k.onPinnacleResult(function (p) {
    if (!p) return;
    setBusy(false);
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    renderPinnacle(p);
    showMode('pinnacle');
    setActiveTab('pinnacle');
  });

  /** №111: отрисовать чек-лист готовности к пиннаклу. */
  function renderPinnacle(p) {
    var wrap = $('pinnacleContent');
    wrap.innerHTML = '';
    var sec = document.createElement('div');
    sec.className = 'boss-sec';
    var head = document.createElement('div');
    head.className = 'camp-head';
    sec.appendChild(head);

    if (p.available === false) {
      head.textContent = '🛡 Чекап перед пиннаклом';
      var errRow = document.createElement('div');
      errRow.className = 'boss-entry boss-unverified';
      var et = document.createElement('div');
      et.className = 'boss-sub';
      et.textContent = '⚠ ' + (p.error || 'Чек-лист недоступен.');
      errRow.appendChild(et);
      sec.appendChild(errRow);
      wrap.appendChild(sec);
      return;
    }

    head.textContent = '🛡 Чекап перед пиннаклом · доступно проверок: ' +
      (p.availableChecks != null ? p.availableChecks + '/' + p.totalChecks : '?');

    if (p.enemy) {
      var en = document.createElement('div');
      en.className = 'boss-tip';
      en.style.marginBottom = '4px';
      en.textContent = 'Модель врага: уровень ' + p.enemy.level + ' · режим ' + p.enemy.boss +
        ' · пенетрация элем-резистов ' + p.enemy.elementalPenetration + '%';
      sec.appendChild(en);
    }
    var checks = p.checks || [];
    for (var i = 0; i < checks.length; i++) {
      var c = checks[i];
      var row = document.createElement('div');
      row.className = 'pin-row pin-' + (c.verdict || 'unknown');
      var mark = c.verdict === 'pass' ? '✔' : (c.verdict === 'fail' ? '✖' : '—');
      row.textContent = mark + ' ' + c.item + (c.detail ? ' · ' + c.detail : '');
      row.title = 'Источник: ' + (c.kind === 'computed' ? 'вычислено по правилу' : 'оценка из гира (может отличаться от игры)');
      sec.appendChild(row);
    }
    var note = document.createElement('div');
    note.className = 'boss-tip';
    note.textContent = '«—» = данных для проверки нет (импортируйте билд Ctrl+F3). ⚠ Оценки из гира — перед пиннаклом сверьтесь в игре.';
    sec.appendChild(note);
    wrap.appendChild(sec);
  }

  // №584 «Ритуал-скан» (Ctrl+F8 / таб «🕯 Ритуал»).
  window.poe2k.onRitualResult(function (p) {
    if (!p) return;
    setBusy(false);
    $('idle').classList.add('hide');
    $('body').classList.remove('hide');
    renderRitual(p);
    showMode('ritual');
    setActiveTab('ritual');
  });

  /** №584: отрисовать распознанные предметы окна дани Ritual. */
  function renderRitual(p) {
    var wrap = $('ritualContent');
    wrap.innerHTML = '';
    var sec = document.createElement('div');
    sec.className = 'boss-sec';
    var head = document.createElement('div');
    head.className = 'camp-head';
    sec.appendChild(head);

    if (p.available === false) {
      head.textContent = '🕯 Ритуал';
      var errRow = document.createElement('div');
      errRow.className = 'boss-entry boss-unverified';
      var et = document.createElement('div');
      et.className = 'boss-sub';
      et.textContent = '⚠ ' + (p.error || 'Скан окна дани не удался.');
      errRow.appendChild(et);
      sec.appendChild(errRow);
      wrap.appendChild(sec);
      return;
    }

    var headTxt = '🕯 Дань Ritual · предметов: ' + (p.items || []).length;
    if (p.totalChaos != null) headTxt += ' · всего ~' + curIcon('chaos', 14) + p.totalChaos + ' chaos';
    if (p.elapsedMs != null) headTxt += ' · ' + p.elapsedMs + ' мс';
    head.textContent = headTxt;

    var items = p.items || [];
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var row = document.createElement('div');
      row.className = 'batch-item';
      var priceTxt;
      if (it.price && it.price.chaos != null) {
        priceTxt = '<span class="value">≈' + curIcon('chaos') + it.price.chaos + ' chaos</span>';
        if (it.price.divine != null && it.price.divine >= 0.01) priceTxt += '<span class="conf">(' + curIcon('div', 14) + it.price.divine + ' div)</span>';
      } else {
        priceTxt = '<span class="muted">н/д</span>';
      }
      var nameHtml = '<div class="bi-name">' + esc(it.nameEn || it.id) + (it.doubtful ? ' <span class="muted" title="score ' + it.score + ' — ниже порога">⚠</span>' : '') + '</div>';
      var noteHtml = '<div class="bi-note"><span class="muted">' +
        'ячейка ' + (it.column + 1) + '×' + (it.row + 1) +
        (it.width > 1 || it.height > 1 ? ' · ' + it.width + '×' + it.height + ' яч.' : '') +
        ' · score ' + it.score + '</span>' +
        (it.candidates && it.candidates.length > 1 ? '<span class="muted"> · 2-й: ' + esc(it.candidates[1].nameEn) + ' (' + it.candidates[1].score + ')</span>' : '') +
        '</div>';
      // Сборка строки innerHTML (стиль батч-вью прайса):
      row.innerHTML = nameHtml + '<div class="bi-est">' + priceTxt + '</div>' + noteHtml;
      sec.appendChild(row);
    }
    if (!items.length) {
      var empty = document.createElement('div');
      empty.className = 'boss-tip';
      empty.textContent = 'Клетки пусты — откройте окно дани Ritual (вкладка обмена) и повторите Ctrl+F8.';
      sec.appendChild(empty);
    }
    if (p.unassigned > 0) {
      var un = document.createElement('div');
      un.className = 'boss-tip';
      un.textContent = '⚠ Не распознано занятых ячеек: ' + p.unassigned + ' (MVP без OCR: часть предметов не идентифицируется по арту).';
      sec.appendChild(un);
    }
    var note = document.createElement('div');
    note.className = 'boss-tip';
    note.textContent = 'Цены — только для валюты (poe2scout + poe.ninja, кэш 10 мин). Уники без цены: MVP без OCR. Скан вручную Ctrl+F8, окно дани должно быть открыто.';
    sec.appendChild(note);
    wrap.appendChild(sec);
  }
// ─── Панель настроек (Ctrl+F6) ─────────────────────────────────────────────
  var setDirty = {};
  var HK_ACTIONS = [
    ['price', 'Прайс'],
    ['leveling', 'Прокачка'],
    ['move', 'Перемещение'],
    ['buildImport', 'Импорт билда'],
    ['buildPanel', 'Панель билда'],
    ['pinnacle', 'Чекап перед пиннаклом'],
    ['ritual', 'Ритуал-скан'],
    ['settings', 'Настройки']
  ];
  var hkInputs = {};

  // №113b: видимость вкладок боковой колонки. id синхронны с data-tab в HTML.
  var TABS_META = [
    ['price', '💰 Прайс'],
    ['build', '🛒 Билд'],
    ['gems', '💎 Камни'],
    ['suppadv', '🧩 Саппорты'],
    ['import', '📥 Импорт'],
    ['level', '📈 Прокачка'],
    ['maps', '🧭 Плитки'],
    ['slang', '📖 Слэнг'],
    ['craft', '⚒ Крафт'],
    ['rates', '💱 Курс'],
    ['gen', '🧬 Билды'],
    ['starterbuilds', '🧬 Стартовые'],
    ['pinnacle', '🛡 Пиннакл'],
    ['ritual', '🕯 Ритуал'],
    ['radar', '🛡 Радар'],
    ['settings', '⚙ Настройки'],
  ];
  function applyTabVisibility(hidden) {
    var hid = Array.isArray(hidden) ? hidden : [];
    TABS_META.forEach(function (t) {
      var btn = document.querySelector('#tabRow button[data-tab="' + t[0] + '"]');
      if (btn) btn.classList.toggle('hide', hid.indexOf(t[0]) >= 0);
    });
    if (activeTab && hid.indexOf(activeTab) >= 0) setActiveTab('');
  }
  function collectHiddenTabs() {
    var out = [];
    TABS_META.forEach(function (t) {
      if (t[0] === 'settings') return; // встроенно: настройки не прячем
      var cb = document.querySelector('#tabsGrid input[data-tab="' + t[0] + '"]');
      if (cb && !cb.checked) out.push(t[0]);
    });
    return out;
  }
  function buildTabsGrid(s) {
    var hidden = (s && Array.isArray(s.hiddenTabs)) ? s.hiddenTabs : [];
    var grid = $('tabsGrid');
    grid.innerHTML = '';
    TABS_META.forEach(function (t) {
      var lab = document.createElement('label');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.setAttribute('data-tab', t[0]);
      cb.checked = hidden.indexOf(t[0]) < 0;
      if (t[0] === 'settings') { cb.checked = true; cb.disabled = true; cb.title = 'Настройки нельзя скрыть'; }
      lab.appendChild(cb);
      lab.appendChild(document.createTextNode(t[1]));
      grid.appendChild(lab);
    });
  }

  function currentDraft() {
    var themeBtn = document.querySelector('#themeRow .on');
    var draftTheme = themeBtn ? themeBtn.getAttribute('data-theme') : 'default';
    return {
      corner: document.querySelector('#cornerRow .on')?.getAttribute('data-corner') || 'top-right',
      opacity: Number($('setOpacity').value) / 100,
      scale: Number($('setScale').value) / 100,
      width: Number($('setWidth').value),
      height: Number($('setHeight').value),
      autoHeight: !!$('setAutoHeight').checked,
      learn: !!$('setLearn').checked,
      bindWindow: !!$('setBindWindow').checked,
      autoClipboard: !!$('setAutoClip').checked,
      verdictLayer: !!$('setVerdictLayer').checked,
      gemLang: $('gemLangEn').classList.contains('on') ? 'en' : 'ru',
      // №105: тема доступности + свои цвета (пипетки).
      theme: draftTheme,
      colors: draftTheme === 'custom' ? {
        bg: $('setColBg').value,
        fg: $('setColFg').value,
        dim: $('setColDim').value,
        accent: $('setColAccent').value,
      } : {},
      hiddenTabs: collectHiddenTabs(),
      hotkeys: {}
    };
  }

  function collectHotkeys() {
    var hk = {};
    HK_ACTIONS.forEach(function (a) {
      var v = (hkInputs[a[0]] || {}).value || '';
      if (v) hk[a[0]] = v;
    });
    return hk;
  }

  function buildSettingsPanel(s) {
    setDirty = {};
    // Слайдеры.
    $('setOpacity').value = Math.round((s.opacity || 0.86) * 100);
    $('setScale').value = Math.round((s.scale || 1) * 100);
    $('setWidth').value = Math.round(s.width || 420);
    $('setHeight').value = Math.round(s.height || 480);
    $('setAutoHeight').checked = s.autoHeight === true;
    $('setLearn').checked = !!s.learn;
    $('setAutoClip').checked = !!s.autoClipboard;
    $('setVerdictLayer').checked = !!s.verdictLayer;
    $('setBindWindow').checked = s.bindWindow !== false;
    paintGemLang(s.gemLang === 'en' ? 'en' : 'ru');
    paintUiLang(s.lang === 'ru' || s.lang === 'en' ? s.lang : 'auto');
    // №105: тема доступности + пипетки.
    paintTheme((s.theme === 'contrast' || s.theme === 'cb' || s.theme === 'custom') ? s.theme : 'default');
    if (s.colors) {
      if (s.colors.bg) $('setColBg').value = s.colors.bg;
      if (s.colors.fg) $('setColFg').value = s.colors.fg;
      if (s.colors.dim) $('setColDim').value = s.colors.dim;
      if (s.colors.accent) $('setColAccent').value = s.colors.accent;
    }
    setDirty.opacity = true; setDirty.scale = true; setDirty.width = true; setDirty.height = true;
    buildTabsGrid(s); // №113b: чекбоксы видимости вкладок
    window.poe2k.learnInfo().then(function (li) {
      if (!li) return;
      $('learnRecords').textContent = li.enabled
        ? 'Включён · записей: ' + (li.records || 0)
        : 'Включить (opt-in)';
    }).catch(function () {});

    // Угол.
    var corners = document.querySelectorAll('#cornerRow button');
    for (var i = 0; i < corners.length; i++) {
      corners[i].classList.toggle('on', corners[i].getAttribute('data-corner') === s.corner);
    }

    // Хоткеи: поля для каждого действия; значения по умолчанию подсвечены как плейсхолдер.
    var grid = $('hkGrid');
    grid.innerHTML = '';
    hkInputs = {};
    HK_ACTIONS.forEach(function (a) {
      var action = a[0];
      var label = a[1];
      var val = (s.hotkeys && s.hotkeys[action]) || '';
      var def = (s.defaultHotkeys && s.defaultHotkeys[action]) || '';
      var row = document.createElement('div');
      row.className = 'hk';
      row.innerHTML = '<span>' + esc(label) +
        (val === '' ? ' <span class="tip">(' + esc(def) + ')</span>' : '') + '</span>';
      var inp = document.createElement('input');
      inp.placeholder = def;
      inp.value = val;
      inp.spellcheck = false;
      row.appendChild(inp);
      hkInputs[action] = inp;
      grid.appendChild(row);
    });
  }

  function refreshDraftValues() {
    $('setOpacityVal').textContent = Math.round(Number($('setOpacity').value)) + '%';
    $('setScaleVal').textContent = Math.round(Number($('setScale').value)) + '%';
    $('setWidthVal').textContent = Math.round(Number($('setWidth').value)) + ' px';
    $('setHeightVal').textContent = Math.round(Number($('setHeight').value)) + ' px';
  }

  function openSettings() {
    setBusy(false);
    $('idle').classList.add('hide');
    $('body').classList.add('hide');
    $('settingsPanel').classList.remove('hide');
    window.poe2k.settingsGet().then(function (s) {
      if (!s) return;
      buildSettingsPanel(s);
      refreshDraftValues();
      refreshWatchlist();
      refreshLeagueSelect();
      requestSize();
    }).catch(function () {});
  }

  // №82: селект лиги в ⚙. Список — poe2scout через IPC leagues:list (кэш 6 ч);
  // выбор применяется сразу (league:set → league.txt + пересчёт цен под лигу).
  function refreshLeagueSelect() {
    var sel = $('setLeague');
    sel.innerHTML = '<option>Загрузка списка лиг…</option>';
    window.poe2k.leaguesList().then(function (r) {
      var list = (r && r.leagues) || [];
      if (!list.length) {
        sel.innerHTML = '<option>Список недоступен (нет сети?)</option>';
        return;
      }
      var cur = r.current || list[0].name;
      var html = '';
      // Если активная лига не из списка (устарела/кастом) — показываем её сверху, чтобы селект не врал.
      var inList = list.some(function (l) { return l.name === cur; });
      if (!inList) html += '<option selected value="' + esc(cur) + '">' + esc(cur) + ' (текущая)</option>';
      list.forEach(function (l) {
        var lbl = l.name + (l.isCurrent ? ' ✦' : '');
        html += '<option value="' + esc(l.name) + '"' + (l.name === cur ? ' selected' : '') + '>' + esc(lbl) + '</option>';
      });
      sel.innerHTML = html;
    }).catch(function () {
      sel.innerHTML = '<option>Ошибка загрузки списка лиг</option>';
    });
  }

  $('setLeague').addEventListener('change', function () {
    var sel = $('setLeague');
    var v = sel.value;
    if (!v || v.indexOf('…') >= 0 || v.indexOf('недоступен') >= 0 || v.indexOf('Ошибка') >= 0) return;
    window.poe2k.setLeague(v).then(function (saved) {
      showToast('Лига: ' + (saved || v) + ' — цены пересчитаются под неё');
      window.poe2k.watchCheck().catch(function () {}); // watchlist-цены зависят от лиги — перепроверяем.
    }).catch(function () {
      showToast('Не удалось применить лигу');
    });
  });

  function closeSettings() {
    $('settingsPanel').classList.add('hide');
    $('idle').classList.remove('hide');
    requestSize();
  }

  $('settingsClose').addEventListener('click', closeSettings);
  $('settingsSave').addEventListener('click', function () {
    var draft = currentDraft();
    draft.hotkeys = collectHotkeys();
    window.poe2k.settingsApply(draft).then(function (res) {
      if (res && res.ok) {
        applyTabVisibility(res.settings && res.settings.hiddenTabs); // №113b
        closeSettings();
      } else {
        var msg = (res && res.error) || 'Не удалось сохранить';
        $('settingsSave').textContent = '✕ ' + msg;
        setTimeout(function () { $('settingsSave').textContent = 'Сохранить'; }, 2500);
      }
    }).catch(function () {});
  });
  $('settingsResetHK').addEventListener('click', function () {
    HK_ACTIONS.forEach(function (a) { hkInputs[a[0]].value = ''; });
  });
  $('diagBtn').addEventListener('click', function () {
    var btn = $('diagBtn');
    var out = $('diagOut');
    btn.disabled = true;
    btn.textContent = 'Собираю…';
    window.poe2k.diagCollect().then(function (r) {
      if (r && r.ok) {
        out.textContent = '✓ ' + r.chars + ' симв. / ' + r.lines + ' строк — скопировано в буфер.\\nФайл: ' + r.file;
        showToast('Диагностика скопирована в буфер обмена');
      } else {
        out.textContent = 'Ошибка сбора: ' + ((r && r.error) || 'неизвестно');
      }
      btn.disabled = false;
      btn.textContent = '📋 Отправить диагностику';
      requestSize();
    }).catch(function () {
      btn.disabled = false;
      btn.textContent = '📋 Отправить диагностику';
      out.textContent = 'Ошибка вызова диагностики';
      requestSize();
    });
  });
  $('learnShareBtn').addEventListener('click', function () {
    var btn = $('learnShareBtn');
    var out = $('learnOut');
    btn.disabled = true;
    btn.textContent = 'Готовлю…';
    window.poe2k.learnContribute().then(function (r) {
      if (r && r.ok) {
        out.textContent = '✓ ' + r.count + ' предметов — текст скопирован в буфер.\\nТеперь вставьте его в issue: sourcecraft.dev/volkovpartilaholin/poe2-kit/issues/new\\nФайл: ' + r.file;
        showToast('Вклад скопирован — вставьте в issue на SourceCraft');
      } else {
        out.textContent = 'Ошибка: ' + ((r && r.error) || 'неизвестно');
      }
      btn.disabled = false;
      btn.textContent = '📤 Поделиться предметами';
      requestSize();
    }).catch(function () {
      btn.disabled = false;
      btn.textContent = '📤 Поделиться предметами';
      out.textContent = 'Ошибка вызова';
      requestSize();
    });
  });
  ['setOpacity', 'setScale', 'setWidth', 'setHeight'].forEach(function (id) {
    $(id).addEventListener('input', function () {
      setDirty[id] = true;
      refreshDraftValues();
    });
  });
  var cornerBtns = document.querySelectorAll('#cornerRow button');
  for (var ci = 0; ci < cornerBtns.length; ci++) {
    cornerBtns[ci].addEventListener('click', function () {
      for (var c2 = 0; c2 < cornerBtns.length; c2++) cornerBtns[c2].classList.remove('on');
      this.classList.add('on');
      // Угол применяется мгновенно (без «Сохранить»): это дешёвая операция,
      // а её эффект видно только при игре в фокусе — просить ещё и «Сохранить»
      // путает («углы не работают»). Панель не закрываем; остальной draft
      // (слайдеры уже с live-preview) сохраняется тем же флоу, что и Save.
      var draft = currentDraft();
      draft.hotkeys = collectHotkeys();
      window.poe2k.settingsApply(draft).catch(function () {});
    });
  }

  // №105: тема цветов применяется мгновенно (как угол) — эффект виден сразу
  // на открытой панели, «Сохранить» для неё не нужен.
  var themeBtns = document.querySelectorAll('#themeRow button');
  for (var th = 0; th < themeBtns.length; th++) {
    themeBtns[th].addEventListener('click', function () {
      var theme = this.getAttribute('data-theme');
      paintTheme(theme);
      var draft = currentDraft();
      draft.hotkeys = collectHotkeys();
      applyThemeColors(draft.theme, draft.colors, Number($('setOpacity').value) / 100);
      window.poe2k.settingsApply(draft).catch(function () {});
    });
  }
  ['setColBg', 'setColFg', 'setColDim', 'setColAccent'].forEach(function (id) {
    $(id).addEventListener('input', function () {
      // Пипетка = режим «Свои»: автоматически переключаем тему и красим живьём.
      paintTheme('custom');
      var draft = currentDraft();
      draft.hotkeys = collectHotkeys();
      applyThemeColors('custom', draft.colors, Number($('setOpacity').value) / 100);
      window.poe2k.settingsApply(draft).catch(function () {});
    });
  });
  $('setColReset').addEventListener('click', function () {
    paintTheme('default');
    var draft = currentDraft();
    draft.hotkeys = collectHotkeys();
    applyThemeColors('default', null, Number($('setOpacity').value) / 100);
    window.poe2k.settingsApply(draft).catch(function () {});
  });

  // Язык имён камней: применяется мгновенно (как угол) — это лишь имена в панели.
  var gemLangBtns = { ru: $('gemLangRu'), en: $('gemLangEn') };
  ['ru', 'en'].forEach(function (lang) {
    gemLangBtns[lang].addEventListener('click', function () {
      if (this.classList.contains('on')) return;
      var draft = currentDraft();
      draft.gemLang = lang;
      draft.hotkeys = collectHotkeys();
      window.poe2k.settingsApply(draft).then(function () {
        paintGemLang(lang);
      }).catch(function () {});
    });
  });
  function paintGemLang(lang) {
    gemLangBtns.ru.classList.toggle('on', lang === 'ru');
    gemLangBtns.en.classList.toggle('on', lang === 'en');
  }

  // №158: язык UI панели — применяется перезагрузкой renderer (перевод
  // деструктивен, обратное переключение без reload RU не восстановит).
  var uiLangBtns = { ru: $('uiLangRu'), auto: $('uiLangAuto'), en: $('uiLangEn') };
  ['ru', 'auto', 'en'].forEach(function (lang) {
    uiLangBtns[lang].addEventListener('click', function () {
      if (this.classList.contains('on')) return;
      var draft = currentDraft();
      draft.lang = lang;
      draft.hotkeys = collectHotkeys();
      window.poe2k.settingsApply(draft).then(function () {
        location.reload(); // boot сам применит язык и запустит observer
      }).catch(function () {});
    });
  });
  function paintUiLang(lang) {
    uiLangBtns.ru.classList.toggle('on', lang === 'ru');
    uiLangBtns.auto.classList.toggle('on', lang === 'auto');
    uiLangBtns.en.classList.toggle('on', lang === 'en');
  }

  // №105: цвета доступности. Пресеты (CSS-переменные :root):
  //  - contrast: чёрный/белый — максимальная светимость текста; статусы
  //    различимы и по светлоте (✕ ярче ⚠ ярче ✅ по насыщенности, все с иконками).
  //  - cb: палитра Okabe-Ito (Okabe & Ito, 2008) — универсально безопасна при
  //    красно-зелёной (де-/протанопия) и сине-жёлтой (тританопия) слепоте:
  //    небесно-синий/жёлтый/киноварь/сине-зелёный различимы по тону И светлоте.
  var lastOpacity = 0.86;
  var THEME_PRESETS = {
    default: null,
    contrast: { bg: '#000000', fg: '#ffffff', dim: '#e0e0e0', accent: '#ffd700',
      border: 'rgba(255,215,0,0.85)', ok: '#00e676', warn: '#ffffff', err: '#ff4040' },
    cb: { bg: '#10151b', fg: '#ffffff', dim: '#b0bec5', accent: '#56b4e9',
      border: 'rgba(86,180,233,0.65)', ok: '#009e73', warn: '#f0e442', err: '#d55e00' },
  };
  function hexToRgba(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + (alpha == null ? 1 : alpha).toFixed(2) + ')';
  }
  /** Применить тему/цвета к CSS-переменным. theme='custom' — только пипетки. */
  function applyThemeColors(theme, colors, opacity) {
    var rootStyle = document.documentElement.style;
    if (typeof opacity === 'number') lastOpacity = opacity;
    // Сброс к дефолту (:root) — снимаем все переопределения.
    ['--bg', '--fg', '--dim', '--accent', '--border', '--ok', '--warn', '--err'].forEach(function (v) {
      rootStyle.removeProperty(v);
    });
    var bg = null, fg = '#f0e6d2', dim = '#a89a83', accent = '#c69a52';
    var preset = THEME_PRESETS[theme];
    if (preset) {
      bg = preset.bg; fg = preset.fg; dim = preset.dim; accent = preset.accent;
      rootStyle.setProperty('--border', preset.border);
      rootStyle.setProperty('--ok', preset.ok);
      rootStyle.setProperty('--warn', preset.warn);
      rootStyle.setProperty('--err', preset.err);
    }
    if (theme === 'custom' && colors) {
      if (colors.bg) bg = colors.bg;
      if (colors.fg) fg = colors.fg;
      if (colors.dim) dim = colors.dim;
      if (colors.accent) accent = colors.accent;
    }
    // 'default' — не трогаем :root вовсе (CSS-дефолты). Любая другая тема —
    // перекрашиваем фон (с сохранением альфы прозрачности) и текст.
    if (theme !== 'default') {
      if (bg) rootStyle.setProperty('--bg', hexToRgba(bg, lastOpacity));
      rootStyle.setProperty('--fg', fg);
      rootStyle.setProperty('--dim', dim);
      rootStyle.setProperty('--accent', accent);
    }
  }
  function paintTheme(theme) {
    var btns = document.querySelectorAll('#themeRow button');
    for (var i = 0; i < btns.length; i++) btns[i].classList.toggle('on', btns[i].getAttribute('data-theme') === theme);
  }

  // Открытие/закрытие панели настроек (Ctrl+F6 из main).
  window.poe2k.onSettingsToggle(function () {
    if ($('settingsPanel').classList.contains('hide')) openSettings();
    else closeSettings();
  });

  // №64: вкладки — кликом открывают те же панели, что и хоткеи.
  // Подсветка активной вкладки синхронизируется и с хоткейами (события main).
  var tabBtns = document.querySelectorAll('#tabRow button');
  // №101: активная вкладка — onBuildUpdate не должен силой перекрашивать её,
  // когда пользователь смотрит результат импорта (это и был «прыжок на Билд»).
  var activeTab = '';
  function setActiveTab(tab) {
    activeTab = tab;
    for (var ti = 0; ti < tabBtns.length; ti++) {
      tabBtns[ti].classList.toggle('on', tabBtns[ti].getAttribute('data-tab') === tab);
    }
  }
  function bindTabs() {
    for (var bi = 0; bi < tabBtns.length; bi++) {
      tabBtns[bi].addEventListener('click', function () {
        var tab = this.getAttribute('data-tab');
        setActiveTab(tab);
        if (tab === 'gems') {
          showGemsView(); // локальная панель, IPC не нужен
        } else if (tab === 'suppadv') {
          showSuppadvView(); // №193: советчик саппортов, датасет gemdata офлайн
        } else if (tab === 'maps') {
          showMapsView(); // №85: статический справочник крафта плиток, IPC не нужен
        } else if (tab === 'slang') {
          showSlangView(); // №133: локальный словарь слэнга, IPC не нужен
        } else if (tab === 'craft') {
          showCraftView(); // №134: локальный вью; план/каталог тянутся по IPC
        } else if (tab === 'rates') {
          showRatesView(); // №135: курсы валют по лигам (IPC currency:rates)
        } else if (tab === 'gen') {
          showGenView(); // №136: генератор билдов по ладдеру poe.ninja
        } else if (tab === 'import') {
          showImportView(); // №101: свой вью; запуск импорта — кнопкой/Ctrl+F3
        } else if (tab === 'radar') {
          showRadarView(); // №262: live-баги/трюки — офлайн, данные запечены
        } else if (tab === 'starterbuilds') {
          showStartersView(); // №479: стартовые билды — офлайн, данные запечены
        } else {
          window.poe2k.panelOpen(tab).catch(function () {});
        }
      });
    }
  }
  bindTabs();

  // ─── №262 Этап 2: keybinds-секция в панели билда (движок core.keybinds) ────
  // Отдельный div #buildKeybinds (в buildWrap после #buildSum): build-рендер
  // его не перезаписывает, показывается/прячется вместе с панелью билда.
  function renderKeybindsSection() {
    var host = $('buildKeybinds');
    if (!host) return;
    host.innerHTML =
      '<button id="kbBtn" class="tabbtn" style="margin-top:6px">🎮 Раскладка по билду</button>' +
      '<div id="kbOut"></div>';
    $('kbBtn').addEventListener('click', function () {
      var out = $('kbOut');
      if (!out) return;
      out.innerHTML = '<div class="lvl-hint">Считаю раскладку…</div>';
      window.poe2k.keybindsAdvice().then(function (res) {
        if (!res || !res.ok) {
          out.innerHTML = '<div class="lvl-hint">' + esc((res && res.error) || 'Ошибка') + '</div>';
          return;
        }
        var a = res.advice || {};
        var roles = (a.assignments || []).map(function (s) {
          return '<button class="tree-chip" title="' + esc(s.reason || '') + '">' +
            '<b>' + esc(s.slot) + '</b> ' + esc(s.gem || '—') + '</button>';
        }).join('');
        var spirit = (a.spirit || []).length
          ? '<div class="lvl-hint">Spirit (не биндить): ' + a.spirit.map(function (s) { return esc(s.gem); }).join(', ') + '</div>'
          : '';
        var unassigned = (a.unassigned || []).length
          ? '<div class="lvl-hint">Без слота: ' + a.unassigned.map(esc).join(', ') + '</div>'
          : '';
        out.innerHTML =
          '<div class="slang-hint">' + esc(res.className || 'Билд') + (res.ascendancy ? ' / ' + esc(res.ascendancy) : '') +
          ' — боевые слоты (' + (a.assignments || []).length + '):</div>' +
          '<div class="tree-chips">' + roles + '</div>' + spirit + unassigned +
          '<div class="lvl-hint">Полная раскладка (схемы, система, инструкции) — web-вкладка «🎮 Раскладка».</div>';
      }).catch(function (e) {
        out.innerHTML = '<div class="lvl-hint">Ошибка IPC: ' + esc(String(e)) + '</div>';
      });
    });
  }
  renderKeybindsSection();
  // №105: применить сохранённую тему/цвета при загрузке (main шлёт settings:display
  // только при изменениях, а не на старте) — берём настройки сами.
  window.poe2k.settingsGet().then(function (s) {
    if (!s) return;
    // №158: язык UI — auto = язык Windows.
    var lang = (s && (s.lang === 'ru' || s.lang === 'en')) ? s.lang
      : ((navigator.language || 'ru').toLowerCase().indexOf('ru') === 0 ? 'ru' : 'en');
    applyLang(lang);
    startLangObserver();
    applyThemeColors(
      s.theme === 'contrast' || s.theme === 'cb' || s.theme === 'custom' ? s.theme : 'default',
      s.colors || null,
      typeof s.opacity === 'number' ? s.opacity : 0.86
    );
    applyTabVisibility(s.hiddenTabs); // №113b: скрытые вкладки убираем при старте
  }).catch(function () {});
  // №65: клики по оверлею. Окно по умолчанию click-through
  // (setIgnoreMouseEvents(true,{forward:true}), main.ts) — ВСЕ кнопки UI
  // (вкладки/✕/слайдеры) были некликабельны вне режима Ctrl+F5. С forward:true
  // рендерею приходят mouseenter/mouseleave: курсор над оверлеем → включаем
  // интерактив, ушёл → выключили и снова не мешаем игре. Move-режим (там
  // интерактивом управляет main) не трогаем.
  var winUnlocked = false;
  window.poe2k.onMoveMode(function (st) { winUnlocked = !!(st && st.unlocked); });
  document.addEventListener('mouseenter', function () {
    if (winUnlocked) return;
    window.poe2k.setInteractive(true).catch(function () {});
  });
  document.addEventListener('mouseleave', function () {
    if (winUnlocked) return;
    window.poe2k.setInteractive(false).catch(function () {});
  });
  // №113e: клавиатура для полей ввода (поиск нод в Билде и т.п.). Окно
  // focusable:false — без этого текст в поля не вводился. Включаем фокус
  // ТОЛЬКО пока поле в фокусе: focusin на input → отдать клавиатуру панели,
  // focusout → вернуть игре. Наведение мыши на панель фокус не ворует.
  document.addEventListener('focusin', function (ev) {
    var t = ev.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
      window.poe2k.captureKeyboard(true).catch(function () {});
    }
  });
  document.addEventListener('focusout', function (ev) {
    var t = ev.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
      window.poe2k.captureKeyboard(false).catch(function () {});
    }
  });
  // №113e-b: focusin в блюрнутом renderer (окно без OS-фокуса) может НЕ
  // сработать — по живому логу друга keyboard:set не вызывался вовсе.
  // mousedown доходит всегда: хватаем клавиатуру на нажатии по полю и
  // принудительно фокусим элемент после (клик в блюрнутом окне не
  // обязательно ставит DOM-фокус).
  document.addEventListener('mousedown', function (ev) {
    var t = ev.target;
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
      window.poe2k.captureKeyboard(true).catch(function () {});
      setTimeout(function () {
        if (document.activeElement !== t && t.focus) {
          try { t.focus(); } catch (e) { /* элемент мог уйти из DOM */ }
        }
      }, 0);
    }
  });
  // №128: у каждой функции — окно с информацией (что делает вкладка, хоткеи).
  var TAB_INFO = ${JSON.stringify(TAB_INFO, null, 2)};
  function hideInfoWin() { document.getElementById('infoWin').classList.add('hide'); }
  document.getElementById('tabInfoBtn').addEventListener('click', function () {
    var w = document.getElementById('infoWin');
    if (!w.classList.contains('hide')) { hideInfoWin(); return; } // повторное ℹ закрывает
    var w = document.getElementById('infoWin');
    var inf = TAB_INFO[activeTab] || { t: 'Оверлей poe2-kit', h: '—', b: [
      'Выбери вкладку слева — «ℹ ?» расскажет, что она делает и каким хоткеем открывается.',
      'Ctrl+F1 прайс · Ctrl+F2 билд · Ctrl+F3 импорт · Ctrl+F4 прокачка · Ctrl+F5 закрепить позицию · Ctrl+F6 настройки · Ctrl+F7 чекап пиннакла.' ] };
    var html = '<div class="h2">' + inf.t + ' <span class="hk">' + inf.h + '</span>' +
      '<span class="close-info" id="infoWinClose" title="Закрыть">✕</span></div>';
    for (var i = 0; i < inf.b.length; i++) html += '<div>· ' + inf.b[i] + '</div>';
    html += '<div class="sub" style="margin-top:8px">ℹ — повторное нажатие закрывает это окно.</div>';
    html += '<div class="sub" style="margin-top:4px">☕ Kit бесплатный и без рекламы. Помочь разработке (СБП / WebMoney) — раздел «Поддержка» в README проекта.</div>';
    w.innerHTML = html;
    w.classList.remove('hide');
    document.getElementById('infoWinClose').addEventListener('click', hideInfoWin);
  });
  // повторное ℹ закрывает; клик по другой вкладке закрывает инфоокно
  document.getElementById('tabInfoBtn').addEventListener('dblclick', hideInfoWin);
  var tabRowEl = document.getElementById('tabRow');
  if (tabRowEl) tabRowEl.addEventListener('click', function (ev) {
    var b = ev.target;
    if (b && b.getAttribute && b.getAttribute('data-tab')) hideInfoWin();
  });
  // Хоткей-пути красят ту же вкладку: параллельные слушатели событий main.
  window.poe2k.onPriceBatch(function () { setActiveTab('price'); });
  window.poe2k.onLevelResult(function () { setActiveTab('level'); });
  window.poe2k.onBuildUpdate(function (st) {
    // №101: на вкладке «Импорт» подсветка не перекрашивается в «Билд» — там свой вью.
    if (activeTab === 'import') return;
    setActiveTab(st && st.visible ? 'build' : '');
  });
  window.poe2k.onSettingsToggle(function () {
    setActiveTab($('settingsPanel').classList.contains('hide') ? '' : 'settings');
  });

  // Применение настроек отображения из main (прозрачность/масштаб/ширина/угол).
  window.poe2k.onSettingsDisplay(function (s) {
    if (!s) return;
    // Прозрачность фона панели + тема/цвета доступности (№105) — единым путём:
    applyThemeColors(
      s.theme === 'contrast' || s.theme === 'cb' || s.theme === 'custom' ? s.theme : 'default',
      s.colors || null,
      typeof s.opacity === 'number' ? s.opacity : 0.86
    );
    // Масштаб UI через zoom (учитывается в авторазмере высоты).
    var z = (typeof s.scale === 'number' ? s.scale : 1);
    var panel = $('panel');
    if (typeof panel.style.zoom === 'string') panel.style.zoom = String(z);
    else panel.style.transform = 'scale(' + z + ')';
    // Обновляем элементы панели настроек, если она открыта.
    if (!$('settingsPanel').classList.contains('hide')) {
      buildSettingsPanel({
        corner: s.corner,
        // №107-fix: было opacity: alpha — несуществующая переменная, ReferenceError
        // при каждом settings:display с открытой панелью настроек.
        opacity: (typeof s.opacity === 'number' ? s.opacity : 0.86), scale: z,
        width: (typeof s.width === 'number' ? s.width : 420),
        hotkeys: {}, defaultHotkeys: {}
      });
      refreshDraftValues();
    }
    requestSize();
  });
})();
</script>
</body>
</html>`;