/**
 * MCP-инструменты: гид по прокачке (точные зоны актов).
 */

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { core } from '@poe2-kit/core';

export function registerLevelingTools(server: McpServer): number {
  server.registerTool(
    'poe2_leveling_plan',
    {
      title: 'PoE2 Leveling Plan',
      description: `План прокачки персонажа PoE2: точные зоны Актов 1–4 с уровнями монстров, квестовыми наградами и заметками.

Аргументы:
  - act (number, опц.): номер акта (1-4). Если не указан — весь план целиком.
  - from_level (number, опц.): показывать зоны с уровня монстров не ниже этого.
  - class (string, опц.): базовый класс ИЛИ асценданси ('Warrior', 'Sorceress', 'Ranger', 'Mercenary', 'Witch', 'Druid', 'Huntress', 'Monk', либо 'Invoker', 'Lich', 'Titan', 'Deadeye', ...) — обогатить план советами этого класса (камни/экипировка/механика).
  - league (string, опц.): лига для league-контекста (по умолчанию не задана). В "Forbidden Rites" Plunder's Point помечается 🔴ОБЯЗАТЕЛЬНО (Runeseeker → Verisium Anvil → Runeforging, гейт — 4 Map Pieces в Kingsmarch).
  - monk (boolean, опц., deprecated): true — то же, что class='Monk'.

Источник: path-of-levelling-2 (автор Kami-Guru метод), данные зон и наград.

Примеры:
  - "Куда идти в Акте 2?" → act=2
  - "Что дают награды?" → весь план
  - "Гид прокачки Witch" → class=Witch
  - "Гид Ice Strike Monk" → class=Monk
`,
      inputSchema: {
        act: z.number().int().min(1).max(4).optional().describe('Номер акта (1-4)'),
        from_level: z.number().int().optional().describe('Мин. уровень монстров'),
        class: z.string().optional().describe('Класс или асценданси для советов (Warrior/Invoker/...)'),
        league: z.string().optional().describe('Лига для league-контекста (например "Forbidden Rites"): зоны типа Plunder\'s Point помечаются обязательными, с шагом Runeseeker→Runeforging'),
        monk: z.boolean().optional().describe('deprecated: советы Ice Strike Monk (= class=Monk)'),
      },
      annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true },
    },
    async ({ act, from_level, class: klass, league, monk }) => {
      try {
        const query = klass ?? (monk ? 'Monk' : undefined);
        const guide = query ? core.leveling.resolveLevelingClass(query) : null;
        // P8: league-контекст — в requiredInLeagues-зонах (Plunder's Point)
        // план пометит обязательность и даст шаг Runeseeker→Runeforging.
        let plan = guide
          ? core.leveling.getClassLevelingPlan(query)
          : core.leveling.getLevelingPlan(league);
        if (act != null) plan = plan.filter((z) => z.act === act);
        if (from_level != null) plan = plan.filter((z) => z.monsterLevel >= from_level!);
        if (!plan.length) {
          return { content: [{ type: 'text', text: 'Нет зон по заданным фильтрам.' }] };
        }
        const label = guide ? `План прокачки ${guide.baseClass}` : 'План прокачки PoE2';
        const lines = [
          `## ${label}${act ? ` — Акт ${act}` : ''}`,
          '',
        ];
        for (const z of plan) {
          const steps = z.steps.length ? z.steps.map((s) => `    - ${s}`).join('\n') : '';
          const rewards = z.rewards.length ? ` *(награда: ${z.rewards.join('; ')})*` : '';
          const wp = z.hasWaypoint ? ' ⚑вайпоинт' : '';
          const req = z.requiredInLeague ? ' 🔴ОБЯЗАТЕЛЬНО в вашей лиге' : z.optional ? ' (опционально)' : '';
          lines.push(`**Акт ${z.act} · ${z.zone}** (уровень ${z.monsterLevel})${wp}${req}${rewards}`);
          if (steps) lines.push(steps);
          lines.push('');
        }
        return { content: [{ type: 'text', text: lines.join('\n') }] };
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return { isError: true, content: [{ type: 'text', text: `Ошибка: ${msg}` }] };
      }
    },
  );

  server.registerTool(
    'poe2_leveling_class',
    {
      title: 'PoE2 Class Leveling Tips (any class)',
      description: `Билд-специфичные советы прокачки ЛЮБОГО класса PoE2: какие камни/способности использовать, приоритеты экипировки и механика по диапазонам уровней (Акты 1–4 + эндгейм).

Поддерживаются все 8 базовых классов и все асценданси: Monk/Invoker, Warrior/Titan, Sorceress/Stormweaver, Ranger/Deadeye, Mercenary/Witchhunter, Witch/Lich, Druid, Huntress/Amazon — передайте любой вариант, он будет резолвлен в базовый класс.

Аргументы:
  - class (string, опц.): базовый класс или асценданси ('Warrior', 'Invoker', 'Lich', 'Deadeye', ...). По умолчанию — Monk.
  - level (number, опц.): текущий уровень персонажа — вернуть только советы этого диапазона.
  - list (boolean, опц.): true — вернуть список всех классов с краткой характеристикой.

Примеры:
  - "Что брать ведьме в начале?" → class=Witch
  - "Гид прокачки Lich" → class=Lich
  - "Мне 30 ур, советы воину" → class=Warrior, level=30
  - "Какие классы бывают?" → list=true
`,
      inputSchema: {
        class: z.string().optional().describe('Класс или асценданси (Warrior/Invoker/...)'),
        level: z.number().int().min(1).optional().describe('Текущий уровень персонажа'),
        list: z.boolean().optional().describe('Показать список всех классов'),
      },
      annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: true },
    },
    async ({ class: klass, level, list }) => {
      try {
        if (list) {
          const classes = core.leveling.listLevelingClasses();
          const lines = ['## Классы PoE2 — гиды прокачки', ''];
          for (const c of classes) {
            lines.push(`- **${c.baseClass}** (${c.tipCount} диапазонов): ${c.tagline}`);
          }
          lines.push('');
          lines.push('_Передайте class (или асценданси) для деталей. Асценданси всех классов: poe2_dataset_info._');
          return { content: [{ type: 'text', text: lines.join('\n') }] };
        }
        const guide = core.leveling.resolveLevelingClass(klass) ?? core.leveling.resolveLevelingClass('Monk')!;
        const tips = core.leveling.getClassLevelingTips(klass ?? guide.baseClass, level);
        const lines = [
          `## ${guide.baseClass} — советы прокачки`,
          `_${guide.tagline}_`,
          `Урон: ${guide.damage.join('; ')}`,
          `Защита: ${guide.defense.join('; ')}`,
          '',
        ];
        if (!tips.length) {
          lines.push(core.leveling.getClassLevelingHint(klass ?? guide.baseClass, level));
        }
        for (const t of tips) {
          const range = t.toLevel == null ? `${t.fromLevel}+` : `${t.fromLevel}–${t.toLevel}`;
          lines.push(`**Уровни ${range}**:`);
          if (t.gems?.length) lines.push(`  - Камни: ${t.gems.join(', ')}`);
          if (t.gear?.length) lines.push(`  - Экипировка: ${t.gear.join('; ')}`);
          if (t.notes?.length) {
            for (const n of t.notes) lines.push(`  - ${n}`);
          }
          lines.push('');
        }
        return { content: [{ type: 'text', text: lines.join('\n') }] };
      } catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        return { isError: true, content: [{ type: 'text', text: `Ошибка: ${msg}` }] };
      }
    },
  );

  // P8 ч.2 (№281-W2): Invoker-гайд по этапам 1-30/30-60/60-80/80-95 (Ice Strike CI, SSF).
  server.registerTool(
    'poe2_leveling_guide',
    {
      title: 'PoE2 Invoker Leveling Guide (stages)',
      description: `Дорожная карта Ice Strike Invoker (CI, SSF) по этапам уровней 1-30 / 30-60 / 60-80 / 80-95: цели этапа, порядок камней (Ice Strike → вестники → Blasphemy+Temporal Chains), приоритеты суппортов, шмот/дерево, CI-гейт (ES >= 2.5-3x жизней), финальные слоты по PoB 28880 (Brimstone Cowl, Pandemonium Paw и др.) и SSF-приоритеты.

Аргументы:
  - level (number, опц.): текущий уровень — вернуть карточку «вашего» этапа + следующий.
  - stage (number, опц., 1-4): конкретный этап (1=1-30, 2=30-60, 3=60-80/Ascendancy+CI, 4=80-95/эндгейм).
  - overview (boolean, опц.): true — все этапы списком (по умолчанию, если ни level, ни stage не заданы).

Примеры:
  - "Я 45lvl Invoker, что дальше?" → level=45
  - "Когда переходить на CI?" → stage=3
  - "Покажи весь роадмап" → overview=true
`,
      inputSchema: {
        level: z.number().int().min(1).max(120).optional().describe('Текущий уровень персонажа'),
        stage: z.number().int().min(1).max(4).optional().describe('Номер этапа (1-4)'),
        overview: z.boolean().optional().describe('true — обзор всех этапов'),
      },
    },
    async ({ level, stage, overview }) => {
        try {
          const g = core.invokerGuide.getInvokerGuide();
          const st = stage
            ? core.invokerGuide.getInvokerGuide().stages.find((s) => s.stage === stage)
            : core.invokerGuide.getInvokerStage(level);
          const lines = [
            `## ${g._meta.title}`,
            `_${g.build.mainSkill} · ${g.build.ascendancy} (${g.build.class}) · ${g.build.mode} · эталон: ${g.build.pobRef}_`,
            '',
          ];
          const fmtStage = (s: NonNullable<typeof st>): string => {
            const out = [
              `### Этап ${s.stage}: уровни ${s.levelRange[0]}-${s.levelRange[1]} (${s.acts}) — ${s.title}`,
              s.theme,
            ];
            if (s.skillOrder?.length) out.push(`- Камни по порядку: ${s.skillOrder.join(' → ')}`);
            if (s.supportPriority) out.push(`- Суппорты/дерево: ${s.supportPriority}`);
            if (s.gear) out.push(`- Экипировка: ${s.gear}`);
            if (s.gearSlots) {
              out.push('- Целевые слоты (PoB):');
              for (const [slot, item] of Object.entries(s.gearSlots)) out.push(`    - ${slot}: ${item}`);
            }
            if (s.tree) out.push(`- Дерево: ${s.tree}`);
            if (s.ciGate) out.push(`- ⚠ CI-гейт: ${s.ciGate}`);
            if (s.watchOut) out.push(`- ⚠ ${s.watchOut}`);
            return out.join('\n');
          };
          if (!overview && (level != null || stage != null)) {
            if (!st) {
              lines.push(`Этап не найден. Доступны 1-4 (${g.stages.map((s) => `${s.stage}=${s.levelRange[0]}-${s.levelRange[1]}`).join(', ')}).`);
            } else {
              lines.push(fmtStage(st));
              if (level != null) lines.push(`\n**Ваш уровень ${level} — Этап ${st.stage}.**`);
              const next = core.invokerGuide.getNextInvokerStage(st.stage);
              lines.push(next ? `\n**Следующий этап ${next.stage}** (${next.levelRange[0]}-${next.levelRange[1]}): ${next.title}` : '\nЭто финальный этап — далее только шлифовка под PoB-таргеты.');
              const t = g.build.targets;
              if (st.stage >= 3) {
                lines.push('', `**PoB-таргеты:** DPS ${t.totalDps.toLocaleString('ru-RU')} · EHP ${t.totalEhp.toLocaleString('ru-RU')} · ES ${t.es} · крит ${t.critChancePct}% ×${t.critMulti} · Дух ${t.spirit}`);
              }
            }
          } else {
            for (const s of g.stages) lines.push(fmtStage(s), '');
            lines.push(`**SSF-приоритеты:**`);
            for (const p of g.ssfPriorities) lines.push(`- ${p}`);
          }
          return { content: [{ type: 'text', text: lines.join('\n') }] };
        } catch (error) {
          const msg = error instanceof Error ? error.message : String(error);
          return { isError: true, content: [{ type: 'text', text: `Ошибка: ${msg}` }] };
        }
      },
  );

  return 3;
}