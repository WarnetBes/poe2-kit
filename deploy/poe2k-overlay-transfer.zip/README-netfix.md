# PoE2 Network Fix (v7 - SAFE)

Оптимизация сети Windows для **Path of Exile 2** + решение проблемы Steam из России.

## Что делает

| # | Что | Зачем |
|---|-----|-------|
| 1 | **NetworkThrottlingIndex → 0xFFFFFFFF** | Главное средство против спайков пинга 20-40k мс в PoE2 |
| 2 | **Initial RTO: 1000 → 300 мс** | Быстрее повторная отправка при потере пакетов |
| 3 | **Max SYN retransmissions: 4 → 2** | Быстрее определяется мёртвый хост |
| 4 | **NIC offloads** | RSC/LSO OFF (меньше latency), Checksum/RSS ON (меньше CPU) |
| 5 | **DNS → 8.8.8.8 / 8.8.4.4** | Google DNS — надёжно в России |
| 6 | **GameDVR OFF** (HKLM + HKCU) | Нет фоновой записи |
| 7 | **Wi-Fi check** | SSID, Signal %, Channel, 2.4/5 GHz |
| 8 | **TCP port test** к GGG | Реальное время подключения |

## Steam из России: ProtonVPN

Steam в РФ заблокирован (Cloudflare CDN block). Решение — бесплатный ProtonVPN:

**Скачать установщик (124 MB):**
```
https://github.com/ProtonVPN/win-app/releases/download/v5.1.8/ProtonVPN_v5.1.8_x64.exe
```

**SHA256:** `c7e9d52fd4d3b65ff8ea83c24dbbe3f4ad9b3726739cf645ce15b9e24edc4aa4`

**Установка:**
1. Запусти `ProtonVPN_v5.1.8_x64.exe`
2. Создай аккаунт (email)
3. Подключись к серверу **Netherlands** или **Finland**
4. Перезапусти Steam

**Проверка:**
```powershell
nslookup cdn.cloudflare.steampowered.com  # должен резолвить IP
```

Подробности: [PROTONVPN-README.md](PROTONVPN-README.md)

## Что НЕ делает (убрано — ломало connectivity)

| Убрано | Причина |
|--------|---------|
| CTCP | Breaks TLS |
| DNS priority overrides | Changes name resolution order |
| Narrow dynamic ports | Too restrictive |
| RSC global disable | Conflicts with NIC-level |
| DefaultTTL/MaxUserPort/TcpTimedWaitDelay | Not needed |
| TCP timestamps off | Breaks TLS |

## Запуск

1. Скопируй `poe2_netfix.ps1` и `poe2_netfix.bat` в одну папку
2. Правой кнопкой по `poe2_netfix.bat` → **Run as administrator**
3. **Перезагрузи ПК**
4. Запусти PoE2 (через Steam или GGG Launcher)
5. Выбери регион **EUROPE (Frankfurt / London)**

## Откат

### Лёгкий откат (только v7)
Запусти `poe2_netfix_revert.bat` от админа → перезагрузи.

### Полный откат (все версии)
Запусти `poe2_full_recovery.bat` от админа → перезагрузи.
Убирает **все** изменения (v2, v3, v5, v7).

## Если Steam/PoE2 перестали работать

1. Запусти `poe2_full_recovery.bat` от админа → перезагрузи
2. Если Steam всё ещё не работает → установи ProtonVPN (ссылка выше)
3. Подключи VPN → перезапусти Steam

## Требования

- Windows 10/11
- Права администратора
- PowerShell 5.1+

## Источники

- [PoE2 Forum - NetworkThrottlingIndex fix](https://www.pathofexile.com/forum/view-thread/3677507/page/27)
- [SpeedGuide.net - Gaming Tweaks](https://www.speedguide.net/articles/gaming-tweaks-5812)
- [Microsoft Learn - NIC Performance Tuning](https://learn.microsoft.com/en-us/windows-server/networking/technologies/network-subsystem/net-sub-performance-tuning-nics)
- [ProtonVPN](https://protonvpn.com)
